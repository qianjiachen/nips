# Reviewer Code Package

This anonymized supplementary package is organized for reviewer-side
inspection and reruns.

## Included contents

- `experiments/scripts/`: training, evaluation, scoring, aggregation, and plotting scripts
- `experiments/configs/`: pilot, main, and fast diagnostic configs
- `experiments/data/arithshift/`: synthetic pilot data and probe pool
- `experiments/data/public_reasoning/`: prepared public-transfer benchmark files
- `experiments/runs/final/`: final summaries and analysis artifacts used by the paper
- `docs/`: setup notes and multiseed layout notes

## Quick start

1. Read `experiments/README_ANON_SUBMISSION.md`.
2. Create the environment with `bash experiments/setup_wsl.sh` or use the dependency
   list in `experiments/requirements-wsl.txt`.
3. Run `bash experiments/run_pilot.sh` for the synthetic pilot or
   `bash experiments/run_public_transfer.sh` /
   `bash experiments/scripts/run_public_single_gpu_8seed_qwen15b.sh`
   for public-transfer runs.

## Notes

- Internal caches, draft notes, debug logs, and archive snapshots are intentionally
  excluded from this package.
- Any absolute machine-specific paths found in saved JSON/Markdown outputs are rewritten
  to anonymized relative placeholders for reviewer readability.

