# Anonymous Supplementary Code Guide

This repository snapshot is intended for anonymous NeurIPS submission-time
reproducibility. It contains the training, evaluation, checkpoint-scoring, and
paper-artifact scripts used by the submission.

## Environment

- Recommended platform: Linux or WSL2 Ubuntu
- Python dependencies: `experiments/requirements-wsl.txt`
- Setup helper: `experiments/setup_wsl.sh`
- Additional environment notes: `docs/SETUP_WSL.md`

Install the Python packages with either:

```bash
bash experiments/setup_wsl.sh
```

or:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r experiments/requirements-wsl.txt
```

## Main files

- Training script: `experiments/scripts/train_sft.py`
- Checkpoint evaluation: `experiments/scripts/evaluate_checkpoints.py`
- Proxy scoring: `experiments/scripts/score_checkpoints.py`
- Multiseed orchestration: `experiments/scripts/run_public_multiseed.py`
- Public-transfer convenience launcher: `experiments/run_public_transfer.sh`
- Full eight-seed single-GPU launcher:
  `experiments/scripts/run_public_single_gpu_8seed_qwen15b.sh`
- Pilot launcher: `experiments/run_pilot.sh`

## Configs

- Pilot config: `experiments/configs/arithshift_pilot.json`
- Main config: `experiments/configs/public_transfer_qwen25_15b.json`
- Fast diagnostic configs:
  `experiments/configs/public_transfer_qwen25_05b_xvalid_fast.json`,
  `experiments/configs/public_transfer_qwen25_15b_xvalid_fast.json`

The main config specifies the backbone, dataset paths, sequence length, learning
rate, epoch count, batch sizes, warmup ratio, weight decay, LoRA settings, and
checkpoint cadence defaults.

## Commands

Run the synthetic pilot:

```bash
bash experiments/run_pilot.sh
```

Run the public-transfer pipeline with the convenience wrapper:

```bash
bash experiments/run_public_transfer.sh
```

Run the full eight-seed single-GPU reproduction used for the main benchmark:

```bash
bash experiments/scripts/run_public_single_gpu_8seed_qwen15b.sh
```

Run the multiseed pipeline directly:

```bash
python experiments/scripts/run_public_multiseed.py \
  --config experiments/configs/public_transfer_qwen25_15b.json \
  --seeds 20260320 20260321 20260322 20260323 20260324 20260325 20260326 20260327 \
  --train-gpus 0 \
  --eval-gpu 0 \
  --desired-checkpoints 10 \
  --enable-rrd \
  --allow-remote \
  --run-diagnostics \
  --diagnostic-max-samples 256 \
  --reuse-existing-scores \
  --reuse-existing-diagnostics \
  --force
```

## Data and outputs

- Prepared public benchmark files live under `experiments/data/public_reasoning/`
- Pilot data live under `experiments/data/arithshift/`
- Final summaries used by the paper live under `experiments/runs/final/`
- The claim-to-artifact mapping in the paper points to the JSON summaries used to
  build the reported tables and figures

## Compute notes

- The main paper reports the final eight-seed public-transfer benchmark on one
  RTX3090 GPU with 24GB memory
- The paper also reports selector-scoring overhead of about 13.3 minutes per
  seed for SCOPE and 4.8 minutes per seed for the diagnostic baseline family on
  the retained-checkpoint benchmark
- Fast configs are included for lighter-weight checks before full reruns
