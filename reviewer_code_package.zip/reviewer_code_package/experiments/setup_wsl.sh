#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

sudo apt update
sudo apt install -y python3.11 python3.11-venv python3-pip git

if [[ ! -d ".venv" ]]; then
  python3.11 -m venv .venv
fi

source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r experiments/requirements-wsl.txt

python - <<'PY'
import importlib
mods = ["torch", "transformers", "datasets", "peft", "bitsandbytes"]
status = {m: bool(importlib.util.find_spec(m)) for m in mods}
print(status)
PY
