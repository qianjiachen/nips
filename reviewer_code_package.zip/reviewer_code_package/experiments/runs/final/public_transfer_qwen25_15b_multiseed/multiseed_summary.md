# Multi-seed Summary: public_transfer_qwen25_15b

## Headline
- Seeds aggregated: 8.
- Seeds with non-monotonic OOD trajectories: 7 / 8.
- SCOPE mean OOD accuracy: 0.2097 +/- 0.0060.
- Last-checkpoint mean OOD accuracy: 0.2059 +/- 0.0040.
- Best-ID mean OOD accuracy: 0.2066 +/- 0.0038.

## Main Table

| Selector | ID Acc (mean+/-std, 95% CI) | OOD Acc (mean+/-std, 95% CI) | OOD Regret | SCOPE Score (mean+/-std) |
|----------|------------------------------|-------------------------------|------------|--------------------------|
| `best_ood` | 0.0892 +/- 0.0096, [0.0833, 0.1071] | 0.2116 +/- 0.0046, [0.2054, 0.2191] | 0.0000 | 0.5230 +/- 1.2310 |
| `best_id` | 0.0938 +/- 0.0140, [0.0839, 0.1214] | 0.2066 +/- 0.0038, [0.2004, 0.2100] | 0.0050 | -0.5093 +/- 1.0797 |
| `best_scope` | 0.0871 +/- 0.0090, [0.0800, 0.1043] | 0.2097 +/- 0.0060, [0.2025, 0.2191] | 0.0019 | 1.2344 +/- 0.5383 |
| `last` | 0.0933 +/- 0.0128, [0.0839, 0.1187] | 0.2059 +/- 0.0040, [0.2004, 0.2100] | 0.0056 | -0.8060 +/- 1.0214 |

## Paired Tests

- `scope_minus_last`: mean_diff=0.0037, 95%CI=[-0.0025, 0.0174], p(sign-flip)=0.2188.
- `scope_minus_best_id`: mean_diff=0.0031, 95%CI=[-0.0046, 0.0174], p(sign-flip)=0.4062.
- `scope_minus_oracle`: mean_diff=-0.0019, 95%CI=[-0.0050, 0.0000], p(sign-flip)=0.1250.

## Interpretation
- Use `best_scope` vs `last` as the main practical comparison.
- Use `best_scope` vs `best_id` to show ID-based selection is insufficient for OOD generalization.
- Use `best_ood` only as an oracle upper bound, not as a deployable selector.
