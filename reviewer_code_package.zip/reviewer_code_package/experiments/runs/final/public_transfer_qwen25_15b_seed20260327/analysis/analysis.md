# Result Analysis: public_transfer_qwen25_15b_seed20260327

## Main Findings
- Oracle OOD checkpoint: `checkpoint-92` with OOD accuracy 0.5814.
- Last checkpoint: `checkpoint-468` with OOD accuracy 0.5680.
- Best SCOPE checkpoint: `checkpoint-184` with score 1.7623.
- Best ID checkpoint: `checkpoint-460` with ID accuracy 0.1280.
- Non-monotonic OOD trajectory: `yes`.

## Selector Comparison
- SCOPE regret to oracle OOD checkpoint: 0.0041.
- SCOPE gain over last checkpoint on OOD: 0.0093.
- SCOPE gain over best-ID checkpoint on OOD: 0.0113.

## Table

| Checkpoint | Step | ID Acc | OOD Acc | PS | RRD | SCOPE |
|------------|------|--------|---------|----|-----|-------|
| `checkpoint-46` | 46 | 0.0780 | 0.5320 | 0.8009 | 0.4202 | -2.5861 |
| `checkpoint-92` | 92 | 0.0960 | 0.5814 | 0.6598 | 0.3499 | 0.4609 |
| `checkpoint-138` | 138 | 0.1020 | 0.5784 | 0.5694 | 0.4026 | 0.8567 |
| `checkpoint-184` | 184 | 0.1100 | 0.5773 | 0.5606 | 0.3533 | 1.7623 |
| `checkpoint-230` | 230 | 0.1120 | 0.5608 | 0.5714 | 0.4254 | 0.4665 |
| `checkpoint-276` | 276 | 0.1140 | 0.5639 | 0.5545 | 0.5515 | -1.3091 |
| `checkpoint-322` | 322 | 0.1160 | 0.5670 | 0.5554 | 0.4616 | 0.1106 |
| `checkpoint-368` | 368 | 0.1180 | 0.5660 | 0.5377 | 0.4292 | 0.8675 |
| `checkpoint-414` | 414 | 0.1200 | 0.5691 | 0.5568 | 0.4045 | 0.9984 |
| `checkpoint-460` | 460 | 0.1280 | 0.5660 | 0.5628 | 0.4981 | -0.5725 |
| `checkpoint-468` | 468 | 0.1140 | 0.5680 | 0.5606 | 0.5303 | -1.0552 |

## Figure Data
- Use `trajectory.csv` for checkpoint-vs-metric line plots.
- Plot `step` on the x-axis and `id_accuracy`, `ood_accuracy`, and `scope_score` on the y-axis.
