# Data Quality Report

- Dataset dir: `experiments\data\public_reasoning`

## Split Summary

| Split | Rows | Empty Prompt | Empty Answer | Dup Prompt Rows | Dup Sample ID Rows |
|-------|------|--------------|--------------|-----------------|--------------------|
| `train` | 2000 | 0 | 0 | 0 | 0 |
| `val` | 300 | 0 | 0 | 0 | 0 |
| `test_ood` | 400 | 0 | 200 | 199 | 0 |

## Overlap Checks

- prompt_overlap_train_val: 0
- prompt_overlap_train_test_ood: 0
- prompt_overlap_val_test_ood: 0
- sample_id_overlap_train_val: 0
- sample_id_overlap_train_test_ood: 0
- sample_id_overlap_val_test_ood: 0

## OOD Source Distribution

- asdiv: 200
- svamp: 200
