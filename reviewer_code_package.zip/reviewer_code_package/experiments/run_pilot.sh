#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

python "${ROOT_DIR}/experiments/scripts/generate_arithshift.py" --output-dir "${ROOT_DIR}/experiments/data/arithshift"
python "${ROOT_DIR}/experiments/scripts/build_probe_pool.py" \
  --input "${ROOT_DIR}/experiments/data/arithshift/train.jsonl" \
  --output "${ROOT_DIR}/experiments/data/arithshift/probe_pool.jsonl"
python "${ROOT_DIR}/experiments/scripts/train_sft.py" --config "${ROOT_DIR}/experiments/configs/arithshift_pilot.json"
python "${ROOT_DIR}/experiments/scripts/evaluate_checkpoints.py" \
  --base-model Qwen/Qwen2.5-0.5B \
  --checkpoint-dir "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot" \
  --id-file "${ROOT_DIR}/experiments/data/arithshift/val.jsonl" \
  --ood-file "${ROOT_DIR}/experiments/data/arithshift/test_ood.jsonl" \
  --output-file "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/eval_results.json" \
  --allow-remote
python "${ROOT_DIR}/experiments/scripts/score_checkpoints.py" \
  --base-model Qwen/Qwen2.5-0.5B \
  --checkpoint-dir "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot" \
  --probe-file "${ROOT_DIR}/experiments/data/arithshift/probe_pool.jsonl" \
  --output-file "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/checkpoint_scores.json" \
  --enable-rrd \
  --allow-remote
python "${ROOT_DIR}/experiments/scripts/summarize_pilot.py" \
  --eval-file "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/eval_results.json" \
  --score-file "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/checkpoint_scores.json" \
  --output-file "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/pilot_summary.md"
python "${ROOT_DIR}/experiments/scripts/analyze_results.py" \
  --eval-file "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/eval_results.json" \
  --score-file "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/checkpoint_scores.json" \
  --output-dir "${ROOT_DIR}/experiments/runs/intermediate/arithshift_pilot/analysis" \
  --tag arithshift_pilot
