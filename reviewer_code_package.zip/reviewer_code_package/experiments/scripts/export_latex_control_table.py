#!/usr/bin/env python3
"""Export control-selector summary JSON into a paper-ready LaTeX table."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


ORDER = ["last", "best_id", "fixed_fraction", "id_patience", "best_scope", "best_ood_oracle"]
LABEL = {
    "last": "Last",
    "best_id": "Best-ID",
    "fixed_fraction": "Fixed-70\\%",
    "id_patience": "ID-Patience",
    "best_scope": "SCOPE",
    "best_ood_oracle": "Oracle Best-OOD",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def fmt(value: Any) -> str:
    if value is None:
        return "--"
    if isinstance(value, float):
        if math.isnan(value):
            return "--"
        return f"{value:.4f}"
    return str(value)


def metric_with_std(row: dict[str, Any], mean_key: str, std_key: str) -> str:
    return f"{fmt(row.get(mean_key))} $\\pm$ {fmt(row.get(std_key))}"


def build_table(payload: dict[str, Any]) -> str:
    rows = {row["selector"]: row for row in payload.get("selectors", [])}
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\caption{Control-selector comparison without additional training runs.}")
    lines.append("\\label{tab:controls}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Selector & ID Acc & OOD Acc & Regret to Oracle \\\\")
    lines.append("\\midrule")
    for name in ORDER:
        row = rows.get(name)
        if row is None:
            continue
        lines.append(
            f"{LABEL.get(name, name)} & "
            f"{metric_with_std(row, 'id_accuracy_mean', 'id_accuracy_std')} & "
            f"{metric_with_std(row, 'ood_accuracy_mean', 'ood_accuracy_std')} & "
            f"{fmt(row.get('ood_regret_mean'))} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    payload = read_json(args.control_json)
    tex = build_table(payload)
    args.output_tex.parent.mkdir(parents=True, exist_ok=True)
    args.output_tex.write_text(tex, encoding="utf-8")
    print(json.dumps({"output_tex": str(args.output_tex.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
