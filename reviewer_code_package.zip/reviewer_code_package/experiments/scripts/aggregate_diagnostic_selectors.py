#!/usr/bin/env python3
"""Aggregate diagnostic-selector results across seeds."""

from __future__ import annotations

import argparse
import json
import math
from itertools import product
from pathlib import Path
from typing import Any


DEFAULT_ORDER = [
    "last",
    "best_id",
    "entropy_min",
    "perplexity_min",
    "cka_max",
    "svcca_max",
    "weight_rel_l2_min",
    "weight_cosine_max",
    "effective_rank_max",
    "top1_ratio_min",
    "best_scope",
    "best_ood_oracle",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selector-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-file", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else math.nan


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def percentile(sorted_vals: list[float], q: float) -> float:
    if not sorted_vals:
        return math.nan
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    idx = (len(sorted_vals) - 1) * q
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return sorted_vals[lo]
    frac = idx - lo
    return sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac


def ci95(values: list[float]) -> tuple[float, float]:
    if not values:
        return (math.nan, math.nan)
    if len(values) == 1:
        return (values[0], values[0])
    sorted_vals = sorted(values)
    return (percentile(sorted_vals, 0.025), percentile(sorted_vals, 0.975))


def paired_signflip_pvalue(diffs: list[float]) -> float:
    usable = [x for x in diffs if not math.isnan(x)]
    n = len(usable)
    if n == 0:
        return math.nan
    observed = abs(mean(usable))
    total = 0
    extreme = 0
    for signs in product([-1.0, 1.0], repeat=n):
        perm_mean = abs(mean([d * s for d, s in zip(usable, signs)]))
        total += 1
        if perm_mean >= observed - 1e-12:
            extreme += 1
    return extreme / total


def safe_seed(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def pack_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "checkpoint": row.get("checkpoint"),
        "id_accuracy": row.get("id_accuracy"),
        "ood_accuracy": row.get("ood_accuracy"),
        "metric_name": row.get("metric_name"),
        "metric_value": row.get("metric_value"),
    }


def build_selector_rows(seed_rows: dict[int, dict[str, dict[str, Any]]]) -> list[dict[str, Any]]:
    selectors: list[str] = []
    for name in DEFAULT_ORDER:
        if any(name in rows for rows in seed_rows.values()):
            selectors.append(name)
    for rows in seed_rows.values():
        for name in rows:
            if name not in selectors:
                selectors.append(name)

    out_rows: list[dict[str, Any]] = []
    for selector in selectors:
        id_vals: list[float] = []
        ood_vals: list[float] = []
        regret_vals: list[float] = []
        metric_vals: list[float] = []
        for seed in sorted(seed_rows):
            rows = seed_rows[seed]
            selector_row = rows.get(selector)
            if selector_row is None:
                continue
            if selector_row.get("id_accuracy") is not None:
                id_vals.append(float(selector_row["id_accuracy"]))
            if selector_row.get("ood_accuracy") is not None:
                ood_val = float(selector_row["ood_accuracy"])
                ood_vals.append(ood_val)
                oracle = rows.get("best_ood_oracle", {}).get("ood_accuracy")
                if oracle is not None:
                    regret_vals.append(float(oracle) - ood_val)
            if selector_row.get("metric_value") is not None:
                metric_vals.append(float(selector_row["metric_value"]))
        id_ci_low, id_ci_high = ci95(id_vals)
        ood_ci_low, ood_ci_high = ci95(ood_vals)
        regret_ci_low, regret_ci_high = ci95(regret_vals)
        out_rows.append(
            {
                "selector": selector,
                "n_seeds": len(ood_vals),
                "id_accuracy_mean": mean(id_vals),
                "id_accuracy_std": std(id_vals),
                "id_accuracy_ci95_low": id_ci_low,
                "id_accuracy_ci95_high": id_ci_high,
                "ood_accuracy_mean": mean(ood_vals),
                "ood_accuracy_std": std(ood_vals),
                "ood_accuracy_ci95_low": ood_ci_low,
                "ood_accuracy_ci95_high": ood_ci_high,
                "ood_regret_mean": mean(regret_vals),
                "ood_regret_std": std(regret_vals),
                "ood_regret_ci95_low": regret_ci_low,
                "ood_regret_ci95_high": regret_ci_high,
                "metric_value_mean": mean(metric_vals),
                "metric_value_std": std(metric_vals),
            }
        )
    return out_rows


def paired_diff(seed_rows: dict[int, dict[str, dict[str, Any]]], lhs: str, rhs: str) -> list[float]:
    diffs: list[float] = []
    for seed in sorted(seed_rows):
        rows = seed_rows[seed]
        lrow = rows.get(lhs)
        rrow = rows.get(rhs)
        if lrow is None or rrow is None:
            continue
        if lrow.get("ood_accuracy") is None or rrow.get("ood_accuracy") is None:
            continue
        diffs.append(float(lrow["ood_accuracy"]) - float(rrow["ood_accuracy"]))
    return diffs


def paired_stats(seed_rows: dict[int, dict[str, dict[str, Any]]], lhs: str, rhs: str) -> dict[str, float]:
    diffs = paired_diff(seed_rows, lhs, rhs)
    ci_low, ci_high = ci95(diffs)
    return {
        "n_pairs": len(diffs),
        "mean_diff_ood": mean(diffs),
        "ci95_low": ci_low,
        "ci95_high": ci_high,
        "p_value_signflip": paired_signflip_pvalue(diffs),
    }


def aggregate(seed_rows: dict[int, dict[str, dict[str, Any]]]) -> dict[str, Any]:
    rows = build_selector_rows(seed_rows)
    paired: dict[str, dict[str, float]] = {}
    if any("best_scope" in row_map for row_map in seed_rows.values()):
        for selector in DEFAULT_ORDER:
            if selector in {"best_scope", "best_ood_oracle"}:
                continue
            if any(selector in row_map for row_map in seed_rows.values()):
                paired[f"{selector}_minus_scope"] = paired_stats(seed_rows, selector, "best_scope")
    return {
        "num_seeds": len(seed_rows),
        "selectors": rows,
        "paired_tests": paired,
    }


def main() -> None:
    args = parse_args()
    seed_rows: dict[int, dict[str, dict[str, Any]]] = {}
    for path in args.selector_files:
        payload = read_json(path)
        seed = safe_seed(payload.get("seed"))
        if seed is None:
            continue
        row_map = seed_rows.setdefault(seed, {})
        for row in payload.get("selectors", []):
            row_map[str(row.get("selector"))] = pack_row(row)
    summary = aggregate(seed_rows)
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    args.output_file.write_text(json.dumps(summary, ensure_ascii=True, indent=2), encoding="utf-8")
    print(json.dumps({"output_file": str(args.output_file.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
