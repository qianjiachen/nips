#!/usr/bin/env python3
"""Fill key metric macros in the NeurIPS TeX draft from multiseed summary."""

from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--multiseed-json", type=Path, required=True)
    parser.add_argument("--tex-file", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, default=None)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def fmt(value: float) -> str:
    if value is None or math.isnan(value):
        return "TBD"
    return f"{value:.4f}"


def replace_macro(text: str, macro: str, value: str) -> str:
    pattern = rf"^\\newcommand\{{\\{re.escape(macro)}\}}\{{.*\}}$"
    replacement = rf"\\newcommand{{\\{macro}}}{{{value}}}"
    return re.sub(pattern, replacement, text, flags=re.MULTILINE)


def main() -> None:
    args = parse_args()
    payload = read_json(args.multiseed_json)
    selectors = {row["selector"]: row for row in payload.get("selectors", [])}
    paired = payload.get("paired_tests", {})

    scope = selectors.get("best_scope", {})
    last = selectors.get("last", {})
    best_id = selectors.get("best_id", {})
    nonmono = payload.get("non_monotonic_ood_seeds")
    total = payload.get("num_seeds")

    ood_gain_last = paired.get("scope_minus_last", {}).get("mean_diff_ood")
    ood_gain_best_id = paired.get("scope_minus_best_id", {}).get("mean_diff_ood")
    p_scope_last = paired.get("scope_minus_last", {}).get("p_value_signflip")
    p_scope_best_id = paired.get("scope_minus_best_id", {}).get("p_value_signflip")
    id_drop = None
    if scope.get("id_accuracy_mean") is not None and best_id.get("id_accuracy_mean") is not None:
        id_drop = float(scope["id_accuracy_mean"]) - float(best_id["id_accuracy_mean"])
    regret = scope.get("ood_regret_mean")

    text = args.tex_file.read_text(encoding="utf-8")
    text = replace_macro(text, "oodgainlast", fmt(ood_gain_last))
    text = replace_macro(text, "oodgainbestid", fmt(ood_gain_best_id))
    text = replace_macro(text, "iddrop", fmt(id_drop if id_drop is not None else math.nan))
    text = replace_macro(text, "regretoracle", fmt(float(regret) if regret is not None else math.nan))
    text = replace_macro(text, "pscopelast", fmt(float(p_scope_last) if p_scope_last is not None else math.nan))
    text = replace_macro(
        text,
        "pscopebestid",
        fmt(float(p_scope_best_id) if p_scope_best_id is not None else math.nan),
    )
    nonmono_text = "TBD" if nonmono is None or total is None else f"{nonmono}/{total}"
    text = replace_macro(text, "nonmono", nonmono_text)

    out_path = args.output_tex or args.tex_file
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text, encoding="utf-8")
    print(json.dumps({"output_tex": str(out_path.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
