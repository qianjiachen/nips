#!/usr/bin/env python3
"""Shared workspace paths for the reorganized research directory."""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]

PAPER_ROOT = ROOT / "paper" / "neurips2026"
MANUSCRIPT_DIR = PAPER_ROOT / "manuscript"
PAPER_ASSETS_DIR = PAPER_ROOT / "assets"
PAPER_TABLES_DIR = PAPER_ASSETS_DIR / "tables"
PAPER_FIGURES_DIR = PAPER_ASSETS_DIR / "figures"
PAPER_DIAGRAMS_DIR = PAPER_FIGURES_DIR / "diagrams"
PAPER_RESULTS_DIR = PAPER_FIGURES_DIR / "results"
PAPER_REVIEW_PAGES_DIR = PAPER_FIGURES_DIR / "review_pages"
PAPER_NOTES_DIR = PAPER_ROOT / "notes"

EXPERIMENTS_DIR = ROOT / "experiments"
SCRIPTS_DIR = EXPERIMENTS_DIR / "scripts"
CONFIGS_DIR = EXPERIMENTS_DIR / "configs"
DATA_DIR = EXPERIMENTS_DIR / "data"
RUNS_DIR = EXPERIMENTS_DIR / "runs"
FINAL_RUNS_DIR = RUNS_DIR / "final"
INTERMEDIATE_RUNS_DIR = RUNS_DIR / "intermediate"
DEBUG_RUNS_DIR = RUNS_DIR / "debug"
LOGS_DIR = EXPERIMENTS_DIR / "logs"

DOCS_DIR = ROOT / "docs"
ARCHIVE_DIR = ROOT / "archive"


def script_path(name: str) -> Path:
    return SCRIPTS_DIR / name
