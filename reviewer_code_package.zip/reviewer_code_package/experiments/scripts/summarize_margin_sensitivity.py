#!/usr/bin/env python3
"""Summarize plateau-margin sensitivity from existing per-seed trajectory analyses."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    parser.add_argument("--margins", type=float, nargs="+", default=[0.0, 0.25, 0.5, 0.75, 1.0])
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    if not values:
        return math.nan
    return sum(values) / len(values)


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def sort_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(rows, key=lambda row: int(row.get("step", 10**9)))


def select_best_ood(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda row: (float(row.get("ood_accuracy", -1.0)), -int(row.get("step", 10**9))))


def select_scope_plateau(rows: list[dict[str, Any]], margin_std: float) -> dict[str, Any]:
    valid = [row for row in rows if row.get("scope_score") is not None]
    if not valid:
        raise ValueError("No valid SCOPE rows found.")
    scores = [float(row["scope_score"]) for row in valid]
    max_score = max(scores)
    score_mean = mean(scores)
    score_var = sum((score - score_mean) ** 2 for score in scores) / len(scores)
    score_std = math.sqrt(score_var)
    threshold = max_score - margin_std * score_std
    eligible = [row for row in sort_rows(valid) if float(row["scope_score"]) >= threshold]
    if not eligible:
        return max(valid, key=lambda row: float(row["scope_score"]))
    return eligible[0]


def format_mean_std(mu: float, sigma: float) -> str:
    return f"{mu:.4f} $\\pm$ {sigma:.4f}"


def write_latex_table(path: Path, rows: list[dict[str, Any]]) -> None:
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(
        "\\caption{Sensitivity of the plateau margin coefficient on the final public-transfer benchmark "
        "(8 seeds). Margin $m$ selects the earliest checkpoint with "
        "$\\mathrm{SCOPE}_t \\geq \\max(\\mathrm{SCOPE}) - m\\cdot \\sigma_{\\text{traj}}$.}"
    )
    lines.append("\\label{tab:margin}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Margin $m$ & ID Acc & OOD Acc & Regret to Oracle \\\\")
    lines.append("\\midrule")
    for row in rows:
        label = f"{row['margin']:.2f}"
        if math.isclose(row["margin"], 0.0):
            label += " (argmax)"
        if math.isclose(row["margin"], 0.5):
            label += " (main)"
        lines.append(
            f"{label} & "
            f"{format_mean_std(row['id_accuracy_mean'], row['id_accuracy_std'])} & "
            f"{format_mean_std(row['ood_accuracy_mean'], row['ood_accuracy_std'])} & "
            f"{row['ood_regret_mean']:.4f} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    margins = sorted(set(args.margins))
    seeds: list[int] = []
    rows_summary: list[dict[str, Any]] = []

    per_seed_payloads = [read_json(path) for path in args.analysis_files]
    for margin in margins:
        picks: list[dict[str, Any]] = []
        regrets: list[float] = []
        for payload in per_seed_payloads:
            seed = int(payload["seed"])
            if margin == margins[0]:
                seeds.append(seed)
            rows = sort_rows(payload.get("rows", []))
            if not rows:
                continue
            selected = select_scope_plateau(rows, margin_std=margin)
            oracle = select_best_ood(rows)
            picks.append(selected)
            regrets.append(float(oracle["ood_accuracy"]) - float(selected["ood_accuracy"]))
        rows_summary.append(
            {
                "margin": margin,
                "n_seeds": len(picks),
                "id_accuracy_mean": mean([float(row["id_accuracy"]) for row in picks]),
                "id_accuracy_std": std([float(row["id_accuracy"]) for row in picks]),
                "ood_accuracy_mean": mean([float(row["ood_accuracy"]) for row in picks]),
                "ood_accuracy_std": std([float(row["ood_accuracy"]) for row in picks]),
                "ood_regret_mean": mean(regrets),
                "ood_regret_std": std(regrets),
            }
        )

    output = {
        "num_seeds": len(set(seeds)),
        "rows": rows_summary,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(output, ensure_ascii=True, indent=2), encoding="utf-8")
    write_latex_table(args.output_tex, rows_summary)
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
