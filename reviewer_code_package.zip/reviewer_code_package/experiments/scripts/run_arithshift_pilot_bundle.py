#!/usr/bin/env python3
"""Run the full ArithShift pilot pipeline for a single training seed."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from workspace_paths import CONFIGS_DIR, DATA_DIR, INTERMEDIATE_RUNS_DIR, ROOT, SCRIPTS_DIR


def script(name: str) -> str:
    return str(SCRIPTS_DIR / name)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-config", type=Path, default=CONFIGS_DIR / "arithshift_pilot.json")
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--prepare-data", action="store_true")
    parser.add_argument("--allow-remote", action="store_true")
    parser.add_argument("--enable-rrd", action="store_true")
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def run_cmd(cmd: list[str], cwd: Path) -> None:
    print("$", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=str(cwd), check=True)


def main() -> None:
    args = parse_args()
    root = ROOT
    config = read_json(args.base_config)

    output_dir = args.output_dir
    if output_dir is None:
        output_dir = INTERMEDIATE_RUNS_DIR / f"arithshift_pilot_seed{args.seed}"
    output_dir = output_dir.resolve()

    dataset_dir = Path(str(config.get("dataset_dir", DATA_DIR / "arithshift"))).resolve()
    train_file = Path(str(config.get("train_file", dataset_dir / "train.jsonl"))).resolve()
    validation_file = Path(str(config.get("validation_file", dataset_dir / "val.jsonl"))).resolve()
    ood_file = Path(str(config.get("ood_file", dataset_dir / "test_ood.jsonl"))).resolve()
    probe_pool_file = Path(str(config.get("probe_pool_file", dataset_dir / "probe_pool.jsonl"))).resolve()

    if args.prepare_data:
        run_cmd(
            [
                sys.executable,
                script("generate_arithshift.py"),
                "--output-dir",
                str(dataset_dir),
            ],
            root,
        )
        run_cmd(
            [
                sys.executable,
                script("build_probe_pool.py"),
                "--input",
                str(train_file),
                "--output",
                str(probe_pool_file),
            ],
            root,
        )

    missing = [path for path in [train_file, validation_file, ood_file, probe_pool_file] if not path.exists()]
    if missing:
        joined = ", ".join(str(path) for path in missing)
        raise FileNotFoundError(f"Required pilot inputs are missing: {joined}")

    resolved_config = dict(config)
    resolved_config["seed"] = args.seed
    resolved_config["output_dir"] = str(output_dir)
    resolved_config["train_file"] = str(train_file)
    resolved_config["validation_file"] = str(validation_file)
    resolved_config["ood_file"] = str(ood_file)
    resolved_config["probe_pool_file"] = str(probe_pool_file)
    resolved_config["dataset_dir"] = str(dataset_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    config_path = output_dir / "resolved_config.json"
    config_path.write_text(json.dumps(resolved_config, ensure_ascii=True, indent=2), encoding="utf-8")

    run_cmd(
        [
            sys.executable,
            script("train_sft.py"),
            "--config",
            str(config_path),
        ],
        root,
    )

    eval_cmd = [
        sys.executable,
        script("evaluate_checkpoints.py"),
        "--base-model",
        str(resolved_config["model_name_or_path"]),
        "--checkpoint-dir",
        str(output_dir),
        "--id-file",
        str(validation_file),
        "--ood-file",
        str(ood_file),
        "--output-file",
        str(output_dir / "eval_results.json"),
        "--seed-id",
        str(args.seed),
    ]
    if args.allow_remote:
        eval_cmd.append("--allow-remote")
    run_cmd(eval_cmd, root)

    score_cmd = [
        sys.executable,
        script("score_checkpoints.py"),
        "--base-model",
        str(resolved_config["model_name_or_path"]),
        "--checkpoint-dir",
        str(output_dir),
        "--probe-file",
        str(probe_pool_file),
        "--output-file",
        str(output_dir / "checkpoint_scores.json"),
        "--seed-id",
        str(args.seed),
    ]
    if args.enable_rrd:
        score_cmd.append("--enable-rrd")
    if args.allow_remote:
        score_cmd.append("--allow-remote")
    run_cmd(score_cmd, root)

    run_cmd(
        [
            sys.executable,
            script("summarize_pilot.py"),
            "--eval-file",
            str(output_dir / "eval_results.json"),
            "--score-file",
            str(output_dir / "checkpoint_scores.json"),
            "--output-file",
            str(output_dir / "pilot_summary.md"),
        ],
        root,
    )
    run_cmd(
        [
            sys.executable,
            script("analyze_results.py"),
            "--eval-file",
            str(output_dir / "eval_results.json"),
            "--score-file",
            str(output_dir / "checkpoint_scores.json"),
            "--output-dir",
            str(output_dir / "analysis"),
            "--tag",
            f"arithshift_seed{args.seed}",
        ],
        root,
    )

    print(
        json.dumps(
            {
                "seed": args.seed,
                "output_dir": str(output_dir),
                "analysis_json": str((output_dir / "analysis" / "analysis.json").resolve()),
                "summary_md": str((output_dir / "pilot_summary.md").resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
