#!/usr/bin/env python3
"""Run public-transfer multiseed training with parallel GPUs and unified evaluation."""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from workspace_paths import CONFIGS_DIR, INTERMEDIATE_RUNS_DIR, ROOT, SCRIPTS_DIR


CONFIG_CANDIDATES = sorted(CONFIGS_DIR.glob("public_transfer_*.json"))
DEFAULT_CONFIG = CONFIG_CANDIDATES[0] if CONFIG_CANDIDATES else (CONFIGS_DIR / "public_transfer.json")


def script(name: str) -> str:
    return str(SCRIPTS_DIR / name)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--workdir", type=Path, default=ROOT)
    parser.add_argument("--seeds", type=int, nargs="+", default=[20260320, 20260321, 20260322])
    parser.add_argument("--train-gpus", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--eval-gpu", type=int, default=3)
    parser.add_argument("--desired-checkpoints", type=int, default=10)
    parser.add_argument("--enable-rrd", action="store_true")
    parser.add_argument("--eval-max-samples", type=int, default=0)
    parser.add_argument(
        "--eval-sample-mode",
        choices=["head", "random", "stratified_source"],
        default="head",
    )
    parser.add_argument("--score-max-samples", type=int, default=0)
    parser.add_argument("--reuse-existing-scores", action="store_true")
    parser.add_argument("--run-diagnostics", action="store_true")
    parser.add_argument("--diagnostic-max-samples", type=int, default=0)
    parser.add_argument("--reuse-existing-diagnostics", action="store_true")
    parser.add_argument("--skip-data-prep", action="store_true")
    parser.add_argument("--eval-only", action="store_true")
    parser.add_argument("--allow-remote", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def run_cmd(cmd: list[str], cwd: Path, env: dict[str, str] | None = None) -> None:
    print(f"[cmd] {' '.join(cmd)}")
    subprocess.run(cmd, cwd=str(cwd), env=env, check=True)


def pid_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="utf-8")


def count_jsonl_rows(path: Path) -> int:
    count = 0
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                count += 1
    return count


def build_seed_config(
    base_config: dict[str, Any],
    *,
    seed: int,
    desired_checkpoints: int,
    train_rows: int,
    output_dir: Path,
) -> dict[str, Any]:
    cfg = dict(base_config)
    cfg["seed"] = seed
    cfg["output_dir"] = str(output_dir)
    per_device_train_batch_size = int(cfg["per_device_train_batch_size"])
    gradient_accumulation_steps = int(cfg["gradient_accumulation_steps"])
    epochs = float(cfg["num_train_epochs"])
    effective_batch = per_device_train_batch_size * gradient_accumulation_steps
    steps_per_epoch = math.ceil(train_rows / effective_batch)
    total_steps = max(1, int(math.ceil(steps_per_epoch * epochs)))
    save_steps = max(1, total_steps // max(1, desired_checkpoints))
    cfg["save_steps"] = save_steps
    cfg["eval_steps"] = save_steps
    cfg["save_strategy"] = "steps"
    cfg["notes"] = list(cfg.get("notes", [])) + [
        f"autotuned_total_steps={total_steps}",
        f"autotuned_save_steps={save_steps}",
        f"desired_checkpoints={desired_checkpoints}",
    ]
    return cfg


def spawn_train(
    *,
    cwd: Path,
    config_path: Path,
    gpu_id: int,
    log_path: Path,
) -> subprocess.Popen[str]:
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    env["PYTHONUNBUFFERED"] = "1"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    handle = log_path.open("w", encoding="utf-8")
    cmd = [sys.executable, script("train_sft.py"), "--config", str(config_path)]
    return subprocess.Popen(cmd, cwd=str(cwd), env=env, stdout=handle, stderr=subprocess.STDOUT, text=True)


def run_eval_pipeline(
    *,
    cwd: Path,
    base_model: str,
    checkpoint_dir: Path,
    id_file: Path,
    ood_file: Path,
    probe_file: Path,
    output_dir: Path,
    eval_gpu: int,
    seed: int,
    enable_rrd: bool,
    tag_prefix: str,
    allow_remote: bool,
    eval_max_samples: int,
    eval_sample_mode: str,
    score_max_samples: int,
    reuse_existing_scores: bool,
    run_diagnostics: bool,
    diagnostic_max_samples: int,
    reuse_existing_diagnostics: bool,
) -> dict[str, Path | None]:
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(eval_gpu)
    env["PYTHONUNBUFFERED"] = "1"
    eval_file = output_dir / "eval_results.json"
    score_file = output_dir / "checkpoint_scores.json"
    analysis_dir = output_dir / "analysis"
    analysis_json = analysis_dir / "analysis.json"
    diagnostic_metrics_file = analysis_dir / "diagnostic_metrics.json"
    diagnostic_selector_file = analysis_dir / "diagnostic_selectors.json"

    run_cmd(
        [
            sys.executable,
                    script("evaluate_checkpoints.py"),
            "--base-model",
            base_model,
            "--checkpoint-dir",
            str(checkpoint_dir),
            "--id-file",
            str(id_file),
            "--ood-file",
            str(ood_file),
            "--output-file",
            str(eval_file),
            "--max-samples",
            str(eval_max_samples),
            "--sample-mode",
            str(eval_sample_mode),
            "--seed-id",
            str(seed),
            "--tokenizer-path",
            str(checkpoint_dir),
            *([] if not allow_remote else ["--allow-remote"]),
        ],
        cwd,
        env,
    )
    if reuse_existing_scores and score_file.exists():
        print(f"[reuse-score] seed={seed} score_file={score_file}")
    else:
        score_cmd = [
            sys.executable,
                    script("score_checkpoints.py"),
            "--base-model",
            base_model,
            "--checkpoint-dir",
            str(checkpoint_dir),
            "--probe-file",
            str(probe_file),
            "--output-file",
            str(score_file),
            "--max-samples",
            str(score_max_samples),
            "--seed-id",
            str(seed),
            "--tokenizer-path",
            str(checkpoint_dir),
        ]
        if enable_rrd:
            score_cmd.append("--enable-rrd")
        if allow_remote:
            score_cmd.append("--allow-remote")
        run_cmd(score_cmd, cwd, env)
    run_cmd(
        [
            sys.executable,
                    script("analyze_results.py"),
            "--eval-file",
            str(eval_file),
            "--score-file",
            str(score_file),
            "--output-dir",
            str(analysis_dir),
            "--tag",
            f"{tag_prefix}_seed{seed}",
        ],
        cwd,
        env,
    )
    if run_diagnostics:
        if (
            reuse_existing_diagnostics
            and diagnostic_metrics_file.exists()
            and diagnostic_selector_file.exists()
        ):
            print(f"[reuse-diagnostic] seed={seed} selector_file={diagnostic_selector_file}")
        else:
            run_cmd(
                [
                    sys.executable,
                    script("score_checkpoint_diagnostics.py"),
                    "--base-model",
                    base_model,
                    "--checkpoint-dir",
                    str(checkpoint_dir),
                    "--probe-file",
                    str(probe_file),
                    "--output-file",
                    str(diagnostic_metrics_file),
                    "--max-samples",
                    str(diagnostic_max_samples),
                    "--tokenizer-path",
                    str(checkpoint_dir),
                    *([] if not allow_remote else ["--allow-remote"]),
                ],
                cwd,
                env,
            )
            run_cmd(
                [
                    sys.executable,
                    script("derive_diagnostic_selectors.py"),
                    "--eval-file",
                    str(eval_file),
                    "--diagnostic-file",
                    str(diagnostic_metrics_file),
                    "--analysis-file",
                    str(analysis_json),
                    "--output-file",
                    str(diagnostic_selector_file),
                ],
                cwd,
                env,
            )
    return {
        "analysis_json": analysis_json,
        "score_file": score_file,
        "diagnostic_metrics_file": diagnostic_metrics_file if diagnostic_metrics_file.exists() else None,
        "diagnostic_selector_file": diagnostic_selector_file if diagnostic_selector_file.exists() else None,
    }


def main() -> None:
    args = parse_args()
    cwd = args.workdir.resolve()
    base_config = read_json((cwd / args.config).resolve())
    experiment_tag = Path(args.config).stem
    base_model = str(base_config["model_name_or_path"])
    dataset_dir = cwd / str(base_config["dataset_dir"])
    train_file = cwd / str(base_config["train_file"])
    val_file = cwd / str(base_config["validation_file"])
    ood_file = cwd / str(base_config["ood_file"])
    probe_file = cwd / str(base_config["probe_pool_file"])
    output_root = INTERMEDIATE_RUNS_DIR
    allow_remote = bool(args.allow_remote)
    output_root.mkdir(parents=True, exist_ok=True)
    lock_path = output_root / ".run_public_multiseed.lock"
    if lock_path.exists() and not args.force:
        lock_payload = read_json(lock_path)
        lock_pid = int(lock_payload.get("pid", -1))
        if pid_exists(lock_pid):
            raise RuntimeError(
                f"Another run_public_multiseed instance is active (pid={lock_pid}). "
                "Use --force only if you intentionally want to bypass the lock."
            )
    write_json(lock_path, {"pid": os.getpid(), "tag": experiment_tag})

    try:
        if not args.train_gpus:
            raise ValueError("At least one training GPU id is required.")

        if not args.skip_data_prep:
            run_cmd(
                [sys.executable, script("prepare_public_data.py"), "--output-dir", str(dataset_dir)],
                cwd,
            )
            run_cmd(
                [
                    sys.executable,
                    script("build_probe_pool.py"),
                    "--input",
                    str(train_file),
                    "--output",
                    str(probe_file),
                    "--sample-size",
                    "384",
                ],
                cwd,
            )

        quality_dir = output_root / "data_quality"
        run_cmd(
            [
                sys.executable,
                script("data_quality_report.py"),
                "--dataset-dir",
                str(dataset_dir),
                "--output-json",
                str(quality_dir / "public_reasoning_quality.json"),
                "--output-md",
                str(quality_dir / "public_reasoning_quality.md"),
            ],
            cwd,
        )

        train_rows = count_jsonl_rows(train_file)
        output_dir_by_seed: dict[int, Path] = {}
        cfg_path_by_seed: dict[int, Path] = {}
        analysis_paths: list[Path] = []
        score_paths: list[Path] = []
        control_paths: list[Path] = []
        diagnostic_metric_paths: list[Path] = []
        diagnostic_selector_paths: list[Path] = []
        eval_failed: list[int] = []

        if args.eval_only:
            for seed in args.seeds:
                output_dir_by_seed[seed] = output_root / f"{experiment_tag}_seed{seed}"
        else:
            active_trains: dict[int, dict[str, Any]] = {}
            eval_queue: list[int] = []
            done_training: set[int] = set()
            failed_training: set[int] = set()
            pending_seeds = list(args.seeds)

            for seed in args.seeds:
                output_dir = output_root / f"{experiment_tag}_seed{seed}"
                cfg = build_seed_config(
                    base_config,
                    seed=seed,
                    desired_checkpoints=args.desired_checkpoints,
                    train_rows=train_rows,
                    output_dir=output_dir,
                )
                cfg_path = output_root / "runtime_configs" / f"{experiment_tag}_seed{seed}.json"
                write_json(cfg_path, cfg)
                output_dir_by_seed[seed] = output_dir
                cfg_path_by_seed[seed] = cfg_path
            while pending_seeds or active_trains or eval_queue:
                progress_made = False

                for seed, info in list(active_trains.items()):
                    proc = info["process"]
                    ret = proc.poll()
                    if ret is None:
                        continue
                    progress_made = True
                    del active_trains[seed]
                    if ret == 0:
                        done_training.add(seed)
                        eval_queue.append(seed)
                        print(f"[train-done] seed={seed}")
                    else:
                        failed_training.add(seed)
                        print(f"[train-failed] seed={seed} code={ret}")

                busy_train_gpus = {int(info["gpu_id"]) for info in active_trains.values()}
                if eval_queue and args.eval_gpu not in busy_train_gpus:
                    seed = eval_queue.pop(0)
                    try:
                        eval_outputs = run_eval_pipeline(
                            cwd=cwd,
                            base_model=base_model,
                            checkpoint_dir=output_dir_by_seed[seed],
                            id_file=val_file,
                            ood_file=ood_file,
                            probe_file=probe_file,
                            output_dir=output_dir_by_seed[seed],
                            eval_gpu=args.eval_gpu,
                            seed=seed,
                            enable_rrd=args.enable_rrd,
                            tag_prefix=experiment_tag,
                            allow_remote=allow_remote,
                            eval_max_samples=args.eval_max_samples,
                            eval_sample_mode=args.eval_sample_mode,
                            score_max_samples=args.score_max_samples,
                            reuse_existing_scores=args.reuse_existing_scores,
                            run_diagnostics=args.run_diagnostics,
                            diagnostic_max_samples=args.diagnostic_max_samples,
                            reuse_existing_diagnostics=args.reuse_existing_diagnostics,
                        )
                        analysis_paths.append(Path(eval_outputs["analysis_json"]))
                        score_paths.append(Path(eval_outputs["score_file"]))
                        if eval_outputs["diagnostic_metrics_file"] is not None:
                            diagnostic_metric_paths.append(Path(eval_outputs["diagnostic_metrics_file"]))
                        if eval_outputs["diagnostic_selector_file"] is not None:
                            diagnostic_selector_paths.append(Path(eval_outputs["diagnostic_selector_file"]))
                        print(f"[eval-done] seed={seed}")
                        progress_made = True
                    except Exception as exc:  # noqa: BLE001
                        eval_failed.append(seed)
                        print(f"[eval-failed] seed={seed} err={exc}")
                        progress_made = True
                    continue

                busy_train_gpus = {int(info["gpu_id"]) for info in active_trains.values()}
                for gpu_id in args.train_gpus:
                    if not pending_seeds or gpu_id in busy_train_gpus:
                        continue
                    if eval_queue and gpu_id == args.eval_gpu:
                        continue
                    seed = pending_seeds.pop(0)
                    log_path = output_dir_by_seed[seed] / "train.log"
                    proc = spawn_train(cwd=cwd, config_path=cfg_path_by_seed[seed], gpu_id=gpu_id, log_path=log_path)
                    active_trains[seed] = {"process": proc, "gpu_id": gpu_id}
                    print(f"[train-started] seed={seed} gpu={gpu_id} pid={proc.pid}")
                    progress_made = True

                if not progress_made:
                    time.sleep(15)

            if failed_training:
                raise RuntimeError(f"Some training runs failed: {sorted(failed_training)}")
        if args.eval_only:
            for seed in args.seeds:
                try:
                    eval_outputs = run_eval_pipeline(
                        cwd=cwd,
                        base_model=base_model,
                        checkpoint_dir=output_dir_by_seed[seed],
                        id_file=val_file,
                        ood_file=ood_file,
                        probe_file=probe_file,
                        output_dir=output_dir_by_seed[seed],
                        eval_gpu=args.eval_gpu,
                        seed=seed,
                        enable_rrd=args.enable_rrd,
                        tag_prefix=experiment_tag,
                        allow_remote=allow_remote,
                        eval_max_samples=args.eval_max_samples,
                        eval_sample_mode=args.eval_sample_mode,
                        score_max_samples=args.score_max_samples,
                        reuse_existing_scores=args.reuse_existing_scores,
                        run_diagnostics=args.run_diagnostics,
                        diagnostic_max_samples=args.diagnostic_max_samples,
                        reuse_existing_diagnostics=args.reuse_existing_diagnostics,
                    )
                    analysis_paths.append(Path(eval_outputs["analysis_json"]))
                    score_paths.append(Path(eval_outputs["score_file"]))
                    if eval_outputs["diagnostic_metrics_file"] is not None:
                        diagnostic_metric_paths.append(Path(eval_outputs["diagnostic_metrics_file"]))
                    if eval_outputs["diagnostic_selector_file"] is not None:
                        diagnostic_selector_paths.append(Path(eval_outputs["diagnostic_selector_file"]))
                    print(f"[eval-done] seed={seed}")
                except Exception as exc:  # noqa: BLE001
                    eval_failed.append(seed)
                    print(f"[eval-failed] seed={seed} err={exc}")

        if eval_failed:
            raise RuntimeError(f"Evaluation failed on seeds: {sorted(set(eval_failed))}")
        if len(analysis_paths) != len(args.seeds):
            raise RuntimeError("Not all seeds produced analysis artifacts.")

        for seed in args.seeds:
            eval_file = output_dir_by_seed[seed] / "eval_results.json"
            control_file = output_dir_by_seed[seed] / "control_selectors.json"
            run_cmd(
                [
                    sys.executable,
                script("derive_control_selectors.py"),
                    "--eval-file",
                    str(eval_file),
                    "--output-file",
                    str(control_file),
                ],
                cwd,
            )
            control_paths.append(control_file)

        aggregate_dir = output_root / f"{experiment_tag}_multiseed"
        run_cmd(
            [
                sys.executable,
                script("aggregate_multiseed.py"),
                "--analysis-files",
                *[str(path) for path in analysis_paths],
                "--output-dir",
                str(aggregate_dir),
                "--tag",
                experiment_tag,
            ],
            cwd,
        )
        run_cmd(
            [
                sys.executable,
                script("plot_results.py"),
                "--multiseed-json",
                str(aggregate_dir / "multiseed_summary.json"),
                "--output-dir",
                str(aggregate_dir),
                "--tag",
                experiment_tag,
            ],
            cwd,
        )
        control_summary_path = aggregate_dir / "control_selector_summary.json"
        run_cmd(
            [
                sys.executable,
                script("aggregate_control_selectors.py"),
                "--control-files",
                *[str(path) for path in control_paths],
                "--analysis-files",
                *[str(path) for path in analysis_paths],
                "--output-file",
                str(control_summary_path),
            ],
            cwd,
        )
        selector_table_path = aggregate_dir / "selector_table.tex"
        run_cmd(
            [
                sys.executable,
                script("export_latex_tables.py"),
                "--multiseed-json",
                str(aggregate_dir / "multiseed_summary.json"),
                "--output-tex",
                str(selector_table_path),
            ],
            cwd,
        )
        control_table_path = aggregate_dir / "control_selector_table.tex"
        run_cmd(
            [
                sys.executable,
                script("export_latex_control_table.py"),
                "--control-json",
                str(control_summary_path),
                "--output-tex",
                str(control_table_path),
            ],
            cwd,
        )

        diagnostic_summary_path = None
        diagnostic_table_path = None
        if args.run_diagnostics:
            if len(diagnostic_selector_paths) != len(args.seeds):
                raise RuntimeError("Not all seeds produced diagnostic selector artifacts.")
            diagnostic_summary_path = aggregate_dir / "diagnostic_selector_summary.json"
            run_cmd(
                [
                    sys.executable,
                script("aggregate_diagnostic_selectors.py"),
                    "--selector-files",
                    *[str(path) for path in diagnostic_selector_paths],
                    "--output-file",
                    str(diagnostic_summary_path),
                ],
                cwd,
            )
            diagnostic_table_path = aggregate_dir / "diagnostic_selector_table.tex"
            run_cmd(
                [
                    sys.executable,
                script("export_latex_diagnostic_table.py"),
                    "--diagnostic-json",
                    str(diagnostic_summary_path),
                    "--output-tex",
                    str(diagnostic_table_path),
                ],
                cwd,
            )

        id_budget_summary_path = aggregate_dir / "id_budget_selector_summary.json"
        id_budget_table_path = aggregate_dir / "id_budget_selector_table.tex"
        run_cmd(
            [
                sys.executable,
                script("summarize_id_budget_selectors.py"),
                "--analysis-files",
                *[str(path) for path in analysis_paths],
                "--output-json",
                str(id_budget_summary_path),
                "--output-tex",
                str(id_budget_table_path),
            ],
            cwd,
        )

        scope_cost_summary_path = aggregate_dir / "scope_cost_summary.json"
        scope_cost_table_path = aggregate_dir / "scope_cost_table.tex"
        scope_cost_cmd = [
            sys.executable,
                script("summarize_scope_cost.py"),
            "--label",
            experiment_tag,
            "--probe-file",
            str(probe_file),
            "--analysis-files",
            *[str(path) for path in analysis_paths],
            "--scope-score-files",
            *[str(path) for path in score_paths],
            "--output-json",
            str(scope_cost_summary_path),
            "--output-tex",
            str(scope_cost_table_path),
        ]
        if diagnostic_metric_paths:
            scope_cost_cmd.extend(["--diagnostic-files", *[str(path) for path in diagnostic_metric_paths]])
        run_cmd(scope_cost_cmd, cwd)

        print(
            json.dumps(
                {
                    "analysis_files": [str(path.resolve()) for path in analysis_paths],
                    "score_files": [str(path.resolve()) for path in score_paths],
                    "diagnostic_selector_files": [str(path.resolve()) for path in diagnostic_selector_paths],
                    "multiseed_dir": str(aggregate_dir.resolve()),
                    "control_summary_json": str(control_summary_path.resolve()),
                    "diagnostic_summary_json": None if diagnostic_summary_path is None else str(diagnostic_summary_path.resolve()),
                    "scope_cost_summary_json": str(scope_cost_summary_path.resolve()),
                    "selector_table_tex": str(selector_table_path.resolve()),
                    "control_table_tex": str(control_table_path.resolve()),
                    "diagnostic_table_tex": None if diagnostic_table_path is None else str(diagnostic_table_path.resolve()),
                    "id_budget_summary_json": str(id_budget_summary_path.resolve()),
                    "id_budget_table_tex": str(id_budget_table_path.resolve()),
                    "scope_cost_table_tex": str(scope_cost_table_path.resolve()),
                    "runtime_configs": [str(path.resolve()) for path in cfg_path_by_seed.values()],
                },
                ensure_ascii=True,
                indent=2,
            )
        )
    finally:
        if lock_path.exists():
            lock_payload = read_json(lock_path)
            if int(lock_payload.get("pid", -1)) == os.getpid():
                lock_path.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
