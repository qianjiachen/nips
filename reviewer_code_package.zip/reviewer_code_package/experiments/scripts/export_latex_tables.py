#!/usr/bin/env python3
"""Export result JSON files into paper-ready LaTeX tables."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--multiseed-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def fmt(value: Any) -> str:
    if value is None:
        return "--"
    if isinstance(value, float):
        if math.isnan(value):
            return "--"
        return f"{value:.4f}"
    return str(value)


def selector_label(name: str) -> str:
    mapping = {
        "best_scope": "SCOPE",
        "last": "Last",
        "best_id": "Best-ID",
        "best_ood": "Oracle",
    }
    return mapping.get(name, name)


def build_table(payload: dict[str, Any]) -> str:
    rows = payload.get("selectors", [])
    paired = payload.get("paired_tests", {})
    p_last = fmt(paired.get("scope_minus_last", {}).get("p_value_signflip"))
    p_best_id = fmt(paired.get("scope_minus_best_id", {}).get("p_value_signflip"))
    order = ["last", "best_id", "best_scope", "best_ood"]
    row_map = {row["selector"]: row for row in rows}
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(
        "\\caption{Selector comparison across seeds. "
        + f"Paired sign-flip p-values: SCOPE-Last={p_last}, SCOPE-Best-ID={p_best_id}."
        + "}"
    )
    lines.append("\\label{tab:selector-main}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Selector & ID Acc & OOD Acc & Regret to Oracle \\\\")
    lines.append("\\midrule")
    for name in order:
        if name not in row_map:
            continue
        row = row_map[name]
        lines.append(
            f"{selector_label(name)} & {fmt(row.get('id_accuracy_mean'))} "
            f"$\\pm$ {fmt(row.get('id_accuracy_std'))} "
            f"[{fmt(row.get('id_accuracy_ci95_low'))}, {fmt(row.get('id_accuracy_ci95_high'))}] & "
            f"{fmt(row.get('ood_accuracy_mean'))} $\\pm$ {fmt(row.get('ood_accuracy_std'))} "
            f"[{fmt(row.get('ood_accuracy_ci95_low'))}, {fmt(row.get('ood_accuracy_ci95_high'))}] & "
            f"{fmt(row.get('ood_regret_mean'))} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    payload = read_json(args.multiseed_json)
    tex = build_table(payload)
    args.output_tex.parent.mkdir(parents=True, exist_ok=True)
    args.output_tex.write_text(tex, encoding="utf-8")
    print(json.dumps({"output_tex": str(args.output_tex.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
