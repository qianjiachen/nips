#!/usr/bin/env python3
"""Derive selector-level baselines from unsupervised checkpoint diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


SELECTOR_SPECS = [
    ("entropy_min", "entropy", "min"),
    ("perplexity_min", "perplexity", "min"),
    ("cka_max", "cka_to_ref", "max"),
    ("svcca_max", "svcca_to_ref", "max"),
    ("weight_rel_l2_min", "weight_rel_l2", "min"),
    ("weight_cosine_max", "weight_cosine", "max"),
    ("effective_rank_max", "effective_rank", "max"),
    ("top1_ratio_min", "top1_ratio", "min"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eval-file", type=Path, required=True)
    parser.add_argument("--diagnostic-file", type=Path, required=True)
    parser.add_argument("--analysis-file", type=Path, default=None)
    parser.add_argument("--output-file", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def checkpoint_step(name: str) -> int:
    if name.startswith("checkpoint-"):
        try:
            return int(name.split("-", 1)[1])
        except ValueError:
            return 10**9
    return 10**9


def select_last(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (checkpoint_step(r["checkpoint"]), r["checkpoint"]))


def select_best_id(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (r.get("id_accuracy", -1.0), -checkpoint_step(r["checkpoint"])))


def select_best_ood(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (r.get("ood_accuracy", -1.0), -checkpoint_step(r["checkpoint"])))


def pack(selector: str, row: dict[str, Any], oracle_ood: float, metric_name: str | None = None, metric_value: float | None = None) -> dict[str, Any]:
    return {
        "selector": selector,
        "checkpoint": row["checkpoint"],
        "id_accuracy": row.get("id_accuracy"),
        "ood_accuracy": row.get("ood_accuracy"),
        "ood_regret": (oracle_ood - row.get("ood_accuracy", 0.0)) if row.get("ood_accuracy") is not None else None,
        "metric_name": metric_name,
        "metric_value": metric_value,
    }


def choose_by_metric(
    selector_name: str,
    metric_name: str,
    direction: str,
    eval_by_checkpoint: dict[str, dict[str, Any]],
    diag_by_checkpoint: dict[str, dict[str, Any]],
    oracle_ood: float,
) -> dict[str, Any] | None:
    candidates: list[tuple[float, int, dict[str, Any]]] = []
    for checkpoint, diag_row in diag_by_checkpoint.items():
        eval_row = eval_by_checkpoint.get(checkpoint)
        if eval_row is None:
            continue
        value = diag_row.get(metric_name)
        if value is None:
            continue
        try:
            score = float(value)
        except (TypeError, ValueError):
            continue
        step = checkpoint_step(checkpoint)
        tie_break = -step if direction == "max" else step
        candidates.append((score, tie_break, eval_row))
    if not candidates:
        return None
    if direction == "max":
        _, _, row = max(candidates, key=lambda item: (item[0], item[1]))
    else:
        _, _, row = min(candidates, key=lambda item: (item[0], item[1]))
    metric_value = diag_by_checkpoint[row["checkpoint"]].get(metric_name)
    return pack(selector_name, row, oracle_ood, metric_name=metric_name, metric_value=metric_value)


def main() -> None:
    args = parse_args()
    eval_payload = read_json(args.eval_file)
    rows = eval_payload.get("results", [])
    if not rows:
        raise ValueError("No checkpoint rows found in eval file.")
    diag_payload = read_json(args.diagnostic_file)
    diag_rows = diag_payload.get("results", [])
    if not diag_rows:
        raise ValueError("No diagnostic rows found in diagnostic file.")

    eval_by_checkpoint = {row["checkpoint"]: row for row in rows}
    diag_by_checkpoint = {row["checkpoint"]: row for row in diag_rows}

    last = select_last(rows)
    best_id = select_best_id(rows)
    best_ood = select_best_ood(rows)
    oracle_ood = float(best_ood.get("ood_accuracy", 0.0))

    selectors = [
        pack("last", last, oracle_ood),
        pack("best_id", best_id, oracle_ood),
        pack("best_ood_oracle", best_ood, oracle_ood),
    ]

    if args.analysis_file is not None and args.analysis_file.exists():
        analysis_payload = read_json(args.analysis_file)
        if analysis_payload.get("best_scope_checkpoint") is not None:
            selectors.append(pack("best_scope", analysis_payload["best_scope_checkpoint"], oracle_ood))

    for selector_name, metric_name, direction in SELECTOR_SPECS:
        picked = choose_by_metric(
            selector_name,
            metric_name,
            direction,
            eval_by_checkpoint,
            diag_by_checkpoint,
            oracle_ood,
        )
        if picked is not None:
            selectors.append(picked)

    payload = {
        "seed": eval_payload.get("seed"),
        "selectors": selectors,
        "meta": {
            "diagnostic_file": str(args.diagnostic_file.resolve()),
            "analysis_file": None if args.analysis_file is None else str(args.analysis_file.resolve()),
            "selector_specs": [
                {"selector": selector, "metric": metric, "direction": direction}
                for selector, metric, direction in SELECTOR_SPECS
            ],
        },
    }
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    args.output_file.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8")
    print(json.dumps({"output_file": str(args.output_file.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
