#!/usr/bin/env python3
"""Export a small cross-backbone selector comparison table from multiseed summaries."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary-a", type=Path, required=True)
    parser.add_argument("--label-a", type=str, required=True)
    parser.add_argument("--summary-b", type=Path, required=True)
    parser.add_argument("--label-b", type=str, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def selector_map(summary: dict[str, Any]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for row in summary.get("selectors", []):
        name = row.get("selector")
        if isinstance(name, str):
            out[name] = row
    return out


def backbone_row(label: str, summary: dict[str, Any]) -> dict[str, Any]:
    smap = selector_map(summary)
    best_scope = smap["best_scope"]
    last = smap["last"]
    best_id = smap["best_id"]
    paired = summary.get("paired_tests", {}).get("scope_minus_last", {})
    return {
        "label": label,
        "n_seeds": int(summary.get("num_seeds", 0)),
        "non_monotonic_ood_seeds": int(summary.get("non_monotonic_ood_seeds", 0)),
        "last_ood_mean": float(last["ood_accuracy_mean"]),
        "last_ood_std": float(last["ood_accuracy_std"]),
        "scope_ood_mean": float(best_scope["ood_accuracy_mean"]),
        "scope_ood_std": float(best_scope["ood_accuracy_std"]),
        "scope_minus_last_mean": float(paired.get("mean_diff_ood", 0.0)),
        "scope_minus_last_p": float(paired.get("p_value_signflip", 1.0)),
        "scope_id_mean": float(best_scope["id_accuracy_mean"]),
        "best_id_id_mean": float(best_id["id_accuracy_mean"]),
        "id_drop_vs_best_id": float(best_scope["id_accuracy_mean"]) - float(best_id["id_accuracy_mean"]),
        "scope_regret_mean": float(best_scope["ood_regret_mean"]),
    }


def fmt_pm(mu: float, sigma: float) -> str:
    return f"{mu:.4f} $\\pm$ {sigma:.4f}"


def fmt_signed(v: float) -> str:
    return f"{v:+.4f}"


def write_tex(path: Path, rows: list[dict[str, Any]]) -> None:
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\caption{Small-scale cross-backbone external-validity check (3 seeds per backbone).}")
    lines.append("\\label{tab:cross-backbone}")
    lines.append("\\begin{tabular}{lcccc}")
    lines.append("\\toprule")
    lines.append("Backbone & Seeds & Last OOD & SCOPE OOD & $\\Delta$OOD (SCOPE-Last) \\\\")
    lines.append("\\midrule")
    for row in rows:
        lines.append(
            f"{row['label']} & "
            f"{row['n_seeds']} & "
            f"{fmt_pm(row['last_ood_mean'], row['last_ood_std'])} & "
            f"{fmt_pm(row['scope_ood_mean'], row['scope_ood_std'])} & "
            f"{fmt_signed(row['scope_minus_last_mean'])} ($p={row['scope_minus_last_p']:.4f}$) \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    a = read_json(args.summary_a)
    b = read_json(args.summary_b)
    rows = [backbone_row(args.label_a, a), backbone_row(args.label_b, b)]
    out = {
        "rows": rows,
        "notes": {
            "metric": "Checkpoint selector performance within each backbone.",
            "test": "Paired sign-flip on per-seed OOD deltas (SCOPE minus Last).",
        },
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(out, ensure_ascii=True, indent=2), encoding="utf-8")
    write_tex(args.output_tex, rows)
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
