#!/usr/bin/env python3
"""Prepare public reasoning datasets for the main transfer track."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path

from workspace_paths import DATA_DIR
from typing import Any

from datasets import load_dataset


NUMBER_RE = re.compile(r"-?\d[\d,]*")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DATA_DIR / "public_reasoning")
    parser.add_argument("--gsm8k-train-limit", type=int, default=8000)
    parser.add_argument("--gsm8k-val-limit", type=int, default=500)
    parser.add_argument("--ood-limit", type=int, default=500)
    parser.add_argument("--allow-empty-answer", action="store_true")
    return parser.parse_args()


def extract_last_number(text: str) -> str:
    matches = NUMBER_RE.findall(text.replace("####", " "))
    if not matches:
        return ""
    return matches[-1].replace(",", "")


def first_nonempty(row: dict[str, Any], keys: list[str]) -> str:
    for key in keys:
        value = row.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=True))
            handle.write("\n")


def format_prompt(question_text: str) -> str:
    return (
        "Solve the following math word problem carefully.\n"
        f"{question_text}\n"
        "Answer with a single integer."
    )


def to_public_row(
    *,
    split: str,
    sample_id: str,
    shift_type: str,
    source: str,
    prompt_text: str,
    answer_text: str,
) -> dict[str, Any]:
    return {
        "split": split,
        "sample_id": sample_id,
        "shift_type": shift_type,
        "prompt": format_prompt(prompt_text),
        "answer": answer_text,
        "metadata": {"source": source},
    }


def convert_gsm8k_row(row: dict[str, Any], split: str, idx: int) -> dict[str, Any]:
    question = first_nonempty(row, ["question"])
    answer_text = first_nonempty(row, ["answer"])
    answer = extract_last_number(answer_text)
    output = to_public_row(
        split=split,
        sample_id=f"{split}-gsm8k-{idx:05d}",
        shift_type="in_distribution",
        source="gsm8k",
        prompt_text=question,
        answer_text=answer,
    )
    output["metadata"]["raw_answer"] = answer_text
    return output


def convert_svamp_row(row: dict[str, Any], idx: int) -> dict[str, Any]:
    body = first_nonempty(row, ["Body", "body"])
    question = first_nonempty(row, ["Question", "question"])
    answer = extract_last_number(first_nonempty(row, ["Answer", "answer", "label"]))
    text = " ".join(part for part in [body, question] if part).strip()
    return to_public_row(
        split="test_ood",
        sample_id=f"test_ood-svamp-{idx:05d}",
        shift_type="svamp_transfer",
        source="svamp",
        prompt_text=text,
        answer_text=answer,
    )


def convert_multiarith_row(row: dict[str, Any], idx: int) -> dict[str, Any]:
    question = first_nonempty(row, ["question", "Question", "sQuestion"])
    answer = extract_last_number(first_nonempty(row, ["final_ans", "final_answer", "answer", "lSolutions"]))
    return to_public_row(
        split="test_ood",
        sample_id=f"test_ood-multiarith-{idx:05d}",
        shift_type="multiarith_transfer",
        source="multiarith",
        prompt_text=question,
        answer_text=answer,
    )


def convert_asdiv_row(row: dict[str, Any], idx: int) -> dict[str, Any]:
    body = first_nonempty(row, ["Body", "body", "sBody"])
    question = first_nonempty(row, ["Question", "question", "sQuestion"])
    answer_raw = first_nonempty(row, ["Answer", "answer", "solution", "lSolutions", "Formula"])
    answer = extract_last_number(answer_raw)
    text = " ".join(part for part in [body, question] if part).strip()
    return to_public_row(
        split="test_ood",
        sample_id=f"test_ood-asdiv-{idx:05d}",
        shift_type="asdiv_transfer",
        source="asdiv",
        prompt_text=text,
        answer_text=answer,
    )


def slice_rows(rows: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    return rows if limit <= 0 else rows[:limit]


def clean_rows(rows: list[dict[str, Any]], allow_empty_answer: bool) -> tuple[list[dict[str, Any]], dict[str, int]]:
    cleaned: list[dict[str, Any]] = []
    dropped = Counter()
    seen_prompt_answer: set[tuple[str, str]] = set()
    for row in rows:
        prompt = str(row.get("prompt", "")).strip()
        answer = str(row.get("answer", "")).strip()
        if not prompt:
            dropped["empty_prompt"] += 1
            continue
        if not allow_empty_answer and not answer:
            dropped["empty_answer"] += 1
            continue
        marker = (prompt, answer)
        if marker in seen_prompt_answer:
            dropped["duplicate_prompt_answer"] += 1
            continue
        seen_prompt_answer.add(marker)
        cleaned.append(row)
    return cleaned, dict(dropped)


def load_dataset_rows(dataset_name: str, split_candidates: list[str]) -> list[dict[str, Any]]:
    for split in split_candidates:
        try:
            payload = load_dataset(dataset_name, split=split)
            return list(payload)
        except Exception:
            continue
    return []


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir

    gsm8k = load_dataset("openai/gsm8k", "main")
    train_raw = [
        convert_gsm8k_row(row, "train", idx)
        for idx, row in enumerate(slice_rows(list(gsm8k["train"]), args.gsm8k_train_limit))
    ]
    val_raw = [
        convert_gsm8k_row(row, "val", idx)
        for idx, row in enumerate(slice_rows(list(gsm8k["test"]), args.gsm8k_val_limit))
    ]
    train_rows, train_drop = clean_rows(train_raw, allow_empty_answer=args.allow_empty_answer)
    val_rows, val_drop = clean_rows(val_raw, allow_empty_answer=args.allow_empty_answer)

    ood_rows_raw: list[dict[str, Any]] = []
    loaded_sources: list[str] = []
    source_drop_stats: dict[str, dict[str, int]] = {}

    svamp_rows = [
        convert_svamp_row(row, idx)
        for idx, row in enumerate(slice_rows(load_dataset_rows("ChilleD/SVAMP", ["test"]), args.ood_limit))
    ]
    if svamp_rows:
        cleaned, drop = clean_rows(svamp_rows, allow_empty_answer=args.allow_empty_answer)
        ood_rows_raw.extend(cleaned)
        loaded_sources.append("SVAMP")
        source_drop_stats["svamp"] = drop

    multiarith_payload = load_dataset_rows(
        "ChilleD/MultiArith",
        ["test", "train", "validation"],
    )
    if not multiarith_payload:
        multiarith_payload = load_dataset_rows(
            "allenai/multi_arith",
            ["test", "validation", "train"],
        )
    multiarith_rows = [
        convert_multiarith_row(row, idx)
        for idx, row in enumerate(slice_rows(multiarith_payload, args.ood_limit))
    ]
    if multiarith_rows:
        cleaned, drop = clean_rows(multiarith_rows, allow_empty_answer=args.allow_empty_answer)
        ood_rows_raw.extend(cleaned)
        loaded_sources.append("MultiArith")
        source_drop_stats["multiarith"] = drop

    asdiv_payload = load_dataset_rows("EleutherAI/asdiv", ["validation", "test"])
    asdiv_rows = [
        convert_asdiv_row(row, idx)
        for idx, row in enumerate(slice_rows(asdiv_payload, args.ood_limit))
    ]
    if asdiv_rows:
        cleaned, drop = clean_rows(asdiv_rows, allow_empty_answer=args.allow_empty_answer)
        ood_rows_raw.extend(cleaned)
        loaded_sources.append("ASDiv")
        source_drop_stats["asdiv"] = drop

    ood_rows, ood_drop = clean_rows(ood_rows_raw, allow_empty_answer=args.allow_empty_answer)

    write_jsonl(output_dir / "train.jsonl", train_rows)
    write_jsonl(output_dir / "val.jsonl", val_rows)
    write_jsonl(output_dir / "test_ood.jsonl", ood_rows)

    source_counts = Counter(row.get("metadata", {}).get("source", "unknown") for row in ood_rows)
    summary = {
        "output_dir": str(output_dir.resolve()),
        "train_rows": len(train_rows),
        "val_rows": len(val_rows),
        "ood_rows": len(ood_rows),
        "ood_source_counts": dict(source_counts),
        "ood_sources_loaded": loaded_sources,
        "drop_stats": {
            "train": train_drop,
            "val": val_drop,
            "ood_total": ood_drop,
            "ood_per_source": source_drop_stats,
        },
        "required_fields": ["sample_id", "split", "shift_type", "prompt", "answer", "metadata.source"],
        "note": "If ood_rows is 0, install datasets support and verify remote dataset availability.",
    }
    report_path = output_dir / "data_prep_summary.json"
    report_path.write_text(json.dumps(summary, indent=2, ensure_ascii=True), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=True))


if __name__ == "__main__":
    main()
