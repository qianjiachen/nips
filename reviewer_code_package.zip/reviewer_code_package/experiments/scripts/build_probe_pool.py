#!/usr/bin/env python3
"""Build unlabeled probe prompts and deterministic rewrites for SCOPE scoring."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

from workspace_paths import DATA_DIR


REWRITE_PREFIXES = [
    "Think carefully before answering.",
    "Please solve this arithmetic problem.",
    "Work through the calculation step by step.",
]

REWRITE_SUFFIXES = [
    "Return only the final integer.",
    "Write the result as: Answer: <number>.",
    "Do not explain; give the numeric result.",
]

LEXICAL_MAP = {
    "buys": "purchases",
    "more": "additional",
    "have": "possess",
    "leave": "go away",
    "remain": "stay",
    "gets": "receives",
}


def lexical_rewrite(prompt: str) -> str:
    tokens = prompt.split()
    rewritten: list[str] = []
    for token in tokens:
        bare = token.strip(".,!?")
        replacement = LEXICAL_MAP.get(bare.lower())
        if replacement is None:
            rewritten.append(token)
            continue
        punct = token[len(bare) :]
        rewritten.append(replacement + punct)
    return " ".join(rewritten)


def build_rewrites(prompt: str, rng: random.Random) -> list[dict[str, str]]:
    prefix = rng.choice(REWRITE_PREFIXES)
    suffix = rng.choice(REWRITE_SUFFIXES)
    wrapped = f"{prefix}\n{prompt}\n{suffix}"
    reformatted = prompt.replace("Final answer only.", "Respond with Answer: <integer>.")
    lexical = lexical_rewrite(prompt)
    return [
        {"rewrite_type": "wrapper_shift", "prompt": wrapped},
        {"rewrite_type": "format_shift", "prompt": reformatted},
        {"rewrite_type": "lexical_shift", "prompt": lexical},
    ]


def load_examples(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=True))
            handle.write("\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DATA_DIR / "arithshift" / "train.jsonl")
    parser.add_argument("--output", type=Path, default=DATA_DIR / "arithshift" / "probe_pool.jsonl")
    parser.add_argument("--sample-size", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20260320)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    rows = load_examples(args.input)
    if not rows:
        raise ValueError(f"No rows found in {args.input}")
    sampled = rows if len(rows) <= args.sample_size else rng.sample(rows, args.sample_size)
    output_rows: list[dict[str, object]] = []
    for row in sampled:
        output_rows.append(
            {
                "sample_id": row["sample_id"],
                "source_split": row["split"],
                "base_prompt": row["prompt"],
                "rewrites": build_rewrites(str(row["prompt"]), rng),
            }
        )
    write_jsonl(args.output, output_rows)
    print(
        json.dumps(
            {
                "input_rows": len(rows),
                "probe_rows": len(output_rows),
                "output": str(args.output.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
