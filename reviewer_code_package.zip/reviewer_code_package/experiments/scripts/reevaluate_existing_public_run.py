﻿#!/usr/bin/env python3
"""Re-evaluate an existing retained-checkpoint public-transfer run on a new benchmark bundle.

This helper reuses:
- trained checkpoint directories
- SCOPE checkpoint scores
- diagnostic metric files

and refreshes only the evaluation-dependent artifacts in place:
- eval_results.json
- analysis/analysis.json
- analysis/diagnostic_selectors.json
- control_selectors.json
- multiseed summaries / LaTeX tables
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workdir", type=Path, default=Path("."))
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--seed-prefix", type=Path, required=True, help="Prefix like experiments/runs/final/public_transfer_qwen25_15b_seed")
    parser.add_argument("--aggregate-dir", type=Path, required=True)
    parser.add_argument("--probe-file", type=Path, required=True)
    parser.add_argument("--id-file", type=Path, required=True)
    parser.add_argument("--ood-file", type=Path, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", required=True)
    parser.add_argument("--eval-gpu", type=int, default=0)
    parser.add_argument("--eval-max-samples", type=int, default=0)
    parser.add_argument(
        "--eval-sample-mode",
        choices=["head", "random", "stratified_source"],
        default="head",
    )
    parser.add_argument("--tag", default="public_transfer_qwen25_15b")
    parser.add_argument("--allow-remote", action="store_true")
    return parser.parse_args()


def run_cmd(cmd: list[str], cwd: Path, env: dict[str, str] | None = None) -> None:
    print(f"[cmd] {' '.join(cmd)}")
    subprocess.run(cmd, cwd=str(cwd), env=env, check=True)


def main() -> None:
    args = parse_args()
    cwd = args.workdir.resolve()
    seed_prefix = (cwd / args.seed_prefix).resolve() if not args.seed_prefix.is_absolute() else args.seed_prefix.resolve()
    aggregate_dir = (cwd / args.aggregate_dir).resolve() if not args.aggregate_dir.is_absolute() else args.aggregate_dir.resolve()
    probe_file = (cwd / args.probe_file).resolve() if not args.probe_file.is_absolute() else args.probe_file.resolve()
    id_file = (cwd / args.id_file).resolve() if not args.id_file.is_absolute() else args.id_file.resolve()
    ood_file = (cwd / args.ood_file).resolve() if not args.ood_file.is_absolute() else args.ood_file.resolve()

    env = None
    if args.eval_gpu >= 0:
        env = {"CUDA_VISIBLE_DEVICES": str(args.eval_gpu), "PYTHONUNBUFFERED": "1", **dict(os.environ)}

    analysis_files: list[Path] = []
    score_files: list[Path] = []
    control_files: list[Path] = []
    diagnostic_metric_files: list[Path] = []
    diagnostic_selector_files: list[Path] = []

    for seed in args.seeds:
        seed_dir = Path(f"{seed_prefix}{seed}")
        if not seed_dir.exists():
            raise FileNotFoundError(f"Missing seed directory: {seed_dir}")
        score_file = seed_dir / "checkpoint_scores.json"
        diagnostic_metric_file = seed_dir / "analysis" / "diagnostic_metrics.json"
        if not score_file.exists():
            raise FileNotFoundError(f"Missing checkpoint score file: {score_file}")
        if not diagnostic_metric_file.exists():
            raise FileNotFoundError(f"Missing diagnostic metric file: {diagnostic_metric_file}")

        eval_file = seed_dir / "eval_results.json"
        analysis_dir = seed_dir / "analysis"
        analysis_json = analysis_dir / "analysis.json"
        control_file = seed_dir / "control_selectors.json"
        diagnostic_selector_file = analysis_dir / "diagnostic_selectors.json"

        eval_cmd = [
            sys.executable,
            "experiments/scripts/evaluate_checkpoints.py",
            "--base-model",
            args.base_model,
            "--checkpoint-dir",
            str(seed_dir),
            "--id-file",
            str(id_file),
            "--ood-file",
            str(ood_file),
            "--output-file",
            str(eval_file),
            "--max-samples",
            str(args.eval_max_samples),
            "--sample-mode",
            args.eval_sample_mode,
            "--seed-id",
            str(seed),
            "--tokenizer-path",
            str(seed_dir),
        ]
        if args.allow_remote:
            eval_cmd.append("--allow-remote")
        run_cmd(eval_cmd, cwd, env=env)

        run_cmd(
            [
                sys.executable,
                "experiments/scripts/analyze_results.py",
                "--eval-file",
                str(eval_file),
                "--score-file",
                str(score_file),
                "--output-dir",
                str(analysis_dir),
                "--tag",
                f"{args.tag}_seed{seed}",
            ],
            cwd,
            env=env,
        )

        run_cmd(
            [
                sys.executable,
                "experiments/scripts/derive_control_selectors.py",
                "--eval-file",
                str(eval_file),
                "--output-file",
                str(control_file),
            ],
            cwd,
            env=env,
        )

        run_cmd(
            [
                sys.executable,
                "experiments/scripts/derive_diagnostic_selectors.py",
                "--eval-file",
                str(eval_file),
                "--diagnostic-file",
                str(diagnostic_metric_file),
                "--analysis-file",
                str(analysis_json),
                "--output-file",
                str(diagnostic_selector_file),
            ],
            cwd,
            env=env,
        )

        analysis_files.append(analysis_json)
        score_files.append(score_file)
        control_files.append(control_file)
        diagnostic_metric_files.append(diagnostic_metric_file)
        diagnostic_selector_files.append(diagnostic_selector_file)

    aggregate_dir.mkdir(parents=True, exist_ok=True)

    run_cmd(
        [
            sys.executable,
            "experiments/scripts/aggregate_multiseed.py",
            "--analysis-files",
            *(str(path) for path in analysis_files),
            "--output-dir",
            str(aggregate_dir),
            "--tag",
            args.tag,
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/plot_results.py",
            "--multiseed-json",
            str(aggregate_dir / "multiseed_summary.json"),
            "--output-dir",
            str(aggregate_dir),
            "--tag",
            args.tag,
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/aggregate_control_selectors.py",
            "--control-files",
            *(str(path) for path in control_files),
            "--analysis-files",
            *(str(path) for path in analysis_files),
            "--output-file",
            str(aggregate_dir / "control_selector_summary.json"),
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/export_latex_tables.py",
            "--multiseed-json",
            str(aggregate_dir / "multiseed_summary.json"),
            "--output-tex",
            str(aggregate_dir / "selector_table.tex"),
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/export_latex_control_table.py",
            "--control-json",
            str(aggregate_dir / "control_selector_summary.json"),
            "--output-tex",
            str(aggregate_dir / "control_selector_table.tex"),
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/aggregate_diagnostic_selectors.py",
            "--selector-files",
            *(str(path) for path in diagnostic_selector_files),
            "--output-file",
            str(aggregate_dir / "diagnostic_selector_summary.json"),
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/export_latex_diagnostic_table.py",
            "--diagnostic-json",
            str(aggregate_dir / "diagnostic_selector_summary.json"),
            "--output-tex",
            str(aggregate_dir / "diagnostic_selector_table.tex"),
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/summarize_id_budget_selectors.py",
            "--analysis-files",
            *(str(path) for path in analysis_files),
            "--output-json",
            str(aggregate_dir / "id_budget_selector_summary.json"),
            "--output-tex",
            str(aggregate_dir / "id_budget_selector_table.tex"),
        ],
        cwd,
        env=env,
    )
    run_cmd(
        [
            sys.executable,
            "experiments/scripts/summarize_scope_cost.py",
            "--label",
            args.tag,
            "--probe-file",
            str(probe_file),
            "--analysis-files",
            *(str(path) for path in analysis_files),
            "--scope-score-files",
            *(str(path) for path in score_files),
            "--output-json",
            str(aggregate_dir / "scope_cost_summary.json"),
            "--output-tex",
            str(aggregate_dir / "scope_cost_table.tex"),
            "--diagnostic-files",
            *(str(path) for path in diagnostic_metric_files),
        ],
        cwd,
        env=env,
    )

    print(
        json.dumps(
            {
                "analysis_files": [str(path.resolve()) for path in analysis_files],
                "aggregate_dir": str(aggregate_dir),
                "multiseed_summary": str((aggregate_dir / "multiseed_summary.json").resolve()),
                "control_summary": str((aggregate_dir / "control_selector_summary.json").resolve()),
                "diagnostic_summary": str((aggregate_dir / "diagnostic_selector_summary.json").resolve()),
                "id_budget_summary": str((aggregate_dir / "id_budget_selector_summary.json").resolve()),
                "scope_cost_summary": str((aggregate_dir / "scope_cost_summary.json").resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()

