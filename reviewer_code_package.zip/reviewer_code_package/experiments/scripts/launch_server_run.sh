#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
WORKDIR="${WORKDIR:-$ROOT_DIR}"
cd "${ROOT_DIR}"

if [[ ! -d ".venv" ]]; then
  bash experiments/scripts/setup_python_env.sh
fi

source .venv/bin/activate
CONFIG="$(ls experiments/configs/public_transfer_*.json | head -n 1)"
LOG_FILE="experiments/logs/jobs/run_public_multiseed.nohup.log"
mkdir -p "$(dirname "${LOG_FILE}")"
nohup python experiments/scripts/run_public_multiseed.py \
  --config "${CONFIG}" \
  --seeds 20260320 20260321 20260322 \
  --train-gpus 0 1 2 \
  --eval-gpu 3 \
  --desired-checkpoints 10 \
  --enable-rrd \
  > "${LOG_FILE}" 2>&1 &

echo "started_pid=$!"
echo "log_file=${WORKDIR}/${LOG_FILE}"
