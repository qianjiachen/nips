#!/usr/bin/env python3
"""Summarize exact selector-scoring calls together with measured runtime and GPU memory."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import mean
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-files", type=Path, nargs="+", required=True)
    parser.add_argument("--probe-file", type=Path, required=True)
    parser.add_argument("--scope-score-files", type=Path, nargs="*", default=[])
    parser.add_argument("--diagnostic-files", type=Path, nargs="*", default=[])
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    parser.add_argument("--label", type=str, default="Public-transfer main")
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def fmt_float(value: float | int) -> str:
    if isinstance(value, float) and math.isnan(value):
        return "--"
    return f"{float(value):.2f}"


def fmt_seconds(value: float | int) -> str:
    if isinstance(value, float) and math.isnan(value):
        return "--"
    seconds = float(value)
    if seconds >= 3600:
        return f"{seconds / 3600:.2f}h"
    if seconds >= 60:
        return f"{seconds / 60:.1f}m"
    return f"{seconds:.1f}s"


def fmt_int(value: float | int) -> str:
    if isinstance(value, float) and math.isnan(value):
        return "--"
    return str(int(round(float(value))))


def mean_or_nan(values: list[float]) -> float:
    return mean(values) if values else math.nan


def max_or_nan(values: list[float]) -> float:
    return max(values) if values else math.nan


def checkpoint_counts(analysis_files: list[Path]) -> list[int]:
    counts: list[int] = []
    for path in analysis_files:
        payload = read_json(path)
        counts.append(len(payload.get("rows", [])))
    return counts


def summarize_scope_rows(score_files: list[Path], probe_rows: int, rewrites_per_probe: int, fallback_checkpoints: list[int]) -> dict[str, Any]:
    payloads = [read_json(path) for path in score_files]
    probe_vals = [
        int(payload.get("probe_count", probe_rows))
        for payload in payloads
        if payload.get("probe_count") is not None
    ]
    rewrite_vals = [
        int(payload.get("rewrites_per_probe", rewrites_per_probe))
        for payload in payloads
        if payload.get("rewrites_per_probe") is not None
    ]
    runtime_vals = [float(payload.get("runtime_seconds", math.nan)) for payload in payloads if payload.get("runtime_seconds") is not None]
    peak_vals = [float(payload.get("peak_gpu_memory_gb", math.nan)) for payload in payloads if payload.get("peak_gpu_memory_gb") is not None]
    checkpoint_vals = [
        int(payload.get("num_checkpoints", 0))
        for payload in payloads
        if payload.get("num_checkpoints") is not None
    ]
    extra_seed_vals = [
        float(payload.get("extra_forwards_total", math.nan))
        for payload in payloads
        if payload.get("extra_forwards_total") is not None
    ]
    extra_checkpoint_vals = [
        float(payload.get("extra_forwards_per_checkpoint", math.nan))
        for payload in payloads
        if payload.get("extra_forwards_per_checkpoint") is not None
    ]
    if not payloads:
        checkpoint_vals = fallback_checkpoints
        extra_per_checkpoint = probe_rows * (rewrites_per_probe + 2)
        extra_seed_vals = [extra_per_checkpoint * count for count in checkpoint_vals]
        extra_checkpoint_vals = [extra_per_checkpoint]
    return {
        "method": "SCOPE scoring",
        "num_runs": len(payloads) if payloads else len(fallback_checkpoints),
        "probe_rows": mean_or_nan([float(x) for x in probe_vals]) if probe_vals else float(probe_rows),
        "rewrites_per_probe": mean_or_nan([float(x) for x in rewrite_vals]) if rewrite_vals else float(rewrites_per_probe),
        "checkpoints_per_seed_mean": mean_or_nan([float(x) for x in checkpoint_vals]),
        "extra_calls_per_checkpoint_mean": mean_or_nan(extra_checkpoint_vals),
        "extra_calls_per_seed_mean": mean_or_nan(extra_seed_vals),
        "runtime_seconds_mean": mean_or_nan(runtime_vals),
        "peak_gpu_memory_gb_max": max_or_nan(peak_vals),
    }


def summarize_diagnostic_rows(diagnostic_files: list[Path], probe_rows: int, fallback_checkpoints: list[int]) -> dict[str, Any] | None:
    if not diagnostic_files:
        return None
    payloads = [read_json(path) for path in diagnostic_files]
    probe_vals = [
        int(payload.get("probe_count", probe_rows))
        for payload in payloads
        if payload.get("probe_count") is not None
    ]
    runtime_vals = [float(payload.get("runtime_seconds", math.nan)) for payload in payloads if payload.get("runtime_seconds") is not None]
    peak_vals = [float(payload.get("peak_gpu_memory_gb", math.nan)) for payload in payloads if payload.get("peak_gpu_memory_gb") is not None]
    checkpoint_vals = [
        int(payload.get("num_checkpoints", 0))
        for payload in payloads
        if payload.get("num_checkpoints") is not None
    ]
    extra_seed_vals = [
        float(payload.get("extra_forwards_total", math.nan))
        for payload in payloads
        if payload.get("extra_forwards_total") is not None
    ]
    extra_checkpoint_vals = [
        float(payload.get("extra_forwards_per_checkpoint", math.nan))
        for payload in payloads
        if payload.get("extra_forwards_per_checkpoint") is not None
    ]
    if not checkpoint_vals:
        checkpoint_vals = fallback_checkpoints
    if not extra_seed_vals:
        extra_seed_vals = [probe_rows * (2 * count + 1) for count in checkpoint_vals]
    if not extra_checkpoint_vals:
        extra_checkpoint_vals = [probe_rows * 2]
    return {
        "method": "Diagnostic baselines",
        "num_runs": len(payloads),
        "probe_rows": mean_or_nan([float(x) for x in probe_vals]) if probe_vals else float(probe_rows),
        "rewrites_per_probe": 0,
        "checkpoints_per_seed_mean": mean_or_nan([float(x) for x in checkpoint_vals]),
        "extra_calls_per_checkpoint_mean": mean_or_nan(extra_checkpoint_vals),
        "extra_calls_per_seed_mean": mean_or_nan(extra_seed_vals),
        "runtime_seconds_mean": mean_or_nan(runtime_vals),
        "peak_gpu_memory_gb_max": max_or_nan(peak_vals),
        "note": "Includes one extra reference hidden-state pass per seed.",
    }


def build_summary(
    label: str,
    analysis_files: list[Path],
    probe_file: Path,
    scope_score_files: list[Path],
    diagnostic_files: list[Path],
) -> dict[str, Any]:
    probe_rows = read_jsonl(probe_file)
    if not probe_rows:
        raise ValueError(f"No probe rows found in {probe_file}")
    probe_count = len(probe_rows)
    rewrites_per_probe = len(probe_rows[0].get("rewrites", []))
    counts = checkpoint_counts(analysis_files)
    rows = [summarize_scope_rows(scope_score_files, probe_count, rewrites_per_probe, counts)]
    diagnostic_row = summarize_diagnostic_rows(diagnostic_files, probe_count, counts)
    if diagnostic_row is not None:
        rows.append(diagnostic_row)
    return {
        "label": label,
        "probe_file": str(probe_file.resolve()),
        "analysis_files": [str(path.resolve()) for path in analysis_files],
        "scope_score_files": [str(path.resolve()) for path in scope_score_files],
        "diagnostic_files": [str(path.resolve()) for path in diagnostic_files],
        "num_seeds": len(analysis_files),
        "probe_rows": probe_count,
        "rewrites_per_probe": rewrites_per_probe,
        "rows": rows,
    }


def build_tex(summary: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(
        "\\caption{Selector-scoring overhead on the retained-checkpoint public-transfer rerun. "
        "Exact forward-call counts come from the probe layout and checkpoint count; wall-clock and peak GPU memory are measured directly from the scorer outputs. "
        "Diagnostic baselines reuse the same retained checkpoints and include one extra reference hidden-state pass per seed.}"
    )
    lines.append("\\label{tab:scope-cost}")
    lines.append("\\setlength{\\tabcolsep}{3.5pt}")
    lines.append("\\resizebox{\\linewidth}{!}{%")
    lines.append("\\begin{tabular}{lcccccc}")
    lines.append("\\toprule")
    lines.append("Scoring pass & Seeds & Probe rows & Checkpoints/seed & Exact extra calls/seed & Wall-clock/seed & Peak GPU mem \\\\")
    lines.append("\\midrule")
    for row in summary["rows"]:
        lines.append(
            f"{row['method']} & "
            f"{fmt_int(row['num_runs'])} & "
            f"{fmt_int(row['probe_rows'])} & "
            f"{fmt_float(row['checkpoints_per_seed_mean'])} & "
            f"{fmt_float(row['extra_calls_per_seed_mean'])} & "
            f"{fmt_seconds(row['runtime_seconds_mean'])} & "
            f"{fmt_float(row['peak_gpu_memory_gb_max'])} GB \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("}%")
    lines.append("\\end{table}")
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    summary = build_summary(
        args.label,
        args.analysis_files,
        args.probe_file,
        args.scope_score_files,
        args.diagnostic_files,
    )
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_tex.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(summary, indent=2, ensure_ascii=True), encoding="utf-8")
    args.output_tex.write_text(build_tex(summary), encoding="utf-8")
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
