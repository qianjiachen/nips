#!/usr/bin/env python3
"""Pull top-level experiment artifacts from a remote host and mirror paper-facing files locally."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path, PurePosixPath

import paramiko

from workspace_paths import ROOT, SCRIPTS_DIR


ALLOWED_SUFFIXES = {".json", ".tex", ".md", ".png", ".pdf"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--username", required=True)
    parser.add_argument("--password", default=None)
    parser.add_argument("--password-env", default="REMOTE_SSH_PASSWORD")
    parser.add_argument("--remote-dir", required=True)
    parser.add_argument("--local-dir", type=Path, required=True)
    parser.add_argument("--paper-dir", type=Path, default=None)
    parser.add_argument("--tex-file", type=Path, default=None, help="Optional paper TeX file to refresh via fill_tex_metrics.py.")
    parser.add_argument("--include", nargs="*", default=None, help="Optional explicit filenames to copy.")
    parser.add_argument("--workdir", type=Path, default=ROOT)
    return parser.parse_args()


def resolve_password(args: argparse.Namespace) -> str:
    if args.password:
        return args.password
    value = os.environ.get(args.password_env)
    if value:
        return value
    raise ValueError(f"Missing SSH password. Pass --password or set {args.password_env}.")


def should_copy(name: str, explicit: set[str] | None) -> bool:
    if explicit is not None:
        return name in explicit
    return Path(name).suffix.lower() in ALLOWED_SUFFIXES


def main() -> None:
    args = parse_args()
    password = resolve_password(args)
    explicit = None if not args.include else set(args.include)
    remote_dir = PurePosixPath(args.remote_dir)
    local_dir = (args.workdir / args.local_dir).resolve() if not args.local_dir.is_absolute() else args.local_dir.resolve()
    paper_dir = None
    if args.paper_dir is not None:
        paper_dir = (args.workdir / args.paper_dir).resolve() if not args.paper_dir.is_absolute() else args.paper_dir.resolve()
    tex_file = None
    if args.tex_file is not None:
        tex_file = (args.workdir / args.tex_file).resolve() if not args.tex_file.is_absolute() else args.tex_file.resolve()

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    copied: list[dict[str, str]] = []
    try:
        client.connect(
            args.host,
            port=args.port,
            username=args.username,
            password=password,
            timeout=20,
            banner_timeout=20,
            auth_timeout=20,
        )
        sftp = client.open_sftp()
        try:
            entries = sftp.listdir_attr(str(remote_dir))
            local_dir.mkdir(parents=True, exist_ok=True)
            if paper_dir is not None:
                paper_dir.mkdir(parents=True, exist_ok=True)
            for entry in entries:
                name = entry.filename
                if not should_copy(name, explicit):
                    continue
                remote_path = remote_dir / name
                local_path = local_dir / name
                sftp.get(str(remote_path), str(local_path))
                copied.append({"remote": str(remote_path), "local": str(local_path)})
                if paper_dir is not None and Path(name).suffix.lower() in {".tex", ".png", ".pdf"}:
                    paper_path = paper_dir / name
                    sftp.get(str(remote_path), str(paper_path))
                    copied.append({"remote": str(remote_path), "local": str(paper_path)})
        finally:
            sftp.close()
    finally:
        client.close()

    metrics_refresh = None
    multiseed_json = local_dir / "multiseed_summary.json"
    if tex_file is not None and multiseed_json.exists():
        cmd = [
            sys.executable,
            str(SCRIPTS_DIR / "fill_tex_metrics.py"),
            "--multiseed-json",
            str(multiseed_json),
            "--tex-file",
            str(tex_file),
        ]
        subprocess.run(cmd, cwd=str(args.workdir.resolve()), check=True)
        metrics_refresh = {"multiseed_json": str(multiseed_json), "tex_file": str(tex_file)}

    print(
        json.dumps(
            {"copied": copied, "count": len(copied), "metrics_refresh": metrics_refresh},
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
