#!/usr/bin/env python3
"""Export diagnostic-selector summary JSON into a LaTeX table."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


ORDER = [
    "last",
    "best_id",
    "entropy_min",
    "cka_max",
    "svcca_max",
    "weight_rel_l2_min",
    "weight_cosine_max",
    "effective_rank_max",
    "top1_ratio_min",
    "best_scope",
    "best_ood_oracle",
]

LABEL = {
    "last": "Last",
    "best_id": "Best-ID",
    "entropy_min": "Min Entropy",
    "cka_max": "Max CKA",
    "svcca_max": "Max SVCCA",
    "weight_rel_l2_min": "Min Rel-L2 Drift",
    "weight_cosine_max": "Max Cosine Similarity",
    "effective_rank_max": "Max EffRank",
    "top1_ratio_min": "Min Top-1 Ratio",
    "best_scope": "SCOPE",
    "best_ood_oracle": "Oracle Best-OOD",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--diagnostic-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def fmt(value: Any) -> str:
    if value is None:
        return "--"
    if isinstance(value, float):
        if math.isnan(value):
            return "--"
        return f"{value:.4f}"
    return str(value)


def metric_with_std(row: dict[str, Any], mean_key: str, std_key: str) -> str:
    return f"{fmt(row.get(mean_key))} $\\pm$ {fmt(row.get(std_key))}"


def p_vs_scope(payload: dict[str, Any], selector: str) -> str:
    if selector == "best_scope":
        return "--"
    if selector == "best_ood_oracle":
        return "--"
    row = payload.get("paired_tests", {}).get(f"{selector}_minus_scope", {})
    return fmt(row.get("p_value_signflip"))


def build_caption(payload: dict[str, Any]) -> str:
    num_seeds = payload.get("num_seeds")
    if isinstance(num_seeds, int) and num_seeds > 0:
        scope = f" (n={num_seeds}"
        if num_seeds < 8:
            scope += ", partial but informative retained-checkpoint subset"
        scope += ")"
    else:
        scope = ""
    return (
        "Additional unsupervised checkpoint selectors derived from representation similarity, predictive uncertainty, "
        f"weight drift, and spectrum heuristics{scope}. "
        "The last column reports paired sign-flip $p$-values against SCOPE on the same seeds."
    )


def build_table(payload: dict[str, Any]) -> str:
    rows = {row["selector"]: row for row in payload.get("selectors", [])}
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(f"\\caption{{{build_caption(payload)}}}")
    lines.append("\\label{tab:diagnostic-baselines}")
    lines.append("\\setlength{\\tabcolsep}{3.5pt}")
    lines.append("\\resizebox{\\linewidth}{!}{%")
    lines.append("\\begin{tabular}{lcccc}")
    lines.append("\\toprule")
    lines.append("Selector & ID Acc & OOD Acc & Regret to Oracle & $p$ vs SCOPE \\\\")
    lines.append("\\midrule")
    for name in ORDER:
        row = rows.get(name)
        if row is None:
            continue
        lines.append(
            f"{LABEL.get(name, name)} & "
            f"{metric_with_std(row, 'id_accuracy_mean', 'id_accuracy_std')} & "
            f"{metric_with_std(row, 'ood_accuracy_mean', 'ood_accuracy_std')} & "
            f"{fmt(row.get('ood_regret_mean'))} & "
            f"{p_vs_scope(payload, name)} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("}%")
    lines.append("\\end{table}")
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    payload = read_json(args.diagnostic_json)
    tex = build_table(payload)
    args.output_tex.parent.mkdir(parents=True, exist_ok=True)
    args.output_tex.write_text(tex, encoding="utf-8")
    print(json.dumps({"output_tex": str(args.output_tex.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
