#!/usr/bin/env python3
"""Generate publication-ready figures for the SCOPE NeurIPS draft."""

from __future__ import annotations

import json
from pathlib import Path
from statistics import mean, stdev
from typing import Any

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from workspace_paths import DATA_DIR, FINAL_RUNS_DIR, PAPER_DIAGRAMS_DIR, PAPER_RESULTS_DIR, ROOT


MULTISEED_DIR = FINAL_RUNS_DIR / "public_transfer_qwen25_15b_multiseed"
SEEDS = list(range(20260320, 20260328))

COLORS = {
    "navy": "#24405C",
    "ink": "#1F2937",
    "slate": "#6B7280",
    "light_slate": "#E5E7EB",
    "blue": "#DCEEFF",
    "blue_dark": "#2563EB",
    "green": "#DCFCE7",
    "green_dark": "#16A34A",
    "orange": "#FDE7D3",
    "orange_dark": "#EA580C",
    "purple": "#E9D5FF",
    "purple_dark": "#7C3AED",
    "gold": "#F5B301",
    "red_soft": "#FEE2E2",
    "red_dark": "#DC2626",
    "teal": "#72B7B2",
    "gray": "#7A8691",
    "gray_fill": "#EEF2F7",
    "background": "#FCFCFD",
}


def set_plot_theme() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.labelsize": 11,
            "axes.titlesize": 12,
            "legend.fontsize": 9,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
        }
    )


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_seed_payload(seed: int) -> dict[str, Any]:
    path = FINAL_RUNS_DIR / f"public_transfer_qwen25_15b_seed{seed}" / "analysis" / "analysis.json"
    return read_json(path)


def load_all_seed_payloads() -> list[dict[str, Any]]:
    return [load_seed_payload(seed) for seed in SEEDS]


def checkpoint_row(payload: dict[str, Any], step: int) -> dict[str, Any]:
    for row in payload.get("rows", []):
        if int(row["step"]) == int(step):
            return row
    raise KeyError(f"Checkpoint step {step} not found.")


def probe_pool_stats() -> tuple[int, int]:
    probe_path = DATA_DIR / "public_reasoning" / "probe_pool.jsonl"
    with probe_path.open("r", encoding="utf-8") as handle:
        first_row = json.loads(next(handle))
        count = 1 + sum(1 for _ in handle)
    return count, len(first_row.get("rewrites", []))


def add_round_box(
    ax: plt.Axes,
    x: float,
    y: float,
    w: float,
    h: float,
    text: str,
    facecolor: str,
    edgecolor: str,
    *,
    fontsize: float = 11,
    weight: str = "regular",
    textcolor: str = COLORS["ink"],
    lw: float = 1.7,
    rounding: float = 0.03,
    alpha: float = 1.0,
) -> FancyBboxPatch:
    patch = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle=f"round,pad=0.012,rounding_size={rounding}",
        linewidth=lw,
        facecolor=facecolor,
        edgecolor=edgecolor,
        alpha=alpha,
    )
    ax.add_patch(patch)
    ax.text(
        x + w / 2,
        y + h / 2,
        text,
        ha="center",
        va="center",
        fontsize=fontsize,
        fontweight=weight,
        color=textcolor,
        linespacing=1.25,
    )
    return patch


def add_arrow(
    ax: plt.Axes,
    start: tuple[float, float],
    end: tuple[float, float],
    *,
    label: str | None = None,
    label_offset: tuple[float, float] = (0.0, 0.0),
    color: str = COLORS["ink"],
    lw: float = 1.8,
    linestyle: str = "-",
    mutation_scale: float = 18.0,
) -> FancyArrowPatch:
    arrow = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=mutation_scale,
        linewidth=lw,
        linestyle=linestyle,
        color=color,
        shrinkA=2,
        shrinkB=2,
    )
    ax.add_patch(arrow)
    if label is not None:
        mx = (start[0] + end[0]) / 2 + label_offset[0]
        my = (start[1] + end[1]) / 2 + label_offset[1]
        ax.text(
            mx,
            my,
            label,
            ha="center",
            va="center",
            fontsize=8.5,
            color=color,
            bbox={"boxstyle": "round,pad=0.18", "fc": "white", "ec": "none", "alpha": 0.92},
        )
    return arrow


def add_panel_tag(ax: plt.Axes, label: str, title: str) -> None:
    ax.text(0.02, 0.97, label, ha="left", va="top", fontsize=12.5, fontweight="bold", color=COLORS["navy"])
    ax.text(0.12, 0.97, title, ha="left", va="top", fontsize=12.5, fontweight="bold", color=COLORS["navy"])


def plot_method_overview() -> Path:
    set_plot_theme()
    probe_count, rewrites_per_probe = probe_pool_stats()
    representative = load_seed_payload(SEEDS[0])
    steps = np.array([int(row["step"]) for row in representative["rows"]], dtype=float)
    scores = np.array([float(row["scope_score"]) for row in representative["rows"]], dtype=float)
    threshold = scores.max() - float(representative["scope_selection_rule"]["margin_std"]) * scores.std()
    selected_step = int(representative["best_scope_checkpoint"]["step"])
    selected_score = float(representative["best_scope_checkpoint"]["scope_score"])
    last_step = int(representative["last_checkpoint"]["step"])
    last_score = float(representative["last_checkpoint"]["scope_score"])
    best_step = int(representative["best_ood_checkpoint"]["step"])
    best_score = float(representative["best_ood_checkpoint"]["scope_score"])

    fig, axes = plt.subplots(1, 4, figsize=(15.5, 4.6))
    fig.patch.set_facecolor(COLORS["background"])
    for ax in axes:
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis("off")

    ax = axes[0]
    add_panel_tag(ax, "A.", "Probe Construction")
    add_round_box(ax, 0.07, 0.66, 0.30, 0.17, "ID prompts", COLORS["blue"], COLORS["blue_dark"], weight="bold")
    add_round_box(ax, 0.56, 0.66, 0.28, 0.17, "Base prompt\n$x$", COLORS["blue"], COLORS["blue_dark"], weight="bold")
    add_arrow(ax, (0.38, 0.745), (0.56, 0.745), label=f"sample {probe_count} bases")
    rewrite_labels = [
        ("Wrapper shift\n$\\tilde{x}^{(1)}$", 0.05),
        ("Lexical rewrite\n$\\tilde{x}^{(2)}$", 0.365),
        ("Format rewrite\n$\\tilde{x}^{(3)}$", 0.68),
    ]
    for text, x in rewrite_labels:
        add_round_box(ax, x, 0.28, 0.24, 0.16, text, COLORS["green"], COLORS["green_dark"], fontsize=10.2, weight="bold")
        add_arrow(ax, (0.70, 0.66), (x + 0.12, 0.44), color=COLORS["green_dark"])
    add_round_box(
        ax,
        0.17,
        0.07,
        0.66,
        0.12,
        f"Deterministic semantics-preserving rewrites\n{rewrites_per_probe} rewrites per probe, label-blind by design",
        "#FFFFFF",
        COLORS["light_slate"],
        fontsize=9.5,
    )

    ax = axes[1]
    add_panel_tag(ax, "B.", "Two Proxy Signals")
    add_round_box(ax, 0.05, 0.43, 0.20, 0.17, "Checkpoint\n$t$", COLORS["gray_fill"], COLORS["gray"], weight="bold")
    add_round_box(ax, 0.33, 0.63, 0.25, 0.14, "Base / rewrite\nnext-token dists.", COLORS["green"], COLORS["green_dark"], fontsize=10.1)
    add_round_box(ax, 0.69, 0.63, 0.22, 0.14, "$\\mathrm{PS}_t$\nJS divergence", COLORS["green"], COLORS["green_dark"], fontsize=10.1, weight="bold")
    add_arrow(ax, (0.25, 0.515), (0.33, 0.70), color=COLORS["green_dark"])
    add_arrow(ax, (0.58, 0.70), (0.69, 0.70), label="surface invariance", label_offset=(0.0, 0.06), color=COLORS["green_dark"])
    add_round_box(ax, 0.29, 0.19, 0.22, 0.14, "Reference\n$H_{t_0}$", COLORS["orange"], COLORS["orange_dark"], fontsize=10.1)
    add_round_box(ax, 0.54, 0.19, 0.22, 0.14, "Current\n$H_t$", COLORS["orange"], COLORS["orange_dark"], fontsize=10.1)
    add_round_box(ax, 0.79, 0.19, 0.14, 0.14, "$\\mathrm{RRD}_t$\nPCA angle", COLORS["orange"], COLORS["orange_dark"], fontsize=9.7, weight="bold")
    add_arrow(ax, (0.25, 0.515), (0.29, 0.26), color=COLORS["orange_dark"])
    add_arrow(ax, (0.25, 0.515), (0.54, 0.26), color=COLORS["orange_dark"])
    add_arrow(ax, (0.51, 0.26), (0.79, 0.26), label="principal-subspace drift", label_offset=(0.0, 0.06), color=COLORS["orange_dark"])

    ax = axes[2]
    add_panel_tag(ax, "C.", "Composite Score")
    add_round_box(ax, 0.09, 0.60, 0.22, 0.15, "$\\mathrm{RRD}_t$", COLORS["orange"], COLORS["orange_dark"], weight="bold")
    add_round_box(ax, 0.09, 0.35, 0.22, 0.15, "$\\mathrm{PS}_t$", COLORS["green"], COLORS["green_dark"], weight="bold")
    add_round_box(
        ax,
        0.43,
        0.43,
        0.48,
        0.24,
        "$\\mathrm{SCOPE}_t = -z(\\mathrm{RRD}_t) - z(\\mathrm{PS}_t)$",
        COLORS["purple"],
        COLORS["purple_dark"],
        fontsize=11.5,
        weight="bold",
    )
    add_arrow(ax, (0.31, 0.675), (0.43, 0.555), color=COLORS["orange_dark"])
    add_arrow(ax, (0.31, 0.425), (0.43, 0.555), color=COLORS["green_dark"])
    ax.text(0.43, 0.28, "z-normalize over checkpoints within one trajectory", ha="left", va="center", fontsize=9.5, color=COLORS["navy"])
    strip_x = np.linspace(0.44, 0.88, 10)
    strip_vals = np.linspace(0.15, 0.95, 10)
    for x, alpha in zip(strip_x, strip_vals):
        add_round_box(
            ax,
            x,
            0.10,
            0.035,
            0.08,
            "",
            COLORS["purple"],
            COLORS["purple_dark"],
            lw=1.0,
            alpha=alpha,
            rounding=0.01,
        )
    ax.text(0.66, 0.06, "higher SCOPE = expected broader generalization", ha="center", va="center", fontsize=8.9, color=COLORS["slate"])

    ax = axes[3]
    add_panel_tag(ax, "D.", "Plateau-Aware Deployment")
    ax.text(0.05, 0.86, "Select the earliest checkpoint in the\nhigh-score plateau, not necessarily argmax.", ha="left", va="top", fontsize=10.2, color=COLORS["navy"])
    ax.text(0.05, 0.74, r"Threshold: $\max(\mathrm{SCOPE}) - 0.5\,\sigma_{\mathrm{traj}}$", ha="left", va="top", fontsize=9.6, color=COLORS["purple_dark"])
    inset = ax.inset_axes([0.08, 0.19, 0.84, 0.44])
    inset.set_facecolor("white")
    inset.axhspan(threshold, scores.max(), color=COLORS["purple"], alpha=0.35)
    inset.plot(steps, scores, color=COLORS["teal"], linestyle="--", linewidth=2.2, marker="^", markersize=5)
    inset.scatter([selected_step], [selected_score], s=64, color=COLORS["purple_dark"], zorder=5)
    inset.scatter([best_step], [best_score], s=130, marker="*", color=COLORS["gold"], edgecolor=COLORS["ink"], linewidth=0.7, zorder=6)
    inset.scatter([last_step], [last_score], s=44, marker="s", color=COLORS["gray"], zorder=6)
    inset.axhline(threshold, color=COLORS["purple_dark"], linewidth=1.2, linestyle=":")
    inset.set_xlabel("Checkpoint step", fontsize=9)
    inset.set_ylabel("SCOPE", fontsize=9)
    inset.tick_params(labelsize=8)
    inset.grid(alpha=0.18, linewidth=0.7)
    inset.spines["top"].set_visible(False)
    inset.spines["right"].set_visible(False)
    ax.text(0.11, 0.08, "Purple dot: deployed checkpoint", fontsize=8.8, color=COLORS["purple_dark"])
    ax.text(0.11, 0.03, "Gold star: oracle-best OOD, Gray square: last checkpoint", fontsize=8.8, color=COLORS["slate"])

    fig.subplots_adjust(left=0.03, right=0.985, top=0.92, bottom=0.08, wspace=0.14)
    output_path = PAPER_DIAGRAMS_DIR / "method_overview.png"
    fig.savefig(output_path, dpi=300)
    plt.close(fig)
    return output_path


def plot_data_contract_figure() -> Path:
    set_plot_theme()
    local_quality = read_json(FINAL_RUNS_DIR / "data_quality" / "public_reasoning_quality_local.json")
    server_quality = read_json(FINAL_RUNS_DIR / "data_quality" / "public_reasoning_quality_server.json")
    probe_count, rewrites_per_probe = probe_pool_stats()

    fig, ax = plt.subplots(figsize=(13.8, 5.5))
    fig.patch.set_facecolor("white")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    add_round_box(ax, 0.03, 0.11, 0.29, 0.70, "", "#F6FAFF", "#F6FAFF", lw=0.0, rounding=0.04)
    add_round_box(ax, 0.355, 0.11, 0.29, 0.70, "", "#FBF8FF", "#FBF8FF", lw=0.0, rounding=0.04)
    add_round_box(ax, 0.68, 0.11, 0.29, 0.70, "", "#FFF8F1", "#FFF8F1", lw=0.0, rounding=0.04)

    ax.plot([0.12, 0.84], [0.90, 0.90], color="#D8DEE9", linewidth=4.0, solid_capstyle="round")
    add_arrow(ax, (0.15, 0.90), (0.46, 0.90), color=COLORS["blue_dark"], lw=2.4, mutation_scale=22)
    add_arrow(ax, (0.53, 0.90), (0.84, 0.90), color=COLORS["purple_dark"], lw=2.4, mutation_scale=22)

    def add_stage_marker(x: float, number: str, color: str, title: str, subtitle: str) -> None:
        ax.text(
            x,
            0.90,
            number,
            ha="center",
            va="center",
            fontsize=13.0,
            fontweight="bold",
            color="white",
            bbox={"boxstyle": "circle,pad=0.38", "fc": color, "ec": "none"},
        )
        ax.text(x, 0.84, title, ha="center", va="bottom", fontsize=15.0, fontweight="bold", color=color)
        ax.text(x, 0.805, subtitle, ha="center", va="bottom", fontsize=10.2, color=COLORS["navy"])

    add_stage_marker(0.12, "1", COLORS["blue_dark"], "Selector-facing bundle", "experiments/data/public_reasoning")
    add_stage_marker(0.50, "2", COLORS["purple_dark"], "Selection-time boundary", "checkpoint is fixed without OOD labels")
    add_stage_marker(
        0.88,
        "3",
        COLORS["orange_dark"],
        "Benchmark evaluation",
        "public_reasoning_quality_\nserver.json",
    )

    add_round_box(
        ax,
        0.06,
        0.58,
        0.21,
        0.11,
        "train\n2000 GSM8K rows",
        COLORS["blue"],
        COLORS["blue_dark"],
        fontsize=11.2,
        weight="bold",
    )
    add_round_box(
        ax,
        0.06,
        0.42,
        0.21,
        0.11,
        "val\n300 GSM8K rows",
        COLORS["blue"],
        COLORS["blue_dark"],
        fontsize=11.2,
        weight="bold",
    )
    add_round_box(
        ax,
        0.06,
        0.19,
        0.21,
        0.17,
        "test_ood\n400 rows\nSVAMP 200 + ASDiv 200",
        COLORS["orange"],
        COLORS["orange_dark"],
        fontsize=11.0,
        weight="bold",
    )
    add_round_box(
        ax,
        0.215,
        0.275,
        0.08,
        0.06,
        f"{local_quality['splits']['test_ood']['duplicate_prompt_rows']} duplicate\nprompt rows",
        COLORS["red_soft"],
        COLORS["red_dark"],
        fontsize=8.1,
        weight="bold",
    )
    add_round_box(
        ax,
        0.215,
        0.195,
        0.08,
        0.06,
        f"{local_quality['splits']['test_ood']['empty_answer']} blank answers\nby design",
        COLORS["red_soft"],
        COLORS["red_dark"],
        fontsize=8.1,
        weight="bold",
    )
    add_round_box(
        ax,
        0.06,
        0.07,
        0.24,
        0.075,
        f"probe pool\n{probe_count} unlabeled bases x {rewrites_per_probe} rewrites",
        COLORS["green"],
        COLORS["green_dark"],
        fontsize=10.0,
        weight="bold",
    )
    ax.text(
        0.175,
        0.155,
        "schema checks + leakage checks +\nlabel-blind proxy scoring",
        ha="center",
        va="center",
        fontsize=9.4,
        color=COLORS["navy"],
    )

    add_round_box(
        ax,
        0.40,
        0.49,
        0.20,
        0.14,
        "SCOPE selector\nRRD + PS + plateau rule",
        COLORS["purple"],
        COLORS["purple_dark"],
        fontsize=11.1,
        weight="bold",
    )
    add_round_box(
        ax,
        0.39,
        0.26,
        0.22,
        0.12,
        "Can use:\nprompts, rewrites,\npredictions, hidden states",
        "#FFFFFF",
        COLORS["light_slate"],
        fontsize=9.8,
        weight="bold",
    )
    add_round_box(
        ax,
        0.41,
        0.08,
        0.18,
        0.10,
        "Cannot use:\nOOD labels",
        COLORS["red_soft"],
        COLORS["red_dark"],
        fontsize=10.2,
        weight="bold",
    )
    ax.plot([0.435, 0.565], [0.095, 0.165], color=COLORS["red_dark"], linewidth=2.4)
    ax.plot([0.435, 0.565], [0.165, 0.095], color=COLORS["red_dark"], linewidth=2.4)

    ax.text(0.50, 0.69, "selector sees only selection-time artifacts", ha="center", va="center", fontsize=9.7, color=COLORS["blue_dark"])
    ax.text(0.50, 0.20, "labels remain hidden until evaluation", ha="center", va="center", fontsize=9.7, color=COLORS["purple_dark"])

    add_round_box(
        ax,
        0.71,
        0.56,
        0.23,
        0.13,
        "train / val / test_ood\n7473 / 500 / 970 rows\nall test_ood answers present",
        COLORS["orange"],
        COLORS["orange_dark"],
        fontsize=10.7,
        weight="bold",
    )
    add_round_box(
        ax,
        0.71,
        0.34,
        0.23,
        0.11,
        "OOD sources\nSVAMP 300 | MultiArith 178 | ASDiv 492",
        COLORS["orange"],
        COLORS["orange_dark"],
        fontsize=10.0,
        weight="bold",
    )
    add_round_box(
        ax,
        0.71,
        0.12,
        0.23,
        0.12,
        "Evaluator joins the frozen checkpoint\nwith the labeled benchmark by sample_id",
        "#FFFFFF",
        COLORS["light_slate"],
        fontsize=9.7,
        weight="bold",
    )

    add_arrow(ax, (0.30, 0.56), (0.395, 0.56), color=COLORS["blue_dark"], lw=2.2, mutation_scale=20)
    add_arrow(ax, (0.60, 0.56), (0.71, 0.18), color=COLORS["purple_dark"], lw=2.2, mutation_scale=20)
    ax.text(0.66, 0.30, "freeze checkpoint first", ha="center", va="center", fontsize=9.7, color=COLORS["purple_dark"])

    overlap_zero = all(value == 0 for value in local_quality["overlap"].values()) and all(value == 0 for value in server_quality["overlap"].values())
    overlap_text = "Overlap checks: 0 prompt/sample_id overlap across train, val, and test in both bundles." if overlap_zero else "Inspect overlap fields: at least one overlap check is non-zero."
    add_round_box(ax, 0.08, 0.01, 0.84, 0.05, overlap_text, "#F8FAFC", COLORS["light_slate"], fontsize=9.4, weight="bold")

    fig.subplots_adjust(left=0.01, right=0.99, top=0.98, bottom=0.02)
    output_path = PAPER_DIAGRAMS_DIR / "data_contract_overview.png"
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_trajectory(seed: int = 20260320) -> Path:
    set_plot_theme()
    payload = load_seed_payload(seed)
    rows = payload.get("rows", [])
    steps = [int(row["step"]) for row in rows]
    id_acc = [float(row["id_accuracy"]) for row in rows]
    ood_acc = [float(row["ood_accuracy"]) for row in rows]
    scope = [float(row["scope_score"]) for row in rows]

    selected_step = int(payload["best_scope_checkpoint"]["step"])
    last_step = int(payload["last_checkpoint"]["step"])
    best_ood_step = int(payload["best_ood_checkpoint"]["step"])
    selected_row = checkpoint_row(payload, selected_step)
    last_row = checkpoint_row(payload, last_step)
    best_ood_row = checkpoint_row(payload, best_ood_step)

    fig, ax1 = plt.subplots(figsize=(8.0, 4.5))
    ax1.set_facecolor("white")
    fig.patch.set_facecolor("white")

    id_line, = ax1.plot(steps, id_acc, marker="o", markersize=4.5, linewidth=2.0, color="#4C78A8", label="ID accuracy")
    ood_line, = ax1.plot(steps, ood_acc, marker="s", markersize=4.5, linewidth=2.0, color="#E45756", label="OOD accuracy")
    ax1.axvline(selected_step, color="black", linestyle="--", linewidth=1.1, alpha=0.75)
    ax1.axvline(last_step, color="0.45", linestyle=":", linewidth=1.1, alpha=0.8)
    ax1.set_xlabel("Checkpoint step")
    ax1.set_ylabel("Accuracy")
    ax1.grid(alpha=0.18, linewidth=0.8)
    ax1.set_axisbelow(True)
    tick_positions = []
    for idx, step in enumerate(steps):
        if idx < len(steps) - 1 and steps[idx + 1] - step <= 12:
            continue
        tick_positions.append(step)
    ax1.set_xticks(tick_positions)
    ax1.set_xlim(min(steps) - 8, max(steps) + 8)

    ax2 = ax1.twinx()
    scope_line, = ax2.plot(
        steps,
        scope,
        marker="^",
        markersize=4.5,
        linewidth=2.0,
        linestyle="--",
        color=COLORS["teal"],
        label="SCOPE score",
    )
    ax2.set_ylabel("SCOPE score")
    ax1.scatter(
        [selected_step],
        [float(selected_row["ood_accuracy"])],
        s=58,
        color=COLORS["purple_dark"],
        edgecolor="white",
        linewidth=0.9,
        zorder=6,
    )
    ax1.scatter(
        [best_ood_step],
        [float(best_ood_row["ood_accuracy"])],
        marker="*",
        s=180,
        color=COLORS["gold"],
        edgecolor=COLORS["ink"],
        linewidth=0.9,
        zorder=7,
    )
    ax1.scatter(
        [last_step],
        [float(last_row["ood_accuracy"])],
        marker="s",
        s=48,
        color=COLORS["gray"],
        edgecolor="white",
        linewidth=0.8,
        zorder=6,
    )

    handles = [
        id_line,
        ood_line,
        scope_line,
        Line2D([0], [0], color="black", linestyle="--", linewidth=1.1, label="SCOPE selected"),
        Line2D(
            [0],
            [0],
            marker="*",
            color="w",
            markerfacecolor=COLORS["gold"],
            markeredgecolor=COLORS["ink"],
            markersize=11,
            label="Oracle Best-OOD",
        ),
        Line2D([0], [0], color="0.45", linestyle=":", linewidth=1.1, label="Last checkpoint"),
    ]
    ax1.legend(handles=handles, loc="upper left", frameon=False, ncol=2, columnspacing=1.1, handlelength=2.2)

    fig.tight_layout(pad=0.4)
    output_path = PAPER_RESULTS_DIR / "trajectory_plot_neurips.png"
    fig.savefig(output_path, dpi=300, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)
    return output_path


def plot_trajectory_small_multiples() -> Path:
    set_plot_theme()
    payloads = load_all_seed_payloads()
    all_ood = [float(row["ood_accuracy"]) for payload in payloads for row in payload["rows"]]
    y_min = min(all_ood) - 0.004
    y_max = max(all_ood) + 0.004
    steps_reference = [int(row["step"]) for row in payloads[0]["rows"]]
    tick_positions = [steps_reference[0], steps_reference[3], steps_reference[6], steps_reference[-1]]

    fig, axes = plt.subplots(2, 4, figsize=(13.0, 5.6), sharex=True, sharey=True)
    fig.patch.set_facecolor("white")
    axes = axes.flatten()

    for ax, payload in zip(axes, payloads):
        rows = payload["rows"]
        steps = np.array([int(row["step"]) for row in rows], dtype=float)
        ood = np.array([float(row["ood_accuracy"]) for row in rows], dtype=float)

        best_scope = payload["best_scope_checkpoint"]
        best_ood = payload["best_ood_checkpoint"]
        last = payload["last_checkpoint"]

        ax.plot(steps, ood, color="#E45756", marker="s", markersize=4.3, linewidth=2.1)
        ax.scatter(
            [best_scope["step"]],
            [best_scope["ood_accuracy"]],
            s=56,
            color=COLORS["purple_dark"],
            edgecolor="white",
            linewidth=0.8,
            zorder=5,
        )
        ax.scatter(
            [best_ood["step"]],
            [best_ood["ood_accuracy"]],
            s=132,
            marker="*",
            color=COLORS["gold"],
            edgecolor=COLORS["ink"],
            linewidth=0.7,
            zorder=6,
        )
        ax.scatter(
            [last["step"]],
            [last["ood_accuracy"]],
            s=44,
            marker="s",
            color=COLORS["gray"],
            edgecolor="white",
            linewidth=0.7,
            zorder=6,
        )

        ax.set_title(f"Seed {payload['seed']}", fontsize=10.0, pad=6)
        ax.set_facecolor("white")
        ax.grid(alpha=0.18, linewidth=0.8)
        ax.set_axisbelow(True)
        ax.set_xlim(min(steps_reference) - 8, max(steps_reference) + 8)
        ax.set_ylim(y_min, y_max)
        ax.set_xticks(tick_positions)

    for idx, ax in enumerate(axes):
        if idx % 4 == 0:
            ax.set_ylabel("OOD accuracy")
        if idx >= 4:
            ax.set_xlabel("Checkpoint step")

    legend_handles = [
        Line2D([0], [0], color="#E45756", marker="s", linewidth=2.0, markersize=5, label="OOD accuracy"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor=COLORS["purple_dark"], markersize=7, label="SCOPE-selected checkpoint"),
        Line2D([0], [0], marker="*", color="w", markerfacecolor=COLORS["gold"], markeredgecolor=COLORS["ink"], markersize=11, label="Oracle Best-OOD"),
        Line2D([0], [0], marker="s", color="w", markerfacecolor=COLORS["gray"], markersize=6, label="Last checkpoint"),
    ]
    fig.legend(
        handles=legend_handles,
        loc="upper center",
        ncol=4,
        frameon=False,
        bbox_to_anchor=(0.5, 0.985),
        columnspacing=1.2,
        handlelength=2.3,
    )
    fig.subplots_adjust(left=0.06, right=0.99, bottom=0.10, top=0.84, wspace=0.16, hspace=0.22)
    output_path = PAPER_RESULTS_DIR / "trajectory_small_multiples.png"
    fig.savefig(output_path, dpi=300, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)
    return output_path


def plot_seedwise_paired_delta() -> Path:
    set_plot_theme()
    payloads = load_all_seed_payloads()
    summary = read_json(MULTISEED_DIR / "multiseed_summary.json")
    comparisons = [
        ("last_checkpoint", "Last", summary["paired_tests"]["scope_minus_last"]),
        ("best_id_checkpoint", "Best-ID", summary["paired_tests"]["scope_minus_best_id"]),
    ]
    seed_labels = [str(payload["seed"])[-4:] for payload in payloads]
    mean_y = len(payloads)

    all_points: list[float] = []
    for checkpoint_key, _, paired in comparisons:
        all_points.extend(
            [
                100.0 * (float(payload["best_scope_checkpoint"]["ood_accuracy"]) - float(payload[checkpoint_key]["ood_accuracy"]))
                for payload in payloads
            ]
        )
        all_points.extend([100.0 * float(paired["ci95_low"]), 100.0 * float(paired["ci95_high"])])
    x_min = min(-0.25, min(all_points) - 0.15)
    x_max = max(all_points) + 0.35

    fig, axes = plt.subplots(1, 2, figsize=(11.6, 5.3), sharey=True)
    fig.patch.set_facecolor("white")

    for ax, (checkpoint_key, baseline_name, paired) in zip(axes, comparisons):
        deltas = [
            100.0 * (float(payload["best_scope_checkpoint"]["ood_accuracy"]) - float(payload[checkpoint_key]["ood_accuracy"]))
            for payload in payloads
        ]
        ax.axvline(0.0, color=COLORS["slate"], linewidth=1.2, linestyle=":")
        ax.axvspan(0.0, x_max, color=COLORS["purple"], alpha=0.18)

        for y, delta in enumerate(deltas):
            point_color = COLORS["purple_dark"] if delta >= 0 else COLORS["red_dark"]
            ax.hlines(y, 0.0, delta, color=point_color, linewidth=2.0, alpha=0.95)
            ax.scatter(delta, y, s=56, color=point_color, edgecolor="white", linewidth=0.8, zorder=4)
            text_dx = 0.05 if delta >= 0 else -0.05
            ha = "left" if delta >= 0 else "right"
            ax.text(delta + text_dx, y, f"{delta:+.2f}", va="center", ha=ha, fontsize=8.4, color=point_color)

        mean_pp = 100.0 * float(paired["mean_diff_ood"])
        low_pp = 100.0 * float(paired["ci95_low"])
        high_pp = 100.0 * float(paired["ci95_high"])
        ax.errorbar(
            mean_pp,
            mean_y,
            xerr=np.array([[mean_pp - low_pp], [high_pp - mean_pp]]),
            fmt="D",
            markersize=7,
            color="black",
            capsize=4,
            linewidth=1.6,
            zorder=5,
        )

        ax.set_title(
            f"SCOPE - {baseline_name}\nmean {mean_pp:+.2f} pp, $p$={float(paired['p_value_signflip']):.4f}",
            fontsize=11.5,
            pad=10,
            color=COLORS["navy"],
        )
        ax.set_xlim(x_min, x_max)
        ax.set_xlabel("OOD delta (percentage points)")
        ax.grid(axis="x", alpha=0.18, linewidth=0.8)
        ax.set_axisbelow(True)
        ax.set_facecolor("white")
        ax.set_yticks(list(range(len(seed_labels))) + [mean_y])
        ax.set_ylim(-0.7, mean_y + 0.8)
        ax.invert_yaxis()
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    axes[0].set_yticklabels(seed_labels + ["Mean"])
    axes[0].set_ylabel("Seed")
    axes[1].set_yticklabels(seed_labels + ["Mean"])

    baseline_handles = [
        Line2D([0], [0], color=COLORS["purple_dark"], linewidth=2.0, marker="o", markersize=6, label="Per-seed delta"),
        Line2D([0], [0], color="black", linewidth=1.6, marker="D", markersize=6, label="Mean and empirical 95% interval"),
        Line2D([0], [0], color=COLORS["slate"], linewidth=1.2, linestyle=":", label="No improvement"),
    ]
    fig.legend(handles=baseline_handles, loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(0.5, 1.03))
    fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.90))
    output_path = PAPER_RESULTS_DIR / "seedwise_paired_delta.png"
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_failure_breakdown() -> Path:
    set_plot_theme()
    selectors = {
        "Last": "last_checkpoint",
        "SCOPE": "best_scope_checkpoint",
        "Oracle Best-OOD": "best_ood_checkpoint",
    }
    sources = [("svamp", "SVAMP"), ("multiarith", "MultiArith"), ("asdiv", "ASDiv")]
    values: dict[str, dict[str, list[float]]] = {
        selector: {source_key: [] for source_key, _ in sources} for selector in selectors
    }

    for seed in SEEDS:
        payload = load_seed_payload(seed)
        for selector_label, checkpoint_key in selectors.items():
            checkpoint = payload[checkpoint_key]
            row = checkpoint_row(payload, int(checkpoint["step"]))
            breakdown = row["ood_source_breakdown"]
            for source_key, _ in sources:
                values[selector_label][source_key].append(float(breakdown[source_key]["accuracy"]))

    ordered_selectors = ["Last", "SCOPE", "Oracle Best-OOD"]
    colors = {
        "Last": COLORS["gray"],
        "SCOPE": COLORS["purple_dark"],
        "Oracle Best-OOD": "#D98E04",
    }

    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    x_positions = list(range(len(sources)))
    width = 0.24

    for idx, selector_label in enumerate(ordered_selectors):
        offsets = [x + (idx - 1) * width for x in x_positions]
        means = [mean(values[selector_label][source_key]) for source_key, _ in sources]
        errors = [stdev(values[selector_label][source_key]) if len(values[selector_label][source_key]) > 1 else 0.0 for source_key, _ in sources]
        ax.bar(
            offsets,
            means,
            width=width,
            yerr=errors,
            capsize=4,
            label=selector_label,
            color=colors[selector_label],
            edgecolor="white",
            linewidth=0.8,
        )

    ax.set_xticks(x_positions)
    ax.set_xticklabels([label for _, label in sources])
    ax.set_ylabel("OOD accuracy")
    ax.set_ylim(0.0, 0.85)
    ax.grid(axis="y", alpha=0.18, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.legend(loc="upper left", frameon=False, ncol=3, columnspacing=1.2)
    ax.text(
        0.98,
        0.04,
        "SCOPE strongest on SVAMP;\nMultiArith remains brittle.",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=9,
        bbox=dict(boxstyle="round,pad=0.25", facecolor="white", edgecolor="0.85", alpha=0.92),
    )

    fig.tight_layout()
    output_path = PAPER_RESULTS_DIR / "failure_breakdown.png"
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def main() -> None:
    PAPER_DIAGRAMS_DIR.mkdir(parents=True, exist_ok=True)
    PAPER_RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    outputs = {
        "method_overview": str(plot_method_overview().resolve()),
        "data_contract_overview": str(plot_data_contract_figure().resolve()),
        "trajectory_plot_neurips": str(plot_trajectory().resolve()),
        "trajectory_small_multiples": str(plot_trajectory_small_multiples().resolve()),
        "seedwise_paired_delta": str(plot_seedwise_paired_delta().resolve()),
        "failure_breakdown": str(plot_failure_breakdown().resolve()),
    }
    print(json.dumps(outputs, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
