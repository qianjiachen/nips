#!/usr/bin/env python3
"""Summarize selector behavior split by whether a seed exhibits a non-monotonic OOD trajectory."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    if not values:
        return math.nan
    return sum(values) / len(values)


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def fmt_mean_std(mu: float, sigma: float) -> str:
    return f"{mu:.4f} $\\pm$ {sigma:.4f}"


def bucket_name(flag: bool) -> str:
    return "non_monotonic" if flag else "monotonic"


def summarize_bucket(rows: list[dict[str, Any]]) -> dict[str, Any]:
    scope = [float(row["best_scope_ood"]) for row in rows]
    last = [float(row["last_ood"]) for row in rows]
    best_id = [float(row["best_id_ood"]) for row in rows]
    oracle = [float(row["oracle_ood"]) for row in rows]
    return {
        "n_seeds": len(rows),
        "seed_ids": [int(row["seed"]) for row in rows],
        "scope_mean": mean(scope),
        "scope_std": std(scope),
        "last_mean": mean(last),
        "last_std": std(last),
        "best_id_mean": mean(best_id),
        "best_id_std": std(best_id),
        "oracle_mean": mean(oracle),
        "oracle_std": std(oracle),
        "scope_minus_last_mean": mean([s - l for s, l in zip(scope, last)]),
        "scope_minus_best_id_mean": mean([s - b for s, b in zip(scope, best_id)]),
        "scope_regret_mean": mean([o - s for o, s in zip(oracle, scope)]),
    }


def write_latex_table(path: Path, summary: dict[str, Any]) -> None:
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\caption{Post-hoc split of the public-transfer main run by whether the per-seed OOD trajectory is non-monotonic.}")
    lines.append("\\label{tab:regime-split}")
    lines.append("\\setlength{\\tabcolsep}{3.5pt}")
    lines.append("\\resizebox{\\linewidth}{!}{%")
    lines.append("\\begin{tabular}{lccccccc}")
    lines.append("\\toprule")
    lines.append("Bucket & Seeds & Last OOD & Best-ID OOD & SCOPE OOD & Oracle OOD & SCOPE$-$Last & SCOPE$-$Best-ID \\\\")
    lines.append("\\midrule")
    for key, label in [("non_monotonic", "Non-monotonic"), ("monotonic", "Monotonic / near-monotonic")]:
        row = summary[key]
        lines.append(
            f"{label} & {row['n_seeds']} & "
            f"{fmt_mean_std(row['last_mean'], row['last_std'])} & "
            f"{fmt_mean_std(row['best_id_mean'], row['best_id_std'])} & "
            f"{fmt_mean_std(row['scope_mean'], row['scope_std'])} & "
            f"{fmt_mean_std(row['oracle_mean'], row['oracle_std'])} & "
            f"{row['scope_minus_last_mean']:+.4f} & "
            f"{row['scope_minus_best_id_mean']:+.4f} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("}%")
    lines.append("\\end{table}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    split_rows: dict[str, list[dict[str, Any]]] = {"non_monotonic": [], "monotonic": []}

    for path in args.analysis_files:
        payload = read_json(path)
        bucket = bucket_name(bool(payload.get("non_monotonic_ood")))
        split_rows[bucket].append(
            {
                "seed": int(payload["seed"]),
                "best_scope_ood": float(payload["best_scope_checkpoint"]["ood_accuracy"]),
                "best_id_ood": float(payload["best_id_checkpoint"]["ood_accuracy"]),
                "last_ood": float(payload["last_checkpoint"]["ood_accuracy"]),
                "oracle_ood": float(payload["best_ood_checkpoint"]["ood_accuracy"]),
            }
        )

    output = {
        "non_monotonic": summarize_bucket(split_rows["non_monotonic"]),
        "monotonic": summarize_bucket(split_rows["monotonic"]),
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(output, ensure_ascii=True, indent=2), encoding="utf-8")
    write_latex_table(args.output_tex, output)
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
