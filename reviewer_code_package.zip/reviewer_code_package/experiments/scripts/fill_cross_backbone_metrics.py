#!/usr/bin/env python3
"""Fill cross-backbone metric macros in TeX from cross-backbone summary JSON."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cross-json", type=Path, required=True)
    parser.add_argument("--tex-file", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def sanitize_latex_text(text: str) -> str:
    return text.replace("_", "\\_")


def replace_macro(tex: str, macro: str, value: str) -> str:
    pattern = re.compile(rf"(\\newcommand\{{\\{re.escape(macro)}\}}\{{)(.*?)\}}")
    return pattern.sub(rf"\g<1>{value}}}", tex)


def signed4(x: float) -> str:
    return f"{x:+.4f}"


def fixed4(x: float) -> str:
    return f"{x:.4f}"


def main() -> None:
    args = parse_args()
    payload = read_json(args.cross_json)
    rows = payload.get("rows", [])
    if len(rows) < 2:
        raise ValueError("cross-json rows should contain at least two backbones.")

    row_a = rows[0]
    row_b = rows[1]

    tex = args.tex_file.read_text(encoding="utf-8")
    tex = replace_macro(tex, "crossbackbonebase", sanitize_latex_text(str(row_a["label"])))
    tex = replace_macro(tex, "crossbackbonenew", sanitize_latex_text(str(row_b["label"])))
    tex = replace_macro(tex, "crossdeltaoodbase", signed4(float(row_a["scope_minus_last_mean"])))
    tex = replace_macro(tex, "crosspbase", fixed4(float(row_a["scope_minus_last_p"])))
    tex = replace_macro(tex, "crossdeltaoodnew", signed4(float(row_b["scope_minus_last_mean"])))
    tex = replace_macro(tex, "crosspnew", fixed4(float(row_b["scope_minus_last_p"])))
    args.tex_file.write_text(tex, encoding="utf-8")
    print(
        json.dumps(
            {
                "tex_file": str(args.tex_file.resolve()),
                "row_a_label": row_a["label"],
                "row_b_label": row_b["label"],
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
