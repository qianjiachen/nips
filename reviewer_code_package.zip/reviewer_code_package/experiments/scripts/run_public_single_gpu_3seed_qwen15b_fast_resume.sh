﻿#!/usr/bin/env bash
set -euo pipefail

cd /root/autodl-tmp/nips

PYTHON_BIN="${PYTHON_BIN:-/root/miniconda3/bin/python}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HUB_ENDPOINT="${HF_HUB_ENDPOINT:-https://hf-mirror.com}"
export HF_HUB_DISABLE_XET="${HF_HUB_DISABLE_XET:-1}"
export HF_HUB_DOWNLOAD_TIMEOUT="${HF_HUB_DOWNLOAD_TIMEOUT:-600}"
export HF_HUB_ETAG_TIMEOUT="${HF_HUB_ETAG_TIMEOUT:-60}"
unset HF_HUB_ENABLE_HF_TRANSFER
export HUGGINGFACE_HUB_CACHE="${HUGGINGFACE_HUB_CACHE:-/root/autodl-tmp/hf-cache}"
mkdir -p "$HUGGINGFACE_HUB_CACHE" outputs

SEEDS=(20260320 20260321 20260322)
CONFIG="experiments/configs/public_transfer_qwen25_15b_xvalid_fast.json"
TAG="public_transfer_qwen25_15b_xvalid_fast_3seed"
OUTDIR="experiments/runs/intermediate/public_transfer_qwen25_15b_xvalid_fast_multiseed_3seed"

for seed in "${SEEDS[@]}"; do
  analysis_path="experiments/runs/intermediate/public_transfer_qwen25_15b_xvalid_fast_seed${seed}/analysis/analysis.json"
  control_path="experiments/runs/intermediate/public_transfer_qwen25_15b_xvalid_fast_seed${seed}/control_selectors.json"
  if [ -f "$analysis_path" ] && [ -f "$control_path" ]; then
    echo "[$(date '+%F %T')] skip seed=${seed} because analysis/control artifacts already exist"
    continue
  fi

  echo "[$(date '+%F %T')] start seed=${seed}"
  rm -f experiments/runs/intermediate/.run_public_multiseed.lock
  "$PYTHON_BIN" experiments/scripts/run_public_multiseed.py \
    --config "$CONFIG" \
    --seeds "$seed" \
    --train-gpus 0 \
    --eval-gpu 0 \
    --desired-checkpoints 6 \
    --enable-rrd \
    --allow-remote \
    --skip-data-prep \
    --eval-max-samples 300 \
    --score-max-samples 256 \
    --force
  echo "[$(date '+%F %T')] done seed=${seed}"
done

analysis_files=()
control_files=()
for seed in "${SEEDS[@]}"; do
  a="experiments/runs/intermediate/public_transfer_qwen25_15b_xvalid_fast_seed${seed}/analysis/analysis.json"
  c="experiments/runs/intermediate/public_transfer_qwen25_15b_xvalid_fast_seed${seed}/control_selectors.json"
  if [ -f "$a" ]; then analysis_files+=("$a"); fi
  if [ -f "$c" ]; then control_files+=("$c"); fi
done

if [ ${#analysis_files[@]} -lt 3 ]; then
  echo "[$(date '+%F %T')] ERROR: expected 3 analysis files, got ${#analysis_files[@]}"
  exit 1
fi
if [ ${#control_files[@]} -lt 3 ]; then
  echo "[$(date '+%F %T')] ERROR: expected 3 control files, got ${#control_files[@]}"
  exit 1
fi

mkdir -p "$OUTDIR"

"$PYTHON_BIN" experiments/scripts/aggregate_multiseed.py \
  --analysis-files "${analysis_files[@]}" \
  --output-dir "$OUTDIR" \
  --tag "$TAG"

"$PYTHON_BIN" experiments/scripts/plot_results.py \
  --multiseed-json "$OUTDIR/multiseed_summary.json" \
  --output-dir "$OUTDIR" \
  --tag "$TAG"

"$PYTHON_BIN" experiments/scripts/aggregate_control_selectors.py \
  --control-files "${control_files[@]}" \
  --analysis-files "${analysis_files[@]}" \
  --output-file "$OUTDIR/control_selector_summary.json"

echo "[$(date '+%F %T')] resumable fast 3-seed run finished"
echo "[$(date '+%F %T')] multiseed json: $OUTDIR/multiseed_summary.json"

