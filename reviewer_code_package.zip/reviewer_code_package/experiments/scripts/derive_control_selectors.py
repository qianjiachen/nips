#!/usr/bin/env python3
"""Derive control selectors from checkpoint trajectory without additional training."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eval-file", type=Path, required=True)
    parser.add_argument("--output-file", type=Path, required=True)
    parser.add_argument("--patience", type=int, default=2)
    parser.add_argument("--fixed-fraction", type=float, default=0.7)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def checkpoint_step(name: str) -> int:
    if name.startswith("checkpoint-"):
        try:
            return int(name.split("-", 1)[1])
        except ValueError:
            return 10**9
    return 10**9


def select_last(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (checkpoint_step(r["checkpoint"]), r["checkpoint"]))


def select_best_id(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (r.get("id_accuracy", -1.0), -checkpoint_step(r["checkpoint"])))


def select_best_ood(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (r.get("ood_accuracy", -1.0), -checkpoint_step(r["checkpoint"])))


def select_fixed_fraction(rows: list[dict[str, Any]], fraction: float) -> dict[str, Any]:
    sorted_rows = sorted(rows, key=lambda r: checkpoint_step(r["checkpoint"]))
    idx = int(round((len(sorted_rows) - 1) * max(0.0, min(1.0, fraction))))
    return sorted_rows[idx]


def select_id_patience(rows: list[dict[str, Any]], patience: int) -> dict[str, Any]:
    sorted_rows = sorted(rows, key=lambda r: checkpoint_step(r["checkpoint"]))
    best = sorted_rows[0]
    best_id = best.get("id_accuracy", -1.0)
    wait = 0
    for row in sorted_rows[1:]:
        cur = row.get("id_accuracy", -1.0)
        if cur > best_id:
            best = row
            best_id = cur
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                return best
    return best


def pack(name: str, row: dict[str, Any], oracle_ood: float) -> dict[str, Any]:
    return {
        "selector": name,
        "checkpoint": row["checkpoint"],
        "id_accuracy": row.get("id_accuracy"),
        "ood_accuracy": row.get("ood_accuracy"),
        "ood_regret": (oracle_ood - row.get("ood_accuracy", 0.0)) if row.get("ood_accuracy") is not None else None,
    }


def main() -> None:
    args = parse_args()
    payload = read_json(args.eval_file)
    rows = payload.get("results", [])
    if not rows:
        raise ValueError("No checkpoint rows found in eval file.")

    last = select_last(rows)
    best_id = select_best_id(rows)
    best_ood = select_best_ood(rows)
    fixed = select_fixed_fraction(rows, args.fixed_fraction)
    id_patience = select_id_patience(rows, args.patience)
    oracle_ood = float(best_ood.get("ood_accuracy", 0.0))

    out = {
        "seed": payload.get("seed"),
        "selectors": [
            pack("last", last, oracle_ood),
            pack("best_id", best_id, oracle_ood),
            pack("fixed_fraction", fixed, oracle_ood),
            pack("id_patience", id_patience, oracle_ood),
            pack("best_ood_oracle", best_ood, oracle_ood),
        ],
        "meta": {
            "patience": args.patience,
            "fixed_fraction": args.fixed_fraction,
        },
    }
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    args.output_file.write_text(json.dumps(out, ensure_ascii=True, indent=2), encoding="utf-8")
    print(json.dumps({"output_file": str(args.output_file.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
