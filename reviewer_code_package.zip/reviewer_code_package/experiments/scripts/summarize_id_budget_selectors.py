#!/usr/bin/env python3
"""Summarize ID-budgeted SCOPE selectors from existing trajectory analysis files."""

from __future__ import annotations

import argparse
import json
import math
from itertools import product
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    parser.add_argument("--margin-std", type=float, default=0.5)
    parser.add_argument("--id-deltas", type=float, nargs="+", default=[0.005, 0.01, 0.015])
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    if not values:
        return math.nan
    return sum(values) / len(values)


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def percentile(sorted_vals: list[float], q: float) -> float:
    if not sorted_vals:
        return math.nan
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    idx = (len(sorted_vals) - 1) * q
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return sorted_vals[lo]
    frac = idx - lo
    return sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac


def ci95(values: list[float]) -> tuple[float, float]:
    if not values:
        return (math.nan, math.nan)
    if len(values) == 1:
        return (values[0], values[0])
    sorted_vals = sorted(values)
    return (percentile(sorted_vals, 0.025), percentile(sorted_vals, 0.975))


def paired_signflip_pvalue(diffs: list[float]) -> float:
    if not diffs:
        return math.nan
    observed = abs(mean(diffs))
    total = 0
    extreme = 0
    for signs in product([-1.0, 1.0], repeat=len(diffs)):
        perm_mean = abs(mean([d * s for d, s in zip(diffs, signs)]))
        total += 1
        if perm_mean >= observed - 1e-12:
            extreme += 1
    return extreme / total


def sort_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(rows, key=lambda r: int(r.get("step", 10**9)))


def select_last(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: int(r.get("step", -1)))


def select_best_id(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (float(r.get("id_accuracy", -1.0)), -int(r.get("step", 10**9))))


def select_best_ood(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda r: (float(r.get("ood_accuracy", -1.0)), -int(r.get("step", 10**9))))


def select_scope_plateau(rows: list[dict[str, Any]], margin_std: float) -> dict[str, Any]:
    scores = [float(r["scope_score"]) for r in rows if r.get("scope_score") is not None]
    max_score = max(scores)
    score_mean = mean(scores)
    score_var = sum((s - score_mean) ** 2 for s in scores) / len(scores)
    score_std = math.sqrt(score_var)
    threshold = max_score - margin_std * score_std
    eligible = [r for r in sort_rows(rows) if float(r.get("scope_score", -1e9)) >= threshold]
    if not eligible:
        return max(rows, key=lambda r: float(r.get("scope_score", -1e9)))
    return eligible[0]


def select_id_budget_scope(rows: list[dict[str, Any]], margin_std: float, delta: float) -> dict[str, Any]:
    best_id = float(select_best_id(rows).get("id_accuracy", -1.0))
    eligible = [r for r in rows if float(r.get("id_accuracy", -1.0)) >= best_id - delta]
    return select_scope_plateau(eligible if eligible else rows, margin_std=margin_std)


def aggregate_selector(seed_to_row: dict[int, dict[str, Any]]) -> dict[str, float]:
    id_vals = [float(v["id_accuracy"]) for v in seed_to_row.values()]
    ood_vals = [float(v["ood_accuracy"]) for v in seed_to_row.values()]
    regret_vals = [float(v["ood_regret"]) for v in seed_to_row.values()]
    id_ci_low, id_ci_high = ci95(id_vals)
    ood_ci_low, ood_ci_high = ci95(ood_vals)
    reg_ci_low, reg_ci_high = ci95(regret_vals)
    return {
        "n_seeds": len(seed_to_row),
        "id_accuracy_mean": mean(id_vals),
        "id_accuracy_std": std(id_vals),
        "id_accuracy_ci95_low": id_ci_low,
        "id_accuracy_ci95_high": id_ci_high,
        "ood_accuracy_mean": mean(ood_vals),
        "ood_accuracy_std": std(ood_vals),
        "ood_accuracy_ci95_low": ood_ci_low,
        "ood_accuracy_ci95_high": ood_ci_high,
        "ood_regret_mean": mean(regret_vals),
        "ood_regret_std": std(regret_vals),
        "ood_regret_ci95_low": reg_ci_low,
        "ood_regret_ci95_high": reg_ci_high,
    }


def paired_stats(lhs: dict[int, dict[str, Any]], rhs: dict[int, dict[str, Any]]) -> dict[str, float]:
    common = sorted(set(lhs) & set(rhs))
    diffs = [float(lhs[s]["ood_accuracy"]) - float(rhs[s]["ood_accuracy"]) for s in common]
    ci_low, ci_high = ci95(diffs)
    return {
        "n_pairs": len(diffs),
        "mean_diff_ood": mean(diffs),
        "ci95_low": ci_low,
        "ci95_high": ci_high,
        "p_value_signflip": paired_signflip_pvalue(diffs),
    }


def format_mean_std(mu: float, sigma: float) -> str:
    return f"{mu:.4f} $\\pm$ {sigma:.4f}"


def write_latex_table(path: Path, summary: dict[str, Any], deltas: list[float]) -> None:
    base = summary["selectors"]
    num_seeds = int(summary.get("num_seeds", 0))
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(
        f"\\caption{{ID-budgeted SCOPE on the same {num_seeds}-seed public-transfer trajectories "
        "(post-hoc selector-only analysis; no additional training runs).}"
    )
    lines.append("\\label{tab:idbudget}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Selector & ID Acc & OOD Acc & Regret to Oracle \\\\")
    lines.append("\\midrule")
    for key, label in [
        ("last", "Last"),
        ("best_id", "Best-ID"),
        ("best_scope", "SCOPE ($0.5\\sigma$, unconstrained)"),
    ]:
        row = base[key]
        lines.append(
            f"{label} & "
            f"{format_mean_std(row['id_accuracy_mean'], row['id_accuracy_std'])} & "
            f"{format_mean_std(row['ood_accuracy_mean'], row['ood_accuracy_std'])} & "
            f"{row['ood_regret_mean']:.4f} \\\\"
        )
    lines.append("\\midrule")
    for delta in deltas:
        key = f"id_budget_scope_delta_{delta:.4f}"
        row = base[key]
        lines.append(
            f"ID-budget SCOPE ($\\Delta_{{\\mathrm{{ID}}}}\\leq {delta:.4f}$) & "
            f"{format_mean_std(row['id_accuracy_mean'], row['id_accuracy_std'])} & "
            f"{format_mean_std(row['ood_accuracy_mean'], row['ood_accuracy_std'])} & "
            f"{row['ood_regret_mean']:.4f} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    deltas = sorted(set(args.id_deltas))
    seeds: list[int] = []

    selected: dict[str, dict[int, dict[str, Any]]] = {
        "last": {},
        "best_id": {},
        "best_scope": {},
        "best_ood": {},
    }
    for delta in deltas:
        selected[f"id_budget_scope_delta_{delta:.4f}"] = {}

    for path in args.analysis_files:
        payload = read_json(path)
        seed = int(payload["seed"])
        seeds.append(seed)
        rows = sort_rows(payload.get("rows", []))
        if not rows:
            continue

        last = select_last(rows)
        best_id = select_best_id(rows)
        best_scope = select_scope_plateau(rows, margin_std=args.margin_std)
        best_ood = select_best_ood(rows)
        oracle_ood = float(best_ood["ood_accuracy"])

        for key, row in [
            ("last", last),
            ("best_id", best_id),
            ("best_scope", best_scope),
            ("best_ood", best_ood),
        ]:
            selected[key][seed] = {
                "checkpoint": row["checkpoint"],
                "id_accuracy": float(row["id_accuracy"]),
                "ood_accuracy": float(row["ood_accuracy"]),
                "ood_regret": oracle_ood - float(row["ood_accuracy"]),
            }

        for delta in deltas:
            key = f"id_budget_scope_delta_{delta:.4f}"
            row = select_id_budget_scope(rows, margin_std=args.margin_std, delta=delta)
            selected[key][seed] = {
                "checkpoint": row["checkpoint"],
                "id_accuracy": float(row["id_accuracy"]),
                "ood_accuracy": float(row["ood_accuracy"]),
                "ood_regret": oracle_ood - float(row["ood_accuracy"]),
            }

    selectors_summary: dict[str, Any] = {}
    for key, by_seed in selected.items():
        selectors_summary[key] = aggregate_selector(by_seed)

    paired_tests: dict[str, Any] = {
        "scope_minus_last": paired_stats(selected["best_scope"], selected["last"]),
        "scope_minus_best_id": paired_stats(selected["best_scope"], selected["best_id"]),
    }
    for delta in deltas:
        key = f"id_budget_scope_delta_{delta:.4f}"
        paired_tests[f"{key}_minus_last"] = paired_stats(selected[key], selected["last"])
        paired_tests[f"{key}_minus_best_id"] = paired_stats(selected[key], selected["best_id"])
        paired_tests[f"{key}_minus_scope"] = paired_stats(selected[key], selected["best_scope"])

    output = {
        "num_seeds": len(set(seeds)),
        "margin_std": args.margin_std,
        "id_deltas": deltas,
        "selectors": selectors_summary,
        "paired_tests": paired_tests,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(output, ensure_ascii=True, indent=2), encoding="utf-8")
    write_latex_table(args.output_tex, output, deltas=deltas)
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
