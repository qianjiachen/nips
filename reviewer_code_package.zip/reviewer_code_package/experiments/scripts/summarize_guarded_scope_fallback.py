#!/usr/bin/env python3
"""Summarize an exploratory guarded-SCOPE fallback using existing selector outputs."""

from __future__ import annotations

import argparse
import json
import math
from itertools import product
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selector-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    parser.add_argument("--aux-selector", type=str, default="top1_ratio_min")
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    if not values:
        return math.nan
    return sum(values) / len(values)


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def paired_signflip_pvalue(diffs: list[float]) -> float:
    usable = [x for x in diffs if not math.isnan(x)]
    if not usable:
        return math.nan
    observed = abs(mean(usable))
    total = 0
    extreme = 0
    for signs in product([-1.0, 1.0], repeat=len(usable)):
        perm_mean = abs(mean([d * s for d, s in zip(usable, signs)]))
        total += 1
        if perm_mean >= observed - 1e-12:
            extreme += 1
    return extreme / total


def get_selector(payload: dict[str, Any], name: str) -> dict[str, Any]:
    for selector in payload.get("selectors", []):
        if selector.get("selector") == name:
            return selector
    raise KeyError(f"Missing selector {name}")


def aggregate_rows(rows: list[dict[str, Any]], oracle_rows: list[dict[str, Any]]) -> dict[str, Any]:
    regrets = [float(oracle["ood_accuracy"]) - float(row["ood_accuracy"]) for row, oracle in zip(rows, oracle_rows)]
    return {
        "n_seeds": len(rows),
        "id_accuracy_mean": mean([float(row["id_accuracy"]) for row in rows]),
        "id_accuracy_std": std([float(row["id_accuracy"]) for row in rows]),
        "ood_accuracy_mean": mean([float(row["ood_accuracy"]) for row in rows]),
        "ood_accuracy_std": std([float(row["ood_accuracy"]) for row in rows]),
        "ood_regret_mean": mean(regrets),
        "ood_regret_std": std(regrets),
        "checkpoints": [str(row["checkpoint"]) for row in rows],
    }


def format_mean_std(mu: float, sigma: float) -> str:
    return f"{mu:.4f} $\\pm$ {sigma:.4f}"


def write_latex_table(path: Path, summary: dict[str, Any]) -> None:
    rows = summary["selectors"]
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(
        "\\caption{Exploratory guarded-SCOPE fallback on the final public-transfer benchmark (8 seeds). "
        "The guarded rule applies SCOPE only when an independent auxiliary selector "
        f"(here \\texttt{{{summary['aux_selector_label']}}}) also rejects the last checkpoint; "
        "otherwise it falls back to \\texttt{Last}. This is a post-hoc selector-only diagnostic on the same trajectories.}"
    )
    lines.append("\\label{tab:guarded-fallback}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Selector & ID Acc & OOD Acc & Regret to Oracle \\\\")
    lines.append("\\midrule")
    for key, label in [
        ("last", "Last"),
        ("best_scope", "SCOPE"),
        ("aux_selector", summary["aux_selector_label"]),
        ("guarded_scope", f"Guarded SCOPE ({summary['aux_selector_label']})"),
        ("best_ood_oracle", "Oracle Best-OOD"),
    ]:
        row = rows[key]
        lines.append(
            f"{label} & "
            f"{format_mean_std(row['id_accuracy_mean'], row['id_accuracy_std'])} & "
            f"{format_mean_std(row['ood_accuracy_mean'], row['ood_accuracy_std'])} & "
            f"{row['ood_regret_mean']:.4f} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    payloads = [read_json(path) for path in args.selector_files]
    rows_by_name: dict[str, list[dict[str, Any]]] = {
        "last": [],
        "best_scope": [],
        "aux_selector": [],
        "best_ood_oracle": [],
        "guarded_scope": [],
    }

    for payload in payloads:
        last = get_selector(payload, "last")
        scope = get_selector(payload, "best_scope")
        aux = get_selector(payload, args.aux_selector)
        oracle = get_selector(payload, "best_ood_oracle")
        guarded = scope if aux["checkpoint"] != last["checkpoint"] else last
        rows_by_name["last"].append(last)
        rows_by_name["best_scope"].append(scope)
        rows_by_name["aux_selector"].append(aux)
        rows_by_name["best_ood_oracle"].append(oracle)
        rows_by_name["guarded_scope"].append(guarded)

    oracle_rows = rows_by_name["best_ood_oracle"]
    selectors_summary = {
        key: aggregate_rows(value, oracle_rows)
        for key, value in rows_by_name.items()
    }
    paired_tests = {
        "guarded_minus_last": {
            "mean_diff_ood": mean([
                float(g["ood_accuracy"]) - float(l["ood_accuracy"])
                for g, l in zip(rows_by_name["guarded_scope"], rows_by_name["last"])
            ]),
            "p_value_signflip": paired_signflip_pvalue([
                float(g["ood_accuracy"]) - float(l["ood_accuracy"])
                for g, l in zip(rows_by_name["guarded_scope"], rows_by_name["last"])
            ]),
        },
        "guarded_minus_scope": {
            "mean_diff_ood": mean([
                float(g["ood_accuracy"]) - float(s["ood_accuracy"])
                for g, s in zip(rows_by_name["guarded_scope"], rows_by_name["best_scope"])
            ]),
            "p_value_signflip": paired_signflip_pvalue([
                float(g["ood_accuracy"]) - float(s["ood_accuracy"])
                for g, s in zip(rows_by_name["guarded_scope"], rows_by_name["best_scope"])
            ]),
        },
        "guarded_minus_aux": {
            "mean_diff_ood": mean([
                float(g["ood_accuracy"]) - float(a["ood_accuracy"])
                for g, a in zip(rows_by_name["guarded_scope"], rows_by_name["aux_selector"])
            ]),
            "p_value_signflip": paired_signflip_pvalue([
                float(g["ood_accuracy"]) - float(a["ood_accuracy"])
                for g, a in zip(rows_by_name["guarded_scope"], rows_by_name["aux_selector"])
            ]),
        },
    }

    output = {
        "num_seeds": len(payloads),
        "aux_selector": args.aux_selector,
        "aux_selector_label": "Min Top-1 Ratio" if args.aux_selector == "top1_ratio_min" else args.aux_selector,
        "selectors": selectors_summary,
        "paired_tests": paired_tests,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(output, ensure_ascii=True, indent=2), encoding="utf-8")
    write_latex_table(args.output_tex, output)
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
