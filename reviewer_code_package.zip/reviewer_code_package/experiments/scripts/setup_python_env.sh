#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3}"
ENV_DIR="${ENV_DIR:-.venv}"

if ! "${PYTHON_BIN}" -m venv "${ENV_DIR}"; then
  echo "[setup-env] python -m venv failed, installing virtualenv fallback"
  "${PYTHON_BIN}" -m pip install --user --break-system-packages virtualenv
  "${PYTHON_BIN}" -m virtualenv "${ENV_DIR}"
fi
source "${ENV_DIR}/bin/activate"
python -m pip install --upgrade pip wheel setuptools
python -m pip install --index-url https://download.pytorch.org/whl/cu121 torch==2.5.1 torchvision==0.20.1 torchaudio==2.5.1
python -m pip install -r requirements-wsl.txt
python - << 'PY'
import torch
print({"torch_version": torch.__version__, "cuda_available": torch.cuda.is_available(), "gpu_count": torch.cuda.device_count()})
PY
