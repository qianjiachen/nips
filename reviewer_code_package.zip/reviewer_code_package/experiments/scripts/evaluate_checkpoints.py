#!/usr/bin/env python3
"""Evaluate LoRA checkpoints on ID/OOD arithmetic datasets."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import re
from collections import defaultdict
from pathlib import Path

from workspace_paths import INTERMEDIATE_RUNS_DIR
from typing import Any

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


def patch_peft_upcast_dtypes() -> None:
    try:
        from peft.tuners import tuners_utils
    except Exception:  # noqa: BLE001
        return
    upcast_dtypes = getattr(tuners_utils, "UPCAST_DTYPES", None)
    if upcast_dtypes is None:
        return
    filtered = tuple(name for name in upcast_dtypes if hasattr(torch, name))
    if filtered != upcast_dtypes:
        tuners_utils.UPCAST_DTYPES = filtered


patch_peft_upcast_dtypes()


ANSWER_PATTERN = re.compile(r"-?\d+")


def has_bitsandbytes() -> bool:
    try:
        import bitsandbytes  # noqa: F401
    except ImportError:
        return False
    return True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--checkpoint-dir", type=Path, required=True)
    parser.add_argument("--tokenizer-path", type=Path, default=None)
    parser.add_argument("--id-file", type=Path, required=True)
    parser.add_argument("--ood-file", type=Path, required=True)
    parser.add_argument("--output-file", type=Path, default=INTERMEDIATE_RUNS_DIR / "eval_results.json")
    parser.add_argument("--max-new-tokens", type=int, default=32)
    parser.add_argument("--max-samples", type=int, default=0)
    parser.add_argument(
        "--sample-mode",
        choices=["head", "random", "stratified_source"],
        default="head",
        help="Sampling mode when --max-samples is set.",
    )
    parser.add_argument("--seed-id", type=int, default=None)
    parser.add_argument("--allow-remote", action="store_true")
    return parser.parse_args()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            rows.append(json.loads(line))
    return rows


def stable_int(text: str) -> int:
    digest = hashlib.md5(text.encode("utf-8")).hexdigest()  # noqa: S324
    return int(digest[:8], 16)


def source_name(row: dict[str, Any]) -> str:
    return str(row.get("metadata", {}).get("source", "unknown"))


def source_counts(rows: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        src = source_name(row)
        counts[src] = counts.get(src, 0) + 1
    return {key: counts[key] for key in sorted(counts)}


def sample_rows(
    rows: list[dict[str, Any]],
    limit: int | None,
    mode: str,
    seed: int,
) -> list[dict[str, Any]]:
    if limit is None or limit <= 0 or len(rows) <= limit:
        return list(rows)
    if mode == "head":
        return list(rows[:limit])
    if mode == "random":
        rng = random.Random(seed)
        picked = rng.sample(rows, limit)
        return list(picked)
    if mode != "stratified_source":
        raise ValueError(f"Unsupported sample mode: {mode}")

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[source_name(row)].append(row)
    keys = sorted(grouped)
    total = len(rows)
    raw = {key: (limit * len(grouped[key]) / total) for key in keys}
    alloc = {key: min(len(grouped[key]), int(raw[key])) for key in keys}
    used = sum(alloc.values())
    if used < limit:
        remainders = sorted(
            keys,
            key=lambda key: (raw[key] - int(raw[key]), key),
            reverse=True,
        )
        for key in remainders:
            if used >= limit:
                break
            if alloc[key] < len(grouped[key]):
                alloc[key] += 1
                used += 1
    if used < limit:
        for key in keys:
            while used < limit and alloc[key] < len(grouped[key]):
                alloc[key] += 1
                used += 1

    sampled: list[dict[str, Any]] = []
    for key in keys:
        group_rows = grouped[key]
        k = alloc[key]
        if k >= len(group_rows):
            picked = list(group_rows)
        else:
            local_rng = random.Random(seed + stable_int(key))
            picked = local_rng.sample(group_rows, k)
        sampled.extend(picked)

    final_rng = random.Random(seed + 9973)
    final_rng.shuffle(sampled)
    return sampled[:limit]


def list_checkpoints(path: Path) -> list[Path]:
    checkpoints = sorted(
        [p for p in path.iterdir() if p.is_dir() and p.name.startswith("checkpoint-")],
        key=lambda p: checkpoint_step(p.name),
    )
    if not checkpoints:
        checkpoints = [path]
    return checkpoints


def checkpoint_step(name: str) -> int:
    if name.startswith("checkpoint-"):
        try:
            return int(name.split("-", 1)[1])
        except ValueError:
            return 10**9
    return 10**9


def build_tokenizer(base_model: str, tokenizer_path: Path | None, local_files_only: bool) -> Any:
    candidates: list[str] = []
    if tokenizer_path is not None:
        candidates.append(str(tokenizer_path))
    candidates.append(base_model)
    last_error: Exception | None = None
    for candidate in candidates:
        try:
            tokenizer = AutoTokenizer.from_pretrained(
                candidate,
                use_fast=False,
                local_files_only=local_files_only,
            )
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            tokenizer.padding_side = "left"
            return tokenizer
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    if last_error is not None:
        raise last_error
    raise RuntimeError("Failed to build tokenizer.")


def build_base_model(base_model: str, local_files_only: bool) -> Any:
    use_4bit = torch.cuda.is_available() and has_bitsandbytes()
    quant_config = None
    if use_4bit:
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        )
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=quant_config,
        torch_dtype=torch.float16 if torch.cuda.is_available() and not use_4bit else (torch.bfloat16 if torch.cuda.is_available() else torch.float32),
        device_map="auto" if torch.cuda.is_available() else None,
        local_files_only=local_files_only,
    )
    model.eval()
    return model


def attach_adapter(base_model: Any, checkpoint_path: Path) -> Any:
    model = PeftModel.from_pretrained(base_model, checkpoint_path)
    model.eval()
    return model


def extract_answer(text: str) -> str:
    matches = ANSWER_PATTERN.findall(text)
    return matches[-1] if matches else ""


def generate_answer(model: Any, tokenizer: Any, prompt: str, max_new_tokens: int) -> str:
    encoded = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=384).to(model.device)
    with torch.no_grad():
        generated = model.generate(
            **encoded,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    new_tokens = generated[:, encoded["input_ids"].shape[1] :]
    text = tokenizer.decode(new_tokens[0], skip_special_tokens=True)
    return extract_answer(text)


def evaluate_rows(model: Any, tokenizer: Any, rows: list[dict[str, Any]], max_new_tokens: int) -> dict[str, Any]:
    correct = 0
    source_correct: dict[str, int] = {}
    source_total: dict[str, int] = {}
    shift_correct: dict[str, int] = {}
    shift_total: dict[str, int] = {}
    for row in rows:
        pred = generate_answer(model, tokenizer, row["prompt"], max_new_tokens)
        gold = str(row["answer"]).strip()
        is_correct = pred == gold
        correct += int(is_correct)
        source = str(row.get("metadata", {}).get("source", "unknown"))
        shift = str(row.get("shift_type", "unknown"))
        source_total[source] = source_total.get(source, 0) + 1
        shift_total[shift] = shift_total.get(shift, 0) + 1
        source_correct[source] = source_correct.get(source, 0) + int(is_correct)
        shift_correct[shift] = shift_correct.get(shift, 0) + int(is_correct)
    accuracy = correct / len(rows) if rows else 0.0
    source_breakdown = {
        key: {"count": source_total[key], "accuracy": source_correct.get(key, 0) / source_total[key]}
        for key in sorted(source_total)
    }
    shift_breakdown = {
        key: {"count": shift_total[key], "accuracy": shift_correct.get(key, 0) / shift_total[key]}
        for key in sorted(shift_total)
    }
    return {
        "accuracy": accuracy,
        "count": len(rows),
        "source_breakdown": source_breakdown,
        "shift_breakdown": shift_breakdown,
    }


def main() -> None:
    args = parse_args()
    sample_limit = None if args.max_samples <= 0 else args.max_samples
    sample_seed = args.seed_id if args.seed_id is not None else 0
    full_id_rows = read_jsonl(args.id_file)
    full_ood_rows = read_jsonl(args.ood_file)
    id_rows = sample_rows(full_id_rows, sample_limit, args.sample_mode, sample_seed)
    ood_rows = sample_rows(full_ood_rows, sample_limit, args.sample_mode, sample_seed + 1)
    local_files_only = not args.allow_remote
    tokenizer = build_tokenizer(args.base_model, args.tokenizer_path, local_files_only=local_files_only)

    results: list[dict[str, Any]] = []
    for checkpoint in list_checkpoints(args.checkpoint_dir):
        base_model = build_base_model(args.base_model, local_files_only=local_files_only)
        model = attach_adapter(base_model, checkpoint)
        id_metrics = evaluate_rows(model, tokenizer, id_rows, args.max_new_tokens)
        ood_metrics = evaluate_rows(model, tokenizer, ood_rows, args.max_new_tokens)
        results.append(
            {
                "checkpoint": checkpoint.name,
                "path": str(checkpoint.resolve()),
                "seed": args.seed_id,
                "id_accuracy": id_metrics["accuracy"],
                "ood_accuracy": ood_metrics["accuracy"],
                "id_count": id_metrics["count"],
                "ood_count": ood_metrics["count"],
                "id_source_breakdown": id_metrics["source_breakdown"],
                "ood_source_breakdown": ood_metrics["source_breakdown"],
                "id_shift_breakdown": id_metrics["shift_breakdown"],
                "ood_shift_breakdown": ood_metrics["shift_breakdown"],
            }
        )
        del model
        del base_model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    results.sort(key=lambda row: row["ood_accuracy"], reverse=True)
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    with args.output_file.open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "base_model": args.base_model,
                "checkpoint_dir": str(args.checkpoint_dir.resolve()),
                "id_file": str(args.id_file.resolve()),
                "ood_file": str(args.ood_file.resolve()),
                "seed": args.seed_id,
                "sampling": {
                    "mode": args.sample_mode,
                    "max_samples": args.max_samples,
                    "seed": sample_seed,
                    "id_count": len(id_rows),
                    "ood_count": len(ood_rows),
                    "id_source_counts": source_counts(id_rows),
                    "ood_source_counts": source_counts(ood_rows),
                },
                "results": results,
            },
            handle,
            indent=2,
            ensure_ascii=True,
        )
    print(json.dumps({"top_checkpoints": results[:5], "output_file": str(args.output_file.resolve())}, indent=2))


if __name__ == "__main__":
    main()
