#!/usr/bin/env python3
"""Minimal QLoRA SFT trainer for the ArithShift pilot."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import inspect
import json
from pathlib import Path
from typing import Any

import torch
from datasets import Dataset, DatasetDict, load_dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    Trainer,
    TrainingArguments,
    set_seed,
)

from workspace_paths import CONFIGS_DIR


def patch_peft_upcast_dtypes() -> None:
    try:
        from peft.tuners import tuners_utils
    except Exception:  # noqa: BLE001
        return
    upcast_dtypes = getattr(tuners_utils, "UPCAST_DTYPES", None)
    if upcast_dtypes is None:
        return
    filtered = tuple(name for name in upcast_dtypes if hasattr(torch, name))
    if filtered != upcast_dtypes:
        tuners_utils.UPCAST_DTYPES = filtered


patch_peft_upcast_dtypes()


def has_bitsandbytes() -> bool:
    try:
        import bitsandbytes  # noqa: F401
    except ImportError:
        return False
    return True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=CONFIGS_DIR / "arithshift_pilot.json")
    parser.add_argument("--override-output-dir", type=Path, default=None)
    return parser.parse_args()


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_jsonl_dataset(train_file: str, validation_file: str) -> DatasetDict:
    return load_dataset(
        "json",
        data_files={"train": train_file, "validation": validation_file},
    )


def build_text(prompt: str, answer: str, eos_token: str) -> str:
    return f"{prompt}\n{answer}{eos_token}"


def tokenize_dataset(
    dataset: DatasetDict,
    tokenizer: AutoTokenizer,
    max_seq_length: int,
) -> DatasetDict:
    def process_batch(batch: dict[str, list[str]]) -> dict[str, list[list[int]]]:
        texts = [
            build_text(prompt, answer, tokenizer.eos_token)
            for prompt, answer in zip(batch["prompt"], batch["answer"])
        ]
        tokenized = tokenizer(
            texts,
            max_length=max_seq_length,
            truncation=True,
            padding=False,
        )
        tokenized["labels"] = [ids[:] for ids in tokenized["input_ids"]]
        return tokenized

    columns = dataset["train"].column_names
    return dataset.map(
        process_batch,
        batched=True,
        remove_columns=columns,
        desc="Tokenizing",
    )


def build_model_and_tokenizer(config: dict[str, Any]) -> tuple[Any, Any]:
    tokenizer = AutoTokenizer.from_pretrained(config["model_name_or_path"], use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    use_4bit = bool(config.get("load_in_4bit", True) and torch.cuda.is_available() and has_bitsandbytes())
    quant_config = None
    if use_4bit:
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        )

    model = AutoModelForCausalLM.from_pretrained(
        config["model_name_or_path"],
        quantization_config=quant_config,
        torch_dtype=torch.float16 if torch.cuda.is_available() and not use_4bit else (torch.bfloat16 if torch.cuda.is_available() else torch.float32),
        device_map="auto" if torch.cuda.is_available() else None,
    )
    model.config.use_cache = False
    if use_4bit:
        model = prepare_model_for_kbit_training(model)
    elif torch.cuda.is_available():
        model.gradient_checkpointing_enable()

    lora_config = LoraConfig(
        r=config["lora_r"],
        lora_alpha=config["lora_alpha"],
        lora_dropout=config["lora_dropout"],
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=config.get(
            "target_modules",
            ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        ),
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    return model, tokenizer


@dataclass
class CausalLMCollator:
    tokenizer: Any

    def __call__(self, features: list[dict[str, Any]]) -> dict[str, torch.Tensor]:
        labels = [list(feature["labels"]) for feature in features]
        model_inputs = [{k: v for k, v in feature.items() if k != "labels"} for feature in features]
        batch = self.tokenizer.pad(
            model_inputs,
            padding=True,
            return_tensors="pt",
        )
        max_len = int(batch["input_ids"].shape[1])
        padded_labels: list[list[int]] = []
        for row in labels:
            clipped = row[:max_len]
            if len(clipped) < max_len:
                clipped = clipped + [-100] * (max_len - len(clipped))
            padded_labels.append(clipped)
        batch["labels"] = torch.tensor(padded_labels, dtype=torch.long)
        return batch


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    if args.override_output_dir is not None:
        config["output_dir"] = str(args.override_output_dir)

    set_seed(config["seed"])
    dataset = load_jsonl_dataset(config["train_file"], config["validation_file"])
    model, tokenizer = build_model_and_tokenizer(config)
    tokenized = tokenize_dataset(dataset, tokenizer, config["max_seq_length"])

    common_training_kwargs = {
        "output_dir": config["output_dir"],
        "learning_rate": config["learning_rate"],
        "num_train_epochs": config["num_train_epochs"],
        "per_device_train_batch_size": config["per_device_train_batch_size"],
        "gradient_accumulation_steps": config["gradient_accumulation_steps"],
        "per_device_eval_batch_size": config["per_device_eval_batch_size"],
        "logging_steps": config["logging_steps"],
        "save_steps": config["save_steps"],
        "eval_steps": config["eval_steps"],
        "save_strategy": config["save_strategy"],
        "warmup_ratio": config["warmup_ratio"],
        "weight_decay": config["weight_decay"],
        "bf16": torch.cuda.is_available(),
        "fp16": False,
        "report_to": [],
        "save_total_limit": 12,
        "load_best_model_at_end": False,
        "remove_unused_columns": False,
        "label_names": ["labels"],
    }
    try:
        training_args = TrainingArguments(
            evaluation_strategy="steps",
            **common_training_kwargs,
        )
    except TypeError:
        training_args = TrainingArguments(
            eval_strategy="steps",
            **common_training_kwargs,
        )

    collator = CausalLMCollator(tokenizer=tokenizer)
    trainer_kwargs = {
        "model": model,
        "args": training_args,
        "train_dataset": tokenized["train"],
        "eval_dataset": tokenized["validation"],
        "data_collator": collator,
    }
    trainer_signature = inspect.signature(Trainer.__init__)
    if "tokenizer" in trainer_signature.parameters:
        trainer_kwargs["tokenizer"] = tokenizer
    elif "processing_class" in trainer_signature.parameters:
        trainer_kwargs["processing_class"] = tokenizer
    trainer = Trainer(**trainer_kwargs)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is not available in this Python environment. Install a GPU-enabled PyTorch build before training.")
    trainer.train()
    trainer.save_model(config["output_dir"])
    tokenizer.save_pretrained(config["output_dir"])


if __name__ == "__main__":
    main()
