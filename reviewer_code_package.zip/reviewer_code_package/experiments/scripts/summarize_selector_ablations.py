#!/usr/bin/env python3
"""Summarize selector-side ablations from existing per-seed trajectory analyses."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


VARIANT_ORDER = (
    "last",
    "best_id",
    "rrd_only",
    "ps_only",
    "scope_argmax",
    "scope_plateau",
    "best_ood",
)


VARIANT_LABELS = {
    "last": "Last",
    "best_id": "Best-ID",
    "rrd_only": "RRD-only (argmin RRD)",
    "ps_only": "PS-only (argmin PS)",
    "scope_argmax": "Argmax(SCOPE)",
    "scope_plateau": "Plateau-aware SCOPE ($0.5\\sigma$)",
    "best_ood": "Oracle Best-OOD",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    parser.add_argument("--margin-std", type=float, default=0.5)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    if not values:
        return math.nan
    return sum(values) / len(values)


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def sort_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(rows, key=lambda row: int(row.get("step", 10**9)))


def select_last(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda row: int(row.get("step", -1)))


def select_best_id(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda row: (float(row.get("id_accuracy", -1.0)), -int(row.get("step", 10**9))))


def select_best_ood(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return max(rows, key=lambda row: (float(row.get("ood_accuracy", -1.0)), -int(row.get("step", 10**9))))


def select_min_metric(rows: list[dict[str, Any]], metric: str) -> dict[str, Any]:
    return min(rows, key=lambda row: (float(row.get(metric, 1e9)), int(row.get("step", 10**9))))


def select_max_metric(rows: list[dict[str, Any]], metric: str) -> dict[str, Any]:
    return max(rows, key=lambda row: (float(row.get(metric, -1e9)), -int(row.get("step", 10**9))))


def select_scope_plateau(rows: list[dict[str, Any]], margin_std: float) -> dict[str, Any]:
    valid = [row for row in rows if row.get("scope_score") is not None]
    if not valid:
        raise ValueError("No valid SCOPE rows found.")
    scores = [float(row["scope_score"]) for row in valid]
    max_score = max(scores)
    score_mean = mean(scores)
    score_var = sum((score - score_mean) ** 2 for score in scores) / len(scores)
    score_std = math.sqrt(score_var)
    threshold = max_score - margin_std * score_std
    eligible = [row for row in sort_rows(valid) if float(row["scope_score"]) >= threshold]
    if not eligible:
        return max(valid, key=lambda row: float(row["scope_score"]))
    return eligible[0]


def aggregate_variant(picks: list[dict[str, Any]], oracle_oods: list[float]) -> dict[str, Any]:
    regrets = [oracle - float(row["ood_accuracy"]) for row, oracle in zip(picks, oracle_oods)]
    return {
        "n_seeds": len(picks),
        "id_accuracy_mean": mean([float(row["id_accuracy"]) for row in picks]),
        "id_accuracy_std": std([float(row["id_accuracy"]) for row in picks]),
        "ood_accuracy_mean": mean([float(row["ood_accuracy"]) for row in picks]),
        "ood_accuracy_std": std([float(row["ood_accuracy"]) for row in picks]),
        "ood_regret_mean": mean(regrets),
        "ood_regret_std": std(regrets),
    }


def format_mean_std(mu: float, sigma: float) -> str:
    return f"{mu:.4f} $\\pm$ {sigma:.4f}"


def write_latex_table(path: Path, summary: dict[str, Any]) -> None:
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\caption{Selector-side ablation on the final public-transfer benchmark (8 seeds). This is a post-hoc selector-only analysis on the same trajectories, with no additional training runs.}")
    lines.append("\\label{tab:ablation}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Selector Variant & ID Acc & OOD Acc & Regret to Oracle \\\\")
    lines.append("\\midrule")
    for key in VARIANT_ORDER:
        row = summary["variants"][key]
        lines.append(
            f"{VARIANT_LABELS[key]} & "
            f"{format_mean_std(row['id_accuracy_mean'], row['id_accuracy_std'])} & "
            f"{format_mean_std(row['ood_accuracy_mean'], row['ood_accuracy_std'])} & "
            f"{row['ood_regret_mean']:.4f} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    payloads = [read_json(path) for path in args.analysis_files]
    by_variant: dict[str, list[dict[str, Any]]] = {key: [] for key in VARIANT_ORDER}
    oracle_oods: list[float] = []

    for payload in payloads:
        rows = sort_rows(payload.get("rows", []))
        if not rows:
            continue
        oracle = select_best_ood(rows)
        oracle_oods.append(float(oracle["ood_accuracy"]))
        by_variant["last"].append(select_last(rows))
        by_variant["best_id"].append(select_best_id(rows))
        by_variant["rrd_only"].append(select_min_metric(rows, "rrd"))
        by_variant["ps_only"].append(select_min_metric(rows, "ps"))
        by_variant["scope_argmax"].append(select_max_metric(rows, "scope_score"))
        by_variant["scope_plateau"].append(select_scope_plateau(rows, margin_std=args.margin_std))
        by_variant["best_ood"].append(oracle)

    output = {
        "num_seeds": len(oracle_oods),
        "margin_std": args.margin_std,
        "variants": {
            key: aggregate_variant(by_variant[key], oracle_oods)
            for key in VARIANT_ORDER
        },
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(output, ensure_ascii=True, indent=2), encoding="utf-8")
    write_latex_table(args.output_tex, output)
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
