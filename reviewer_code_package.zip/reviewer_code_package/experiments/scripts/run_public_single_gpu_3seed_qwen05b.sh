﻿#!/usr/bin/env bash
set -euo pipefail

cd /root/autodl-tmp/nips
. .venv/bin/activate

export HF_ENDPOINT=https://hf-mirror.com
export HUGGINGFACE_HUB_CACHE=/root/autodl-tmp/hf-cache
mkdir -p "$HUGGINGFACE_HUB_CACHE" outputs

SEEDS=(20260320 20260321 20260322)

for seed in "${SEEDS[@]}"; do
  echo "[$(date '+%F %T')] start seed=${seed}"
  rm -f experiments/runs/intermediate/.run_public_multiseed.lock
  python experiments/scripts/run_public_multiseed.py \
    --config experiments/configs/public_transfer_qwen25_05b.json \
    --seeds "$seed" \
    --train-gpus 0 \
    --eval-gpu 0 \
    --desired-checkpoints 10 \
    --enable-rrd \
    --allow-remote \
    --skip-data-prep \
    --force
  echo "[$(date '+%F %T')] done seed=${seed}"
done

analysis_files=()
control_files=()
for seed in "${SEEDS[@]}"; do
  a="experiments/runs/intermediate/public_transfer_qwen25_05b_seed${seed}/analysis/analysis.json"
  c="experiments/runs/intermediate/public_transfer_qwen25_05b_seed${seed}/control_selectors.json"
  if [ -f "$a" ]; then analysis_files+=("$a"); fi
  if [ -f "$c" ]; then control_files+=("$c"); fi
done

if [ ${#analysis_files[@]} -lt 3 ]; then
  echo "[$(date '+%F %T')] ERROR: expected 3 analysis files, got ${#analysis_files[@]}"
  exit 1
fi
if [ ${#control_files[@]} -lt 3 ]; then
  echo "[$(date '+%F %T')] ERROR: expected 3 control files, got ${#control_files[@]}"
  exit 1
fi

OUTDIR="experiments/runs/intermediate/public_transfer_qwen25_05b_multiseed_3seed"
mkdir -p "$OUTDIR"

python experiments/scripts/aggregate_multiseed.py \
  --analysis-files "${analysis_files[@]}" \
  --output-dir "$OUTDIR" \
  --tag public_transfer_qwen25_05b_3seed

python experiments/scripts/plot_results.py \
  --multiseed-json "$OUTDIR/multiseed_summary.json" \
  --output-dir "$OUTDIR" \
  --tag public_transfer_qwen25_05b_3seed

python experiments/scripts/aggregate_control_selectors.py \
  --control-files "${control_files[@]}" \
  --analysis-files "${analysis_files[@]}" \
  --output-file "$OUTDIR/control_selector_summary.json"

echo "[$(date '+%F %T')] 3-seed cross-backbone run finished"
echo "[$(date '+%F %T')] multiseed json: $OUTDIR/multiseed_summary.json"

