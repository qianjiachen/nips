#!/usr/bin/env python3
"""Convert evaluation and SCOPE outputs into paper-ready tables and trajectory data."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eval-file", type=Path, required=True)
    parser.add_argument("--score-file", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--tag", type=str, default="run")
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def checkpoint_step(name: str) -> int:
    if name.startswith("checkpoint-"):
        try:
            return int(name.split("-", 1)[1])
        except ValueError:
            return 10**9
    if name in {"final", "adapter_model"}:
        return 10**9
    return 10**9


def merge_rows(eval_rows: list[dict[str, Any]], score_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    score_map = {row["checkpoint"]: row for row in score_rows}
    merged: list[dict[str, Any]] = []
    for row in eval_rows:
        checkpoint = row["checkpoint"]
        score = score_map.get(checkpoint, {})
        merged.append(
            {
                "checkpoint": checkpoint,
                "step": checkpoint_step(checkpoint),
                "checkpoint_step": checkpoint_step(checkpoint),
                "seed": row.get("seed"),
                "id_accuracy": row.get("id_accuracy"),
                "ood_accuracy": row.get("ood_accuracy"),
                "ps": score.get("ps"),
                "rrd": score.get("rrd"),
                "scope_score": score.get("scope_score"),
                "ood_source_breakdown": row.get("ood_source_breakdown"),
            }
        )
    merged.sort(key=lambda x: (x["step"], x["checkpoint"]))
    return merged


def argbest(rows: list[dict[str, Any]], key: str) -> dict[str, Any] | None:
    valid = [row for row in rows if row.get(key) is not None]
    if not valid:
        return None
    return max(valid, key=lambda row: row[key])


def select_best_scope(rows: list[dict[str, Any]], margin_std: float = 0.5) -> dict[str, Any] | None:
    valid = [row for row in rows if row.get("scope_score") is not None]
    if not valid:
        return None
    scores = [float(row["scope_score"]) for row in valid]
    max_score = max(scores)
    mean_score = sum(scores) / len(scores)
    variance = sum((score - mean_score) ** 2 for score in scores) / len(scores)
    std_score = variance**0.5
    margin = margin_std * std_score
    eligible = [row for row in valid if float(row["scope_score"]) >= max_score - margin]
    return min(eligible, key=lambda row: (row["step"], -float(row["scope_score"])))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "checkpoint",
        "step",
        "checkpoint_step",
        "seed",
        "id_accuracy",
        "ood_accuracy",
        "ps",
        "rrd",
        "scope_score",
        "ood_source_breakdown",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def maybe_float(value: Any) -> str:
    if value is None:
        return "-"
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


def build_markdown(rows: list[dict[str, Any]], tag: str) -> str:
    best_ood = argbest(rows, "ood_accuracy")
    best_id = argbest(rows, "id_accuracy")
    best_scope = select_best_scope(rows)
    last = rows[-1] if rows else None

    lines: list[str] = []
    lines.append(f"# Result Analysis: {tag}")
    lines.append("")
    lines.append("## Main Findings")
    if best_ood and last:
        lines.append(f"- Oracle OOD checkpoint: `{best_ood['checkpoint']}` with OOD accuracy {maybe_float(best_ood['ood_accuracy'])}.")
        lines.append(f"- Last checkpoint: `{last['checkpoint']}` with OOD accuracy {maybe_float(last['ood_accuracy'])}.")
        lines.append(f"- Best SCOPE checkpoint: `{best_scope['checkpoint']}` with score {maybe_float(best_scope['scope_score'])}." if best_scope else "- Best SCOPE checkpoint: unavailable.")
        lines.append(f"- Best ID checkpoint: `{best_id['checkpoint']}` with ID accuracy {maybe_float(best_id['id_accuracy'])}." if best_id else "- Best ID checkpoint: unavailable.")
        lines.append(f"- Non-monotonic OOD trajectory: `{'yes' if best_ood['checkpoint'] != last['checkpoint'] else 'no'}`.")
    else:
        lines.append("- Not enough checkpoint data to summarize.")

    lines.append("")
    lines.append("## Selector Comparison")
    if best_scope and best_ood:
        scope_regret = (best_ood["ood_accuracy"] or 0.0) - (best_scope["ood_accuracy"] or 0.0)
        lines.append(f"- SCOPE regret to oracle OOD checkpoint: {scope_regret:.4f}.")
    if best_scope and last:
        scope_gain_vs_last = (best_scope["ood_accuracy"] or 0.0) - (last["ood_accuracy"] or 0.0)
        lines.append(f"- SCOPE gain over last checkpoint on OOD: {scope_gain_vs_last:.4f}.")
    if best_scope and best_id:
        scope_gap_vs_best_id = (best_scope["ood_accuracy"] or 0.0) - (best_id["ood_accuracy"] or 0.0)
        lines.append(f"- SCOPE gain over best-ID checkpoint on OOD: {scope_gap_vs_best_id:.4f}.")

    lines.append("")
    lines.append("## Table")
    lines.append("")
    lines.append("| Checkpoint | Step | ID Acc | OOD Acc | PS | RRD | SCOPE |")
    lines.append("|------------|------|--------|---------|----|-----|-------|")
    for row in rows:
        lines.append(
            f"| `{row['checkpoint']}` | {row['step']} | {maybe_float(row['id_accuracy'])} | {maybe_float(row['ood_accuracy'])} | "
            f"{maybe_float(row['ps'])} | {maybe_float(row['rrd'])} | {maybe_float(row['scope_score'])} |"
        )

    lines.append("")
    lines.append("## Figure Data")
    lines.append("- Use `trajectory.csv` for checkpoint-vs-metric line plots.")
    lines.append("- Plot `step` on the x-axis and `id_accuracy`, `ood_accuracy`, and `scope_score` on the y-axis.")
    lines.append("")
    return "\n".join(lines)


def build_analysis_json(rows: list[dict[str, Any]]) -> dict[str, Any]:
    best_ood = argbest(rows, "ood_accuracy")
    best_id = argbest(rows, "id_accuracy")
    best_scope = select_best_scope(rows)
    last = rows[-1] if rows else None
    return {
        "seed": rows[0].get("seed") if rows else None,
        "best_ood_checkpoint": best_ood,
        "best_id_checkpoint": best_id,
        "best_scope_checkpoint": best_scope,
        "scope_selection_rule": {
            "type": "earliest_within_margin",
            "margin_std": 0.5,
        },
        "last_checkpoint": last,
        "non_monotonic_ood": bool(best_ood and last and best_ood["checkpoint"] != last["checkpoint"]),
        "rows": rows,
    }


def main() -> None:
    args = parse_args()
    eval_payload = read_json(args.eval_file)
    score_payload = read_json(args.score_file)
    rows = merge_rows(eval_payload.get("results", []), score_payload.get("results", []))

    args.output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.output_dir / "trajectory.csv"
    md_path = args.output_dir / "analysis.md"
    json_path = args.output_dir / "analysis.json"

    write_csv(csv_path, rows)
    md_text = build_markdown(rows, args.tag)
    with md_path.open("w", encoding="utf-8") as handle:
        handle.write(md_text)
    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(build_analysis_json(rows), handle, ensure_ascii=True, indent=2)

    print(
        json.dumps(
            {
                "trajectory_csv": str(csv_path.resolve()),
                "analysis_md": str(md_path.resolve()),
                "analysis_json": str(json_path.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
