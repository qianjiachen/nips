#!/usr/bin/env python3
"""Generate data quality reports for train/val/test_ood JSONL datasets."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-dir", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    return parser.parse_args()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def summarize_split(rows: list[dict[str, Any]]) -> dict[str, Any]:
    prompt_counter = Counter()
    sample_id_counter = Counter()
    source_counter = Counter()
    shift_counter = Counter()
    empty_prompt = 0
    empty_answer = 0
    for row in rows:
        prompt = str(row.get("prompt", row.get("base_prompt", ""))).strip()
        answer = str(row.get("answer", "")).strip()
        sample_id = str(row.get("sample_id", "")).strip()
        shift = str(row.get("shift_type", "<none>"))
        source = str(row.get("metadata", {}).get("source", "<none>"))
        if not prompt:
            empty_prompt += 1
        if "answer" in row and not answer:
            empty_answer += 1
        if prompt:
            prompt_counter[prompt] += 1
        if sample_id:
            sample_id_counter[sample_id] += 1
        shift_counter[shift] += 1
        source_counter[source] += 1
    duplicate_prompt_rows = sum(count - 1 for count in prompt_counter.values() if count > 1)
    duplicate_sample_id_rows = sum(count - 1 for count in sample_id_counter.values() if count > 1)
    return {
        "rows": len(rows),
        "empty_prompt": empty_prompt,
        "empty_answer": empty_answer,
        "duplicate_prompt_rows": duplicate_prompt_rows,
        "duplicate_sample_id_rows": duplicate_sample_id_rows,
        "shift_distribution": dict(shift_counter),
        "source_distribution": dict(source_counter),
        "unique_prompts": len(prompt_counter),
        "unique_sample_ids": len(sample_id_counter),
        "prompt_set": set(prompt_counter.keys()),
        "sample_id_set": set(sample_id_counter.keys()),
    }


def overlap_count(a: set[str], b: set[str]) -> int:
    return len(a & b)


def build_report(dataset_dir: Path) -> dict[str, Any]:
    files = {
        "train": dataset_dir / "train.jsonl",
        "val": dataset_dir / "val.jsonl",
        "test_ood": dataset_dir / "test_ood.jsonl",
    }
    rows = {split: read_jsonl(path) for split, path in files.items()}
    summary = {split: summarize_split(data) for split, data in rows.items()}

    overlaps = {
        "prompt_overlap_train_val": overlap_count(summary["train"]["prompt_set"], summary["val"]["prompt_set"]),
        "prompt_overlap_train_test_ood": overlap_count(summary["train"]["prompt_set"], summary["test_ood"]["prompt_set"]),
        "prompt_overlap_val_test_ood": overlap_count(summary["val"]["prompt_set"], summary["test_ood"]["prompt_set"]),
        "sample_id_overlap_train_val": overlap_count(summary["train"]["sample_id_set"], summary["val"]["sample_id_set"]),
        "sample_id_overlap_train_test_ood": overlap_count(
            summary["train"]["sample_id_set"], summary["test_ood"]["sample_id_set"]
        ),
        "sample_id_overlap_val_test_ood": overlap_count(summary["val"]["sample_id_set"], summary["test_ood"]["sample_id_set"]),
    }

    for split in summary.values():
        split.pop("prompt_set", None)
        split.pop("sample_id_set", None)

    return {
        "dataset_dir": str(dataset_dir.resolve()),
        "splits": summary,
        "overlap": overlaps,
        "contract_checks": {
            "required_fields": ["sample_id", "split", "shift_type", "prompt", "answer", "metadata.source"],
            "empty_prompt_total": sum(summary[split]["empty_prompt"] for split in summary),
            "empty_answer_total": sum(summary[split]["empty_answer"] for split in summary),
        },
    }


def to_markdown(payload: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("# Data Quality Report")
    lines.append("")
    lines.append(f"- Dataset dir: `{payload['dataset_dir']}`")
    lines.append("")
    lines.append("## Split Summary")
    lines.append("")
    lines.append("| Split | Rows | Empty Prompt | Empty Answer | Dup Prompt Rows | Dup Sample ID Rows |")
    lines.append("|-------|------|--------------|--------------|-----------------|--------------------|")
    for split in ["train", "val", "test_ood"]:
        row = payload["splits"][split]
        lines.append(
            f"| `{split}` | {row['rows']} | {row['empty_prompt']} | {row['empty_answer']} | "
            f"{row['duplicate_prompt_rows']} | {row['duplicate_sample_id_rows']} |"
        )
    lines.append("")
    lines.append("## Overlap Checks")
    lines.append("")
    for key, value in payload["overlap"].items():
        lines.append(f"- {key}: {value}")
    lines.append("")
    lines.append("## OOD Source Distribution")
    lines.append("")
    test_source = payload["splits"]["test_ood"]["source_distribution"]
    if test_source:
        for source, count in sorted(test_source.items()):
            lines.append(f"- {source}: {count}")
    else:
        lines.append("- No source metadata found.")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    report = build_report(args.dataset_dir)
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    args.output_md.write_text(to_markdown(report), encoding="utf-8")
    print(json.dumps({"output_json": str(args.output_json.resolve()), "output_md": str(args.output_md.resolve())}, indent=2))


if __name__ == "__main__":
    main()
