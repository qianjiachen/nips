#!/usr/bin/env python3
"""Compute unsupervised checkpoint diagnostics for paper baselines.

This script is intentionally lightweight and reuses the same checkpoint loading
path as the SCOPE scorer. It reports several label-free metrics that can later
be joined with checkpoint-level OOD results:

- next-token entropy / perplexity proxy
- linear CKA to an early reference checkpoint
- approximate SVCCA to the same reference checkpoint
- adapter weight drift relative to the reference checkpoint
- hidden-spectrum summary (effective rank, top-1 singular value ratio)

The output is a per-checkpoint JSON record that is easy to post-process into a
selector table.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


def patch_peft_upcast_dtypes() -> None:
    try:
        from peft.tuners import tuners_utils
    except Exception:  # noqa: BLE001
        return
    upcast_dtypes = getattr(tuners_utils, "UPCAST_DTYPES", None)
    if upcast_dtypes is None:
        return
    filtered = tuple(name for name in upcast_dtypes if hasattr(torch, name))
    if filtered != upcast_dtypes:
        tuners_utils.UPCAST_DTYPES = filtered


patch_peft_upcast_dtypes()


def has_bitsandbytes() -> bool:
    try:
        import bitsandbytes  # noqa: F401
    except ImportError:
        return False
    return True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--checkpoint-dir", type=Path, required=True)
    parser.add_argument("--tokenizer-path", type=Path, default=None)
    parser.add_argument("--probe-file", type=Path, required=True)
    parser.add_argument("--output-file", type=Path, required=True)
    parser.add_argument("--reference-checkpoint", type=Path, default=None)
    parser.add_argument("--max-samples", type=int, default=0)
    parser.add_argument("--allow-remote", action="store_true")
    return parser.parse_args()


def read_jsonl(path: Path, limit: int | None = None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for idx, line in enumerate(handle):
            if limit is not None and idx >= limit:
                break
            if line.strip():
                rows.append(json.loads(line))
    return rows


def list_checkpoints(path: Path) -> list[Path]:
    checkpoints = sorted(
        [p for p in path.iterdir() if p.is_dir() and p.name.startswith("checkpoint-")],
        key=lambda p: checkpoint_step(p.name),
    )
    return checkpoints or [path]


def checkpoint_step(name: str) -> int:
    if name.startswith("checkpoint-"):
        try:
            return int(name.split("-", 1)[1])
        except ValueError:
            return 10**9
    return 10**9


def build_tokenizer(base_model: str, tokenizer_path: Path | None, local_files_only: bool) -> Any:
    candidates: list[str] = []
    if tokenizer_path is not None:
        candidates.append(str(tokenizer_path))
    candidates.append(base_model)
    last_error: Exception | None = None
    for candidate in candidates:
        try:
            tokenizer = AutoTokenizer.from_pretrained(
                candidate,
                use_fast=False,
                local_files_only=local_files_only,
            )
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            tokenizer.padding_side = "right"
            return tokenizer
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    if last_error is not None:
        raise last_error
    raise RuntimeError("Failed to build tokenizer.")


def build_base_model(base_model: str, local_files_only: bool) -> Any:
    use_4bit = torch.cuda.is_available() and has_bitsandbytes()
    quant_config = None
    if use_4bit:
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        )
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=quant_config,
        torch_dtype=torch.float16 if torch.cuda.is_available() and not use_4bit else (torch.bfloat16 if torch.cuda.is_available() else torch.float32),
        device_map="auto" if torch.cuda.is_available() else None,
        local_files_only=local_files_only,
    )
    model.eval()
    return model


def attach_adapter(base_model: Any, checkpoint_path: Path) -> Any:
    model = PeftModel.from_pretrained(base_model, checkpoint_path)
    model.eval()
    return model


def next_token_distribution(model: Any, tokenizer: Any, prompt: str) -> torch.Tensor:
    encoded = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=384).to(model.device)
    with torch.no_grad():
        outputs = model(**encoded)
        logits = outputs.logits[:, -1, :]
    return torch.softmax(logits.float(), dim=-1).squeeze(0).cpu()


def entropy_from_dist(dist: torch.Tensor) -> float:
    return float(-(dist * torch.log(dist + 1e-8)).sum().item())


def compute_prompt_entropy(model: Any, tokenizer: Any, probe_rows: list[dict[str, Any]]) -> dict[str, float]:
    entropies: list[float] = []
    for row in probe_rows:
        dist = next_token_distribution(model, tokenizer, row["base_prompt"])
        entropies.append(entropy_from_dist(dist))
    if not entropies:
        return {"entropy": math.nan, "perplexity": math.nan}
    mean_entropy = float(sum(entropies) / len(entropies))
    return {"entropy": mean_entropy, "perplexity": float(math.exp(mean_entropy))}


def collect_hidden_matrix(model: Any, tokenizer: Any, probe_rows: list[dict[str, Any]]) -> torch.Tensor:
    vectors: list[torch.Tensor] = []
    for row in probe_rows:
        encoded = tokenizer(
            row["base_prompt"],
            return_tensors="pt",
            truncation=True,
            max_length=384,
        ).to(model.device)
        with torch.no_grad():
            outputs = model(**encoded, output_hidden_states=True)
            hidden = outputs.hidden_states[-1].squeeze(0).float().cpu()
        vectors.append(hidden.mean(dim=0))
    return torch.stack(vectors, dim=0)


def center(x: torch.Tensor) -> torch.Tensor:
    return x - x.mean(dim=0, keepdim=True)


def linear_cka(reference: torch.Tensor, current: torch.Tensor) -> float:
    x = center(reference)
    y = center(current)
    xty = x.T @ y
    xtx = x.T @ x
    yty = y.T @ y
    denom = torch.linalg.norm(xtx, ord="fro") * torch.linalg.norm(yty, ord="fro")
    if denom.item() == 0:
        return math.nan
    return float((torch.linalg.norm(xty, ord="fro") ** 2 / denom).item())


def pca_project(hidden: torch.Tensor, max_components: int) -> torch.Tensor:
    q = max(1, min(max_components, hidden.shape[0] - 1, hidden.shape[1]))
    _, _, basis = torch.pca_lowrank(hidden, q=q, center=False)
    return hidden @ basis[:, :q]


def approx_svcca(reference: torch.Tensor, current: torch.Tensor, max_components: int = 20) -> float:
    x = center(reference)
    y = center(current)
    x_red = pca_project(x, max_components=max_components)
    y_red = pca_project(y, max_components=max_components)
    n = x_red.shape[0]
    x_red = x_red / math.sqrt(max(1, n - 1))
    y_red = y_red / math.sqrt(max(1, n - 1))
    cxx = x_red.T @ x_red
    cyy = y_red.T @ y_red
    cxy = x_red.T @ y_red
    eps = 1e-6
    ex, vx = torch.linalg.eigh(cxx + eps * torch.eye(cxx.shape[0], device=cxx.device))
    ey, vy = torch.linalg.eigh(cyy + eps * torch.eye(cyy.shape[0], device=cyy.device))
    wx = vx @ torch.diag(torch.clamp(ex, min=eps).pow(-0.5)) @ vx.T
    wy = vy @ torch.diag(torch.clamp(ey, min=eps).pow(-0.5)) @ vy.T
    corr = torch.linalg.svdvals(wx @ cxy @ wy)
    if corr.numel() == 0:
        return math.nan
    return float(corr.mean().item())


def spectral_summary(hidden: torch.Tensor) -> dict[str, float]:
    centered = center(hidden)
    singular_vals = torch.linalg.svdvals(centered)
    if singular_vals.numel() == 0:
        return {"effective_rank": math.nan, "top1_ratio": math.nan}
    probs = singular_vals / singular_vals.sum().clamp_min(1e-8)
    spectral_entropy = -(probs * torch.log(probs + 1e-8)).sum()
    effective_rank = float(torch.exp(spectral_entropy).item())
    top1_ratio = float((singular_vals[0] / singular_vals.sum().clamp_min(1e-8)).item())
    return {"effective_rank": effective_rank, "top1_ratio": top1_ratio}


def adapter_vector(model: Any) -> torch.Tensor:
    params: list[torch.Tensor] = []
    for param in model.parameters():
        if param.requires_grad:
            params.append(param.detach().float().flatten().cpu())
    if not params:
        return torch.empty(0)
    return torch.cat(params)


def weight_drift(reference_vector: torch.Tensor, current_model: Any) -> dict[str, float]:
    ref = reference_vector
    cur = adapter_vector(current_model)
    if ref.numel() == 0 or cur.numel() == 0 or ref.shape != cur.shape:
        return {"weight_l2": math.nan, "weight_rel_l2": math.nan, "weight_cosine": math.nan}
    diff = cur - ref
    ref_norm = torch.linalg.norm(ref).clamp_min(1e-8)
    cur_norm = torch.linalg.norm(cur).clamp_min(1e-8)
    cosine = float((torch.dot(ref, cur) / (ref_norm * cur_norm)).item())
    return {
        "weight_l2": float(torch.linalg.norm(diff).item()),
        "weight_rel_l2": float((torch.linalg.norm(diff) / ref_norm).item()),
        "weight_cosine": cosine,
    }


def valid_metric_value(row: dict[str, Any], metric: str) -> float | None:
    value = row.get(metric)
    if value is None:
        return None
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(numeric):
        return None
    return numeric


def metric_rankings(results: list[dict[str, Any]]) -> dict[str, list[str]]:
    minimize_metrics = {"entropy", "perplexity", "weight_l2", "weight_rel_l2", "top1_ratio"}
    metrics = [
        "entropy",
        "perplexity",
        "cka_to_ref",
        "svcca_to_ref",
        "weight_l2",
        "weight_rel_l2",
        "weight_cosine",
        "effective_rank",
        "top1_ratio",
    ]
    rankings: dict[str, list[str]] = {}
    for metric in metrics:
        valid_rows = [row for row in results if valid_metric_value(row, metric) is not None]
        if metric in minimize_metrics:
            ordered = sorted(
                valid_rows,
                key=lambda row: (valid_metric_value(row, metric), checkpoint_step(row["checkpoint"])),
            )
        else:
            ordered = sorted(
                valid_rows,
                key=lambda row: (-valid_metric_value(row, metric), checkpoint_step(row["checkpoint"])),
            )
        rankings[metric] = [row["checkpoint"] for row in ordered]
    return rankings


def peak_gpu_memory_gb() -> float:
    if not torch.cuda.is_available():
        return math.nan
    return float(torch.cuda.max_memory_allocated() / (1024**3))


def main() -> None:
    runtime_start = time.perf_counter()
    args = parse_args()
    probe_limit = None if args.max_samples <= 0 else args.max_samples
    probe_rows = read_jsonl(args.probe_file, limit=probe_limit)
    rewrites_per_probe = len(probe_rows[0].get("rewrites", [])) if probe_rows else 0
    local_files_only = not args.allow_remote
    tokenizer = build_tokenizer(args.base_model, args.tokenizer_path, local_files_only=local_files_only)
    checkpoints = list_checkpoints(args.checkpoint_dir)

    reference_path = args.reference_checkpoint or checkpoints[0]
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    reference_base = build_base_model(args.base_model, local_files_only=local_files_only)
    reference_model = attach_adapter(reference_base, reference_path)
    reference_hidden = collect_hidden_matrix(reference_model, tokenizer, probe_rows)
    reference_vector = adapter_vector(reference_model)
    del reference_model
    del reference_base
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    results: list[dict[str, Any]] = []
    for checkpoint in checkpoints:
        checkpoint_start = time.perf_counter()
        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
        base_model = build_base_model(args.base_model, local_files_only=local_files_only)
        model = attach_adapter(base_model, checkpoint)
        prompt_stats = compute_prompt_entropy(model, tokenizer, probe_rows)
        current_hidden = collect_hidden_matrix(model, tokenizer, probe_rows)
        spec = spectral_summary(current_hidden)
        row = {
            "checkpoint": checkpoint.name,
            "path": str(checkpoint.resolve()),
            **prompt_stats,
            "cka_to_ref": linear_cka(reference_hidden, current_hidden),
            "svcca_to_ref": approx_svcca(reference_hidden, current_hidden),
            **weight_drift(reference_vector, model),
            **spec,
            "runtime_seconds": time.perf_counter() - checkpoint_start,
            "peak_gpu_memory_gb": peak_gpu_memory_gb(),
        }
        results.append(row)
        del model
        del base_model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    payload = {
        "base_model": args.base_model,
        "checkpoint_dir": str(args.checkpoint_dir.resolve()),
        "reference_checkpoint": str(reference_path.resolve()),
        "probe_file": str(args.probe_file.resolve()),
        "probe_count": len(probe_rows),
        "rewrites_per_probe": rewrites_per_probe,
        "num_checkpoints": len(checkpoints),
        "runtime_seconds": time.perf_counter() - runtime_start,
        "peak_gpu_memory_gb": max(
            [float(row["peak_gpu_memory_gb"]) for row in results if not math.isnan(float(row["peak_gpu_memory_gb"]))],
            default=math.nan,
        ),
        "extra_forwards_per_checkpoint": len(probe_rows) * 2,
        "extra_reference_forwards": len(probe_rows),
        "extra_forwards_total": len(probe_rows) * (2 * len(checkpoints) + 1),
        "results": results,
        "rankings": metric_rankings(results),
    }
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    args.output_file.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="utf-8")
    print(json.dumps({"output_file": str(args.output_file.resolve()), "checkpoints": len(results)}, indent=2))


if __name__ == "__main__":
    main()
