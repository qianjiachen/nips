#!/usr/bin/env python3
"""Aggregate multi-seed checkpoint analyses into paper-ready selector tables."""

from __future__ import annotations

import argparse
import csv
import json
import math
from itertools import product
from pathlib import Path
from typing import Any


SELECTORS = ("best_ood", "best_id", "best_scope", "last")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--analysis-files",
        type=Path,
        nargs="+",
        required=True,
        help="Paths to per-seed analysis.json files produced by analyze_results.py",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--tag", type=str, default="multiseed")
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else math.nan


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def percentile(sorted_vals: list[float], q: float) -> float:
    if not sorted_vals:
        return math.nan
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    idx = (len(sorted_vals) - 1) * q
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return sorted_vals[lo]
    frac = idx - lo
    return sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac


def ci95(values: list[float]) -> tuple[float, float]:
    if not values:
        return (math.nan, math.nan)
    if len(values) == 1:
        return (values[0], values[0])
    sorted_vals = sorted(values)
    return (percentile(sorted_vals, 0.025), percentile(sorted_vals, 0.975))


def paired_signflip_pvalue(diffs: list[float]) -> float:
    usable = [x for x in diffs if not math.isnan(x)]
    n = len(usable)
    if n == 0:
        return math.nan
    observed = abs(mean(usable))
    extreme = 0
    total = 0
    for signs in product([-1.0, 1.0], repeat=n):
        perm_mean = abs(mean([d * s for d, s in zip(usable, signs)]))
        total += 1
        if perm_mean >= observed - 1e-12:
            extreme += 1
    return extreme / total


def extract_selector_metrics(payload: dict[str, Any]) -> dict[str, dict[str, float | str | None]]:
    mapping = {
        "best_ood": payload.get("best_ood_checkpoint"),
        "best_id": payload.get("best_id_checkpoint"),
        "best_scope": payload.get("best_scope_checkpoint"),
        "last": payload.get("last_checkpoint"),
    }
    out: dict[str, dict[str, float | str | None]] = {}
    for key, row in mapping.items():
        out[key] = {
            "checkpoint": None if row is None else row.get("checkpoint"),
            "id_accuracy": None if row is None else row.get("id_accuracy"),
            "ood_accuracy": None if row is None else row.get("ood_accuracy"),
            "scope_score": None if row is None else row.get("scope_score"),
        }
    return out


def aggregate(payloads: list[dict[str, Any]]) -> dict[str, Any]:
    selector_per_seed: dict[str, list[dict[str, float | str | None]]] = {name: [] for name in SELECTORS}
    for payload in payloads:
        extracted = extract_selector_metrics(payload)
        for selector in SELECTORS:
            selector_per_seed[selector].append(extracted[selector])

    selector_rows: list[dict[str, Any]] = []
    for selector in SELECTORS:
        id_vals: list[float] = []
        ood_vals: list[float] = []
        scope_vals: list[float] = []
        checkpoints: list[str] = []
        for payload in payloads:
            row = extract_selector_metrics(payload)[selector]
            if row["id_accuracy"] is not None:
                id_vals.append(float(row["id_accuracy"]))
            if row["ood_accuracy"] is not None:
                ood_vals.append(float(row["ood_accuracy"]))
            if row["scope_score"] is not None:
                scope_vals.append(float(row["scope_score"]))
            if row["checkpoint"] is not None:
                checkpoints.append(str(row["checkpoint"]))
        ood_ci_low, ood_ci_high = ci95(ood_vals)
        id_ci_low, id_ci_high = ci95(id_vals)
        selector_rows.append(
            {
                "selector": selector,
                "n_seeds": len(ood_vals),
                "id_accuracy_mean": mean(id_vals),
                "id_accuracy_std": std(id_vals),
                "id_accuracy_ci95_low": id_ci_low,
                "id_accuracy_ci95_high": id_ci_high,
                "ood_accuracy_mean": mean(ood_vals),
                "ood_accuracy_std": std(ood_vals),
                "ood_accuracy_ci95_low": ood_ci_low,
                "ood_accuracy_ci95_high": ood_ci_high,
                "scope_score_mean": mean(scope_vals),
                "scope_score_std": std(scope_vals),
                "example_checkpoints": checkpoints,
            }
        )

    best_ood = next(row for row in selector_rows if row["selector"] == "best_ood")
    for row in selector_rows:
        row["ood_regret_mean"] = best_ood["ood_accuracy_mean"] - row["ood_accuracy_mean"]

    def paired_diffs(lhs: str, rhs: str) -> list[float]:
        diffs: list[float] = []
        lhs_rows = selector_per_seed[lhs]
        rhs_rows = selector_per_seed[rhs]
        for lrow, rrow in zip(lhs_rows, rhs_rows):
            lval = lrow.get("ood_accuracy")
            rval = rrow.get("ood_accuracy")
            if lval is None or rval is None:
                diffs.append(math.nan)
                continue
            diffs.append(float(lval) - float(rval))
        return diffs

    scope_vs_last = paired_diffs("best_scope", "last")
    scope_vs_best_id = paired_diffs("best_scope", "best_id")
    scope_vs_oracle = paired_diffs("best_scope", "best_ood")

    return {
        "num_seeds": len(payloads),
        "selectors": selector_rows,
        "non_monotonic_ood_seeds": sum(1 for payload in payloads if payload.get("non_monotonic_ood")),
        "paired_tests": {
            "scope_minus_last": {
                "mean_diff_ood": mean([x for x in scope_vs_last if not math.isnan(x)]),
                "ci95_low": ci95([x for x in scope_vs_last if not math.isnan(x)])[0],
                "ci95_high": ci95([x for x in scope_vs_last if not math.isnan(x)])[1],
                "p_value_signflip": paired_signflip_pvalue(scope_vs_last),
            },
            "scope_minus_best_id": {
                "mean_diff_ood": mean([x for x in scope_vs_best_id if not math.isnan(x)]),
                "ci95_low": ci95([x for x in scope_vs_best_id if not math.isnan(x)])[0],
                "ci95_high": ci95([x for x in scope_vs_best_id if not math.isnan(x)])[1],
                "p_value_signflip": paired_signflip_pvalue(scope_vs_best_id),
            },
            "scope_minus_oracle": {
                "mean_diff_ood": mean([x for x in scope_vs_oracle if not math.isnan(x)]),
                "ci95_low": ci95([x for x in scope_vs_oracle if not math.isnan(x)])[0],
                "ci95_high": ci95([x for x in scope_vs_oracle if not math.isnan(x)])[1],
                "p_value_signflip": paired_signflip_pvalue(scope_vs_oracle),
            },
        },
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "selector",
        "n_seeds",
        "id_accuracy_mean",
        "id_accuracy_std",
        "id_accuracy_ci95_low",
        "id_accuracy_ci95_high",
        "ood_accuracy_mean",
        "ood_accuracy_std",
        "ood_accuracy_ci95_low",
        "ood_accuracy_ci95_high",
        "scope_score_mean",
        "scope_score_std",
        "ood_regret_mean",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows([{key: row.get(key) for key in fieldnames} for row in rows])


def fmt(value: Any) -> str:
    if value is None:
        return "-"
    if isinstance(value, float):
        if math.isnan(value):
            return "-"
        return f"{value:.4f}"
    return str(value)


def build_markdown(summary: dict[str, Any], tag: str) -> str:
    rows = summary["selectors"]
    best_scope = next(row for row in rows if row["selector"] == "best_scope")
    last = next(row for row in rows if row["selector"] == "last")
    best_id = next(row for row in rows if row["selector"] == "best_id")

    lines: list[str] = []
    lines.append(f"# Multi-seed Summary: {tag}")
    lines.append("")
    lines.append("## Headline")
    lines.append(f"- Seeds aggregated: {summary['num_seeds']}.")
    lines.append(f"- Seeds with non-monotonic OOD trajectories: {summary['non_monotonic_ood_seeds']} / {summary['num_seeds']}.")
    lines.append(
        f"- SCOPE mean OOD accuracy: {fmt(best_scope['ood_accuracy_mean'])} +/- {fmt(best_scope['ood_accuracy_std'])}."
    )
    lines.append(f"- Last-checkpoint mean OOD accuracy: {fmt(last['ood_accuracy_mean'])} +/- {fmt(last['ood_accuracy_std'])}.")
    lines.append(f"- Best-ID mean OOD accuracy: {fmt(best_id['ood_accuracy_mean'])} +/- {fmt(best_id['ood_accuracy_std'])}.")
    lines.append("")
    lines.append("## Main Table")
    lines.append("")
    lines.append("| Selector | ID Acc (mean+/-std, 95% CI) | OOD Acc (mean+/-std, 95% CI) | OOD Regret | SCOPE Score (mean+/-std) |")
    lines.append("|----------|------------------------------|-------------------------------|------------|--------------------------|")
    for row in rows:
        lines.append(
            f"| `{row['selector']}` | {fmt(row['id_accuracy_mean'])} +/- {fmt(row['id_accuracy_std'])}, "
            f"[{fmt(row['id_accuracy_ci95_low'])}, {fmt(row['id_accuracy_ci95_high'])}] | "
            f"{fmt(row['ood_accuracy_mean'])} +/- {fmt(row['ood_accuracy_std'])}, "
            f"[{fmt(row['ood_accuracy_ci95_low'])}, {fmt(row['ood_accuracy_ci95_high'])}] | {fmt(row['ood_regret_mean'])} | "
            f"{fmt(row['scope_score_mean'])} +/- {fmt(row['scope_score_std'])} |"
        )
    lines.append("")
    lines.append("## Paired Tests")
    lines.append("")
    for key, value in summary.get("paired_tests", {}).items():
        lines.append(
            f"- `{key}`: mean_diff={fmt(value.get('mean_diff_ood'))}, "
            f"95%CI=[{fmt(value.get('ci95_low'))}, {fmt(value.get('ci95_high'))}], "
            f"p(sign-flip)={fmt(value.get('p_value_signflip'))}."
        )
    lines.append("")
    lines.append("## Interpretation")
    lines.append("- Use `best_scope` vs `last` as the main practical comparison.")
    lines.append("- Use `best_scope` vs `best_id` to show ID-based selection is insufficient for OOD generalization.")
    lines.append("- Use `best_ood` only as an oracle upper bound, not as a deployable selector.")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    payloads = [read_json(path) for path in args.analysis_files]
    summary = aggregate(payloads)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    csv_path = args.output_dir / "multiseed_table.csv"
    md_path = args.output_dir / "multiseed_summary.md"
    json_path = args.output_dir / "multiseed_summary.json"

    write_csv(csv_path, summary["selectors"])
    with md_path.open("w", encoding="utf-8") as handle:
        handle.write(build_markdown(summary, args.tag))
    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=True, indent=2)

    print(
        json.dumps(
            {
                "multiseed_csv": str(csv_path.resolve()),
                "multiseed_md": str(md_path.resolve()),
                "multiseed_json": str(json_path.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
