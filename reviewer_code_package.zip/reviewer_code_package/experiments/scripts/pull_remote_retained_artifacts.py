#!/usr/bin/env python3
"""Pull corrected aggregate and per-seed retained-checkpoint artifacts from a remote host."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path, PurePosixPath

import paramiko

from workspace_paths import ROOT, SCRIPTS_DIR


AGGREGATE_FILES = [
    "multiseed_summary.json",
    "selector_table.tex",
    "control_selector_summary.json",
    "control_selector_table.tex",
    "diagnostic_selector_summary.json",
    "diagnostic_selector_table.tex",
    "id_budget_selector_summary.json",
    "id_budget_selector_table.tex",
    "scope_cost_summary.json",
    "scope_cost_table.tex",
    "multiseed_selector_plot.png",
]

PER_SEED_FILES = [
    "eval_results.json",
    "control_selectors.json",
    "analysis/analysis.json",
    "analysis/diagnostic_selectors.json",
]

PAPER_MIRROR_SUFFIXES = {".tex", ".png", ".pdf"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--username", required=True)
    parser.add_argument("--password", default=None)
    parser.add_argument("--password-env", default="REMOTE_SSH_PASSWORD")
    parser.add_argument("--remote-workdir", default="/root/project")
    parser.add_argument("--aggregate-dir", default="experiments/runs/final/public_transfer_qwen25_15b_multiseed")
    parser.add_argument("--seed-prefix", default="experiments/runs/final/public_transfer_qwen25_15b_seed")
    parser.add_argument("--seeds", type=int, nargs="+", required=True)
    parser.add_argument("--local-workdir", type=Path, default=ROOT)
    parser.add_argument("--paper-dir", type=Path, default=None)
    parser.add_argument("--tex-file", type=Path, default=None)
    parser.add_argument("--refresh-figures", action="store_true")
    return parser.parse_args()


def resolve_password(args: argparse.Namespace) -> str:
    if args.password:
        return args.password
    value = os.environ.get(args.password_env)
    if value:
        return value
    raise ValueError(f"Missing SSH password. Pass --password or set {args.password_env}.")


def resolve_local_path(workdir: Path, target: Path | None) -> Path | None:
    if target is None:
        return None
    return target.resolve() if target.is_absolute() else (workdir / target).resolve()


def copy_file(
    sftp: paramiko.SFTPClient,
    remote_path: PurePosixPath,
    local_path: Path,
    copied: list[dict[str, str]],
    skipped: list[str],
) -> None:
    try:
        sftp.stat(str(remote_path))
    except FileNotFoundError:
        skipped.append(str(remote_path))
        return
    local_path.parent.mkdir(parents=True, exist_ok=True)
    sftp.get(str(remote_path), str(local_path))
    copied.append({"remote": str(remote_path), "local": str(local_path)})


def maybe_refresh_metrics(workdir: Path, tex_file: Path | None, multiseed_json: Path) -> dict[str, str] | None:
    if tex_file is None or not multiseed_json.exists():
        return None
    subprocess.run(
        [
            sys.executable,
            str(SCRIPTS_DIR / "fill_tex_metrics.py"),
            "--multiseed-json",
            str(multiseed_json),
            "--tex-file",
            str(tex_file),
        ],
        cwd=str(workdir),
        check=True,
    )
    return {"multiseed_json": str(multiseed_json), "tex_file": str(tex_file)}


def maybe_refresh_figures(workdir: Path) -> str | None:
    subprocess.run(
        [sys.executable, str(SCRIPTS_DIR / "build_paper_figures.py")],
        cwd=str(workdir),
        check=True,
    )
    return str((SCRIPTS_DIR / "build_paper_figures.py").resolve())


def main() -> None:
    args = parse_args()
    password = resolve_password(args)
    local_workdir = args.local_workdir.resolve()
    paper_dir = resolve_local_path(local_workdir, args.paper_dir)
    tex_file = resolve_local_path(local_workdir, args.tex_file)

    remote_root = PurePosixPath(args.remote_workdir)
    remote_aggregate_dir = remote_root / args.aggregate_dir
    local_aggregate_dir = (local_workdir / args.aggregate_dir).resolve()

    copied: list[dict[str, str]] = []
    skipped: list[str] = []

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            args.host,
            port=args.port,
            username=args.username,
            password=password,
            timeout=20,
            banner_timeout=20,
            auth_timeout=20,
        )
        with client.open_sftp() as sftp:
            for name in AGGREGATE_FILES:
                remote_path = remote_aggregate_dir / name
                local_path = local_aggregate_dir / name
                copy_file(sftp, remote_path, local_path, copied, skipped)
                if paper_dir is not None and Path(name).suffix.lower() in PAPER_MIRROR_SUFFIXES and local_path.exists():
                    mirrored_path = paper_dir / Path(name).name
                    mirrored_path.parent.mkdir(parents=True, exist_ok=True)
                    sftp.get(str(remote_path), str(mirrored_path))
                    copied.append({"remote": str(remote_path), "local": str(mirrored_path)})

            for seed in args.seeds:
                remote_seed_dir = remote_root / f"{args.seed_prefix}{seed}"
                local_seed_dir = (local_workdir / f"{args.seed_prefix}{seed}").resolve()
                for rel_name in PER_SEED_FILES:
                    remote_path = remote_seed_dir / rel_name
                    local_path = local_seed_dir / Path(rel_name)
                    copy_file(sftp, remote_path, local_path, copied, skipped)
    finally:
        client.close()

    multiseed_json = local_aggregate_dir / "multiseed_summary.json"
    metrics_refresh = maybe_refresh_metrics(local_workdir, tex_file, multiseed_json)
    figures_refresh = maybe_refresh_figures(local_workdir) if args.refresh_figures else None

    print(
        json.dumps(
            {
                "copied": copied,
                "copied_count": len(copied),
                "skipped_missing": skipped,
                "metrics_refresh": metrics_refresh,
                "figures_refresh": figures_refresh,
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
