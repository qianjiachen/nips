#!/usr/bin/env python3
"""Monitor a remote rerun and launch diagnostic-selector postprocessing."""

from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
import textwrap
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import paramiko

from workspace_paths import ROOT, SCRIPTS_DIR


REMOTE_ENV = {
    "HF_ENDPOINT": "https://hf-mirror.com",
    "HF_HUB_ENDPOINT": "https://hf-mirror.com",
    "HF_HUB_DISABLE_XET": "1",
    "HF_HUB_DOWNLOAD_TIMEOUT": "600",
    "HF_HUB_ETAG_TIMEOUT": "60",
    "HUGGINGFACE_HUB_CACHE": "/root/autodl-tmp/hf-cache",
}


@dataclass
class RemotePaths:
    output_dir: str
    eval_file: str
    analysis_file: str
    diagnostic_file: str
    selector_file: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--username", required=True)
    parser.add_argument("--password", default=None)
    parser.add_argument("--password-env", default="REMOTE_SSH_PASSWORD")
    parser.add_argument("--remote-workdir", required=True)
    parser.add_argument("--remote-python", default="/root/miniconda3/bin/python")
    parser.add_argument("--remote-output-dirs", nargs="+", required=True)
    parser.add_argument("--remote-probe-file", required=True)
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--analysis-relpath", default="analysis/analysis.json")
    parser.add_argument("--eval-relpath", default="eval_results.json")
    parser.add_argument("--diagnostic-relpath", default="analysis/diagnostic_metrics.json")
    parser.add_argument("--selector-relpath", default="analysis/diagnostic_selectors.json")
    parser.add_argument("--max-samples", type=int, default=256)
    parser.add_argument("--poll-seconds", type=int, default=60)
    parser.add_argument("--timeout-minutes", type=float, default=0.0)
    parser.add_argument("--skip-wait", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--allow-remote", action="store_true")
    parser.add_argument("--local-output-root", type=Path, required=True)
    parser.add_argument("--aggregate-output", type=Path, default=None)
    parser.add_argument("--latex-output", type=Path, default=None)
    parser.add_argument("--json-status-output", type=Path, default=None)
    return parser.parse_args()


def resolve_password(args: argparse.Namespace) -> str:
    if args.password:
        return args.password
    env_value = os.environ.get(args.password_env)
    if env_value:
        return env_value
    raise ValueError(f"Missing SSH password. Pass --password or set {args.password_env}.")


def q(value: str | Path) -> str:
    return shlex.quote(str(value))


def join_cmd(parts: list[str | Path]) -> str:
    return " ".join(q(part) for part in parts)


def remote_paths(output_dir: str, args: argparse.Namespace) -> RemotePaths:
    return RemotePaths(
        output_dir=output_dir,
        eval_file=f"{output_dir}/{args.eval_relpath}",
        analysis_file=f"{output_dir}/{args.analysis_relpath}",
        diagnostic_file=f"{output_dir}/{args.diagnostic_relpath}",
        selector_file=f"{output_dir}/{args.selector_relpath}",
    )


class SSHRunner:
    def __init__(self, args: argparse.Namespace, password: str) -> None:
        self.args = args
        self.password = password
        self.client: paramiko.SSHClient | None = None

    def __enter__(self) -> "SSHRunner":
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            self.args.host,
            port=self.args.port,
            username=self.args.username,
            password=self.password,
            timeout=20,
            banner_timeout=20,
            auth_timeout=20,
        )
        self.client = client
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        if self.client is not None:
            self.client.close()
            self.client = None

    def exec(self, command: str, timeout: int = 1800) -> tuple[int, str, str]:
        if self.client is None:
            raise RuntimeError("SSH client is not connected.")
        stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)
        exit_code = stdout.channel.recv_exit_status()
        return (
            exit_code,
            stdout.read().decode("utf-8", "ignore"),
            stderr.read().decode("utf-8", "ignore"),
        )

    def get(self, remote_path: str, local_path: Path) -> None:
        if self.client is None:
            raise RuntimeError("SSH client is not connected.")
        local_path.parent.mkdir(parents=True, exist_ok=True)
        with self.client.open_sftp() as sftp:
            sftp.get(remote_path, str(local_path))

    def shell_prefix(self) -> str:
        exports = [f"export {name}={q(value)}" for name, value in REMOTE_ENV.items()]
        exports.append("unset HF_HUB_ENABLE_HF_TRANSFER")
        exports.append(f"cd {q(self.args.remote_workdir)}")
        return " && ".join(exports)

    def python_here_doc(self, script: str, timeout: int = 1800) -> tuple[int, str, str]:
        command = f"{self.shell_prefix()} && {q(self.args.remote_python)} - <<'PY'\n{script}\nPY"
        return self.exec(command, timeout=timeout)


def wait_for_artifacts(
    runner: SSHRunner,
    paths: RemotePaths,
    args: argparse.Namespace,
    on_poll: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    deadline = None if args.skip_wait or args.timeout_minutes <= 0 else time.time() + args.timeout_minutes * 60.0
    status_script = textwrap.dedent(
        f"""
        import json
        from pathlib import Path

        root = Path({paths.output_dir!r})
        checkpoints = sorted(p.name for p in root.glob("checkpoint-*") if p.is_dir())
        payload = {{
            "output_dir": str(root),
            "checkpoint_dirs": checkpoints,
            "checkpoint_count": len(checkpoints),
            "has_eval": (root / {args.eval_relpath!r}).is_file(),
            "has_analysis": (root / {args.analysis_relpath!r}).is_file(),
            "has_diagnostic": (root / {args.diagnostic_relpath!r}).is_file(),
            "has_selector": (root / {args.selector_relpath!r}).is_file(),
        }}
        print(json.dumps(payload))
        """
    ).strip()

    while True:
        code, stdout, stderr = runner.python_here_doc(status_script, timeout=300)
        if code != 0:
            raise RuntimeError(f"Failed to inspect remote output dir {paths.output_dir}:\n{stderr}")
        status = json.loads(stdout.strip())
        if on_poll is not None:
            on_poll(status)
        ready = status["checkpoint_count"] > 0 and status["has_eval"]
        if ready or args.skip_wait:
            return status
        if deadline is not None and time.time() >= deadline:
            status["timed_out"] = True
            return status
        time.sleep(max(1, args.poll_seconds))


def run_remote_python_script(
    runner: SSHRunner,
    script_name: str,
    cli_args: list[str | Path],
    timeout: int = 1800,
) -> dict[str, Any]:
    command = f"{runner.shell_prefix()} && {join_cmd([runner.args.remote_python, script_name, *cli_args])}"
    code, stdout, stderr = runner.exec(command, timeout=timeout)
    if code != 0:
        raise RuntimeError(f"Remote command failed ({script_name}).\nSTDOUT:\n{stdout}\nSTDERR:\n{stderr}")
    text = stdout.strip()
    if text:
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"stdout": text}
    return {"stdout": "", "stderr": stderr.strip()}


def run_local_python(repo_root: Path, script_name: str, cli_args: list[str | Path]) -> dict[str, Any]:
    command = [sys.executable, script_name, *[str(arg) for arg in cli_args]]
    completed = subprocess.run(
        command,
        cwd=str(repo_root),
        check=True,
        capture_output=True,
        text=True,
    )
    text = completed.stdout.strip()
    if not text:
        return {"stdout": "", "stderr": completed.stderr.strip()}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"stdout": text, "stderr": completed.stderr.strip()}


def sync_remote_artifact(runner: SSHRunner, remote_path: str, local_path: Path) -> None:
    runner.get(remote_path, local_path)


def local_run_dir(local_output_root: Path, remote_output_dir: str) -> Path:
    return local_output_root / Path(remote_output_dir).name


def write_status(path: Path | None, payload: dict[str, Any]) -> None:
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8")


def main() -> None:
    args = parse_args()
    repo_root = ROOT
    password = resolve_password(args)
    local_output_root = args.local_output_root.resolve()
    local_output_root.mkdir(parents=True, exist_ok=True)

    selector_files: list[Path] = []
    run_summaries: list[dict[str, Any]] = []
    aggregate_result: dict[str, Any] | None = None
    latex_result: dict[str, Any] | None = None

    def flush_status() -> None:
        write_status(
            None if args.json_status_output is None else args.json_status_output.resolve(),
            {
                "remote_runs": run_summaries,
                "aggregate_result": aggregate_result,
                "latex_result": latex_result,
            },
        )

    with SSHRunner(args, password) as runner:
        for remote_output_dir in args.remote_output_dirs:
            paths = remote_paths(remote_output_dir, args)
            run_summary: dict[str, Any] = {
                "remote_output_dir": remote_output_dir,
                "stage": "waiting_for_artifacts",
                "status": {},
            }
            run_summaries.append(run_summary)
            flush_status()

            def on_poll(status: dict[str, Any]) -> None:
                run_summary["status"] = status
                flush_status()

            status = wait_for_artifacts(runner, paths, args, on_poll=on_poll)
            run_summary["status"] = status
            flush_status()
            if status.get("timed_out"):
                run_summary["stage"] = "timed_out"
                flush_status()
                continue
            if status["checkpoint_count"] == 0 or not status["has_eval"]:
                run_summary["skipped"] = True
                run_summary["stage"] = "skipped"
                flush_status()
                continue

            if args.force or not status["has_diagnostic"]:
                run_summary["stage"] = "running_remote_diagnostics"
                flush_status()
                run_summary["diagnostic"] = run_remote_python_script(
                    runner,
                    str(SCRIPTS_DIR / "score_checkpoint_diagnostics.py"),
                    [
                        "--base-model",
                        args.base_model,
                        "--checkpoint-dir",
                        remote_output_dir,
                        "--probe-file",
                        args.remote_probe_file,
                        "--output-file",
                        paths.diagnostic_file,
                        "--max-samples",
                        str(args.max_samples),
                        *([] if not args.allow_remote else ["--allow-remote"]),
                    ],
                    timeout=7200,
                )
            else:
                run_summary["diagnostic"] = {"skipped": True, "reason": "already_exists"}

            if args.force or not status["has_selector"]:
                run_summary["stage"] = "deriving_selector_summary"
                flush_status()
                selector_args: list[str | Path] = [
                    "--eval-file",
                    paths.eval_file,
                    "--diagnostic-file",
                    paths.diagnostic_file,
                    "--output-file",
                    paths.selector_file,
                ]
                if status["has_analysis"]:
                    selector_args.extend(["--analysis-file", paths.analysis_file])
                run_summary["selector"] = run_remote_python_script(
                    runner,
                    str(SCRIPTS_DIR / "derive_diagnostic_selectors.py"),
                    selector_args,
                    timeout=1800,
                )
            else:
                run_summary["selector"] = {"skipped": True, "reason": "already_exists"}

            run_summary["stage"] = "syncing_artifacts"
            flush_status()
            local_dir = local_run_dir(local_output_root, remote_output_dir)
            local_diag = local_dir / args.diagnostic_relpath
            local_selector = local_dir / args.selector_relpath
            sync_remote_artifact(runner, paths.diagnostic_file, local_diag)
            sync_remote_artifact(runner, paths.selector_file, local_selector)
            selector_files.append(local_selector)
            run_summary["local_diagnostic_file"] = str(local_diag)
            run_summary["local_selector_file"] = str(local_selector)
            run_summary["stage"] = "completed_remote_seed"
            flush_status()

    if selector_files and args.aggregate_output is not None:
        flush_status()
        aggregate_result = run_local_python(
            repo_root,
            str(SCRIPTS_DIR / "aggregate_diagnostic_selectors.py"),
            [
                "--selector-files",
                *selector_files,
                "--output-file",
                args.aggregate_output.resolve(),
            ],
        )
        if args.latex_output is not None:
            latex_result = run_local_python(
                repo_root,
                str(SCRIPTS_DIR / "export_latex_diagnostic_table.py"),
                [
                    "--diagnostic-json",
                    args.aggregate_output.resolve(),
                    "--output-tex",
                    args.latex_output.resolve(),
                ],
            )

    payload = {
        "remote_runs": run_summaries,
        "aggregate_result": aggregate_result,
        "latex_result": latex_result,
    }
    flush_status()
    text = json.dumps(payload, ensure_ascii=True, indent=2)
    print(text)


if __name__ == "__main__":
    main()
