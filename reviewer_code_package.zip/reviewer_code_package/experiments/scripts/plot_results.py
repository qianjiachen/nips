#!/usr/bin/env python3
"""Plot checkpoint trajectories and multi-seed selector summaries."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-json", type=Path, default=None)
    parser.add_argument("--multiseed-json", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--tag", type=str, default="run")
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def plot_trajectory(payload: dict[str, Any], output_dir: Path, tag: str) -> Path:
    rows = payload.get("rows", [])
    steps = [row.get("step", idx) for idx, row in enumerate(rows)]
    id_acc = [row.get("id_accuracy") for row in rows]
    ood_acc = [row.get("ood_accuracy") for row in rows]
    scope = [row.get("scope_score") for row in rows]

    fig, ax1 = plt.subplots(figsize=(8, 4.8))
    ax1.plot(steps, id_acc, marker="o", linewidth=2, color="#1b6ca8", label="ID accuracy")
    ax1.plot(steps, ood_acc, marker="s", linewidth=2, color="#d1495b", label="OOD accuracy")
    ax1.set_xlabel("Checkpoint step")
    ax1.set_ylabel("Accuracy")
    ax1.grid(alpha=0.25)

    ax2 = ax1.twinx()
    ax2.plot(steps, scope, marker="^", linewidth=1.8, color="#2a9d8f", linestyle="--", label="SCOPE score")
    ax2.set_ylabel("SCOPE score")

    handles1, labels1 = ax1.get_legend_handles_labels()
    handles2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(handles1 + handles2, labels1 + labels2, loc="best")
    ax1.set_title(f"Checkpoint Trajectory: {tag}")
    fig.tight_layout()

    output_path = output_dir / "trajectory_plot.png"
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_multiseed(payload: dict[str, Any], output_dir: Path, tag: str) -> Path:
    rows = payload.get("selectors", [])
    selectors = [row["selector"] for row in rows]
    means = [row.get("ood_accuracy_mean", 0.0) for row in rows]
    stds = [row.get("ood_accuracy_std", 0.0) for row in rows]

    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    bars = ax.bar(selectors, means, yerr=stds, capsize=5, color=["#7cb518", "#577590", "#d1495b", "#8d99ae"])
    ax.set_ylabel("OOD accuracy")
    ax.set_title(f"Selector Comparison: {tag}")
    ax.grid(axis="y", alpha=0.25)
    ax.set_axisbelow(True)

    for bar, mean in zip(bars, means):
        ax.text(bar.get_x() + bar.get_width() / 2, mean, f"{mean:.3f}", ha="center", va="bottom", fontsize=9)

    fig.tight_layout()
    output_path = output_dir / "multiseed_selector_plot.png"
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return output_path


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    outputs: dict[str, str] = {}
    if args.analysis_json is not None:
        analysis_payload = read_json(args.analysis_json)
        outputs["trajectory_plot"] = str(plot_trajectory(analysis_payload, args.output_dir, args.tag).resolve())
    if args.multiseed_json is not None:
        multiseed_payload = read_json(args.multiseed_json)
        outputs["multiseed_plot"] = str(plot_multiseed(multiseed_payload, args.output_dir, args.tag).resolve())

    if not outputs:
        raise ValueError("Provide at least one of --analysis-json or --multiseed-json")

    print(json.dumps(outputs, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
