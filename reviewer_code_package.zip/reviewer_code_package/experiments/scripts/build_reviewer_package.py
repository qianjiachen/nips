#!/usr/bin/env python3
"""Build an anonymized reviewer-facing supplementary code package."""

from __future__ import annotations

import argparse
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUTPUT_DIR = ROOT / "submission" / "reviewer_code_package"
TEXT_EXTENSIONS = {
    ".json",
    ".md",
    ".py",
    ".sh",
    ".txt",
    ".csv",
    ".tex",
    ".yaml",
    ".yml",
}
IGNORE_NAMES = {"__pycache__", ".DS_Store"}
IGNORE_SUFFIXES = {".pyc"}

FILES_TO_COPY = [
    Path("experiments/README_ANON_SUBMISSION.md"),
    Path("experiments/requirements-wsl.txt"),
    Path("experiments/run_pilot.sh"),
    Path("experiments/run_public_transfer.sh"),
    Path("experiments/setup_wsl.sh"),
    Path("docs/SETUP_WSL.md"),
    Path("docs/MULTISEED_LAYOUT.md"),
]

DIRS_TO_COPY = [
    Path("experiments/configs"),
    Path("experiments/data/arithshift"),
    Path("experiments/data/public_reasoning"),
    Path("experiments/scripts"),
    Path("experiments/runs/final"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory that will contain the assembled package.",
    )
    parser.add_argument(
        "--zip-path",
        type=Path,
        default=None,
        help="Optional zip path. Defaults to <output-dir>.zip",
    )
    return parser.parse_args()


def should_ignore(path: Path) -> bool:
    return path.name in IGNORE_NAMES or path.suffix in IGNORE_SUFFIXES


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def copy_tree(src: Path, dst: Path) -> None:
    for item in src.rglob("*"):
        if should_ignore(item):
            continue
        rel = item.relative_to(src)
        target = dst / rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)


def make_replacements() -> list[tuple[str, str]]:
    root_win = str(ROOT)
    root_posix = root_win.replace("\\", "/")
    experiments_win = str(ROOT / "experiments")
    experiments_posix = experiments_win.replace("\\", "/")
    docs_win = str(ROOT / "docs")
    docs_posix = docs_win.replace("\\", "/")
    paper_win = str(ROOT / "paper")
    paper_posix = paper_win.replace("\\", "/")
    return [
        (root_win + "\\data\\", "experiments\\data\\"),
        (root_posix + "/data/", "experiments/data/"),
        (root_win + "\\outputs\\", "reviewer_outputs\\"),
        (root_posix + "/outputs/", "reviewer_outputs/"),
        (experiments_win + "\\", "experiments\\"),
        (experiments_posix + "/", "experiments/"),
        (docs_win + "\\", "docs\\"),
        (docs_posix + "/", "docs/"),
        (paper_win + "\\", "paper\\"),
        (paper_posix + "/", "paper/"),
        ("experiments/data/", "experiments/data/"),
        ("reviewer_outputs/", "reviewer_outputs/"),
        ("experiments/", "experiments/"),
        ("docs/", "docs/"),
        ("paper/", "paper/"),
        ("", ""),
        (root_win + "\\", ""),
        (root_posix + "/", ""),
    ]


def sanitize_text_file(path: Path, replacements: list[tuple[str, str]]) -> None:
    try:
        original = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return
    updated = original
    for before, after in replacements:
        updated = updated.replace(before, after)
    if updated != original:
        path.write_text(updated, encoding="utf-8")


def sanitize_package(output_dir: Path) -> None:
    replacements = make_replacements()
    for path in output_dir.rglob("*"):
        if path.is_dir() or path.suffix.lower() not in TEXT_EXTENSIONS:
            continue
        sanitize_text_file(path, replacements)


def write_package_readme(output_dir: Path) -> None:
    readme = output_dir / "README.md"
    readme.write_text(
        "\n".join(
            [
                "# Reviewer Code Package",
                "",
                "This anonymized supplementary package is organized for reviewer-side",
                "inspection and reruns.",
                "",
                "## Included contents",
                "",
                "- `experiments/scripts/`: training, evaluation, scoring, aggregation, and plotting scripts",
                "- `experiments/configs/`: pilot, main, and fast diagnostic configs",
                "- `experiments/data/arithshift/`: synthetic pilot data and probe pool",
                "- `experiments/data/public_reasoning/`: prepared public-transfer benchmark files",
                "- `experiments/runs/final/`: final summaries and analysis artifacts used by the paper",
                "- `docs/`: setup notes and multiseed layout notes",
                "",
                "## Quick start",
                "",
                "1. Read `experiments/README_ANON_SUBMISSION.md`.",
                "2. Create the environment with `bash experiments/setup_wsl.sh` or use the dependency",
                "   list in `experiments/requirements-wsl.txt`.",
                "3. Run `bash experiments/run_pilot.sh` for the synthetic pilot or",
                "   `bash experiments/run_public_transfer.sh` /",
                "   `bash experiments/scripts/run_public_single_gpu_8seed_qwen15b.sh`",
                "   for public-transfer runs.",
                "",
                "## Notes",
                "",
                "- Internal caches, draft notes, debug logs, and archive snapshots are intentionally",
                "  excluded from this package.",
                "- Any absolute machine-specific paths found in saved JSON/Markdown outputs are rewritten",
                "  to anonymized relative placeholders for reviewer readability.",
                "",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def write_manifest(output_dir: Path) -> None:
    entries = []
    for path in sorted(p for p in output_dir.rglob("*") if p.is_file()):
        rel = path.relative_to(output_dir).as_posix()
        size = path.stat().st_size
        entries.append(f"{rel}\t{size}")
    (output_dir / "MANIFEST.tsv").write_text("\n".join(entries) + "\n", encoding="utf-8")


def build_zip(output_dir: Path, zip_path: Path) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for path in sorted(output_dir.rglob("*")):
            if path.is_dir():
                continue
            arcname = path.relative_to(output_dir.parent)
            handle.write(path, arcname.as_posix())


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    zip_path = args.zip_path.resolve() if args.zip_path else output_dir.with_suffix(".zip")

    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    for rel_path in FILES_TO_COPY:
        src = ROOT / rel_path
        copy_file(src, output_dir / rel_path)

    for rel_path in DIRS_TO_COPY:
        src = ROOT / rel_path
        copy_tree(src, output_dir / rel_path)

    write_package_readme(output_dir)
    sanitize_package(output_dir)
    write_manifest(output_dir)
    build_zip(output_dir, zip_path)

    print(f"[reviewer-package] output_dir={output_dir}")
    print(f"[reviewer-package] zip_path={zip_path}")


if __name__ == "__main__":
    main()
