#!/usr/bin/env python3
"""Summarize pilot checkpoint evaluation and SCOPE scoring results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from workspace_paths import INTERMEDIATE_RUNS_DIR
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eval-file", type=Path, required=True)
    parser.add_argument("--score-file", type=Path, required=True)
    parser.add_argument(
        "--output-file",
        type=Path,
        default=INTERMEDIATE_RUNS_DIR / "arithshift_pilot" / "pilot_summary.md",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def merge_results(eval_rows: list[dict[str, Any]], score_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    score_map = {row["checkpoint"]: row for row in score_rows}
    merged: list[dict[str, Any]] = []
    for row in eval_rows:
        checkpoint = row["checkpoint"]
        score_row = score_map.get(checkpoint, {})
        merged.append(
            {
                "checkpoint": checkpoint,
                "id_accuracy": row.get("id_accuracy"),
                "ood_accuracy": row.get("ood_accuracy"),
                "ps": score_row.get("ps"),
                "rrd": score_row.get("rrd"),
                "scope_score": score_row.get("scope_score"),
            }
        )
    return merged


def best_by(rows: list[dict[str, Any]], key: str) -> dict[str, Any] | None:
    valid = [row for row in rows if row.get(key) is not None]
    if not valid:
        return None
    return max(valid, key=lambda row: row[key])


def checkpoint_step(name: str) -> int:
    if name.startswith("checkpoint-"):
        try:
            return int(name.split("-", 1)[1])
        except ValueError:
            return 10**9
    return 10**9


def select_best_scope(rows: list[dict[str, Any]], margin_std: float = 0.5) -> dict[str, Any] | None:
    valid = [row for row in rows if row.get("scope_score") is not None]
    if not valid:
        return None
    scores = [float(row["scope_score"]) for row in valid]
    max_score = max(scores)
    mean_score = sum(scores) / len(scores)
    variance = sum((score - mean_score) ** 2 for score in scores) / len(scores)
    std_score = variance**0.5
    margin = margin_std * std_score
    eligible = [row for row in valid if float(row["scope_score"]) >= max_score - margin]
    return min(eligible, key=lambda row: (checkpoint_step(str(row["checkpoint"])), -float(row["scope_score"])))


def format_float(value: float | None) -> str:
    if value is None:
        return "-"
    return f"{value:.4f}"


def build_summary(rows: list[dict[str, Any]]) -> str:
    oracle_ood = best_by(rows, "ood_accuracy")
    best_id = best_by(rows, "id_accuracy")
    best_scope = select_best_scope(rows)
    last_checkpoint = rows[-1] if rows else None

    lines: list[str] = []
    lines.append("# Pilot Summary")
    lines.append("")
    lines.append("## Headline")
    if oracle_ood and last_checkpoint:
        non_monotonic = oracle_ood["checkpoint"] != last_checkpoint["checkpoint"]
        lines.append(f"- Oracle OOD checkpoint: `{oracle_ood['checkpoint']}` with OOD accuracy {format_float(oracle_ood['ood_accuracy'])}.")
        lines.append(f"- Last checkpoint: `{last_checkpoint['checkpoint']}` with OOD accuracy {format_float(last_checkpoint['ood_accuracy'])}.")
        lines.append(f"- Non-monotonic OOD behavior observed: `{'yes' if non_monotonic else 'no'}`.")
    else:
        lines.append("- Not enough data to judge trajectory behavior.")

    if best_scope:
        lines.append(
            f"- Best SCOPE checkpoint: `{best_scope['checkpoint']}` with score {format_float(best_scope['scope_score'])} and OOD accuracy {format_float(best_scope['ood_accuracy'])}."
        )
    if best_id:
        lines.append(
            f"- Best ID checkpoint: `{best_id['checkpoint']}` with ID accuracy {format_float(best_id['id_accuracy'])} and OOD accuracy {format_float(best_id['ood_accuracy'])}."
        )

    lines.append("")
    lines.append("## Table")
    lines.append("")
    lines.append("| Checkpoint | ID Acc | OOD Acc | PS | RRD | SCOPE |")
    lines.append("|------------|--------|---------|----|-----|-------|")
    for row in rows:
        lines.append(
            f"| `{row['checkpoint']}` | {format_float(row['id_accuracy'])} | {format_float(row['ood_accuracy'])} | "
            f"{format_float(row['ps'])} | {format_float(row['rrd'])} | {format_float(row['scope_score'])} |"
        )

    lines.append("")
    lines.append("## Decision Gate")
    if oracle_ood and last_checkpoint and best_scope:
        non_monotonic = oracle_ood["checkpoint"] != last_checkpoint["checkpoint"]
        scope_matches_oracle = best_scope["checkpoint"] == oracle_ood["checkpoint"]
        if non_monotonic and scope_matches_oracle:
            lines.append("- Proceed: the synthetic pilot shows the target phenomenon and SCOPE recovered the oracle checkpoint.")
        elif non_monotonic:
            lines.append("- Partial proceed: the target phenomenon exists, but SCOPE did not exactly match the oracle checkpoint yet. Inspect PS and consider enabling RRD.")
        else:
            lines.append("- Hold: OOD did not peak before the last checkpoint. Strengthen the synthetic shift before scaling up.")
    else:
        lines.append("- Hold: missing metrics prevent a reliable decision.")

    lines.append("")
    lines.append("## Next Actions")
    lines.append("- If the decision is proceed, run the public transfer track next.")
    lines.append("- If the decision is partial proceed, compare `PS` only vs `SCOPE` and inspect probe rewrites.")
    lines.append("- If the decision is hold, make OOD templates harder before spending more GPU time.")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    eval_payload = read_json(args.eval_file)
    score_payload = read_json(args.score_file)
    rows = merge_results(eval_payload.get("results", []), score_payload.get("results", []))
    summary = build_summary(rows)
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    with args.output_file.open("w", encoding="utf-8") as handle:
        handle.write(summary)
    print(summary)


if __name__ == "__main__":
    main()
