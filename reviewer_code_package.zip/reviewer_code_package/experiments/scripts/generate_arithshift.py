#!/usr/bin/env python3
"""Generate a lightweight arithmetic-shift benchmark for OOD-forgetting studies."""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass
from pathlib import Path

from workspace_paths import DATA_DIR


SEED = 20260320

ID_TEMPLATES = [
    "Lina has {a} apples and buys {b} more. How many apples does she have now?",
    "A box contains {a} pencils. Sam adds {b} pencils. How many pencils are in the box now?",
    "There are {a} birds on a tree. {b} more birds arrive. How many birds are there now?",
    "Mia saved {a} stickers and found {b} more. How many stickers does she have in total?",
]

OOD_TEMPLATES = [
    "Start with {a}. Then increase it by {b}. What number do you get?",
    "A machine outputs {a} tokens and later emits {b} extra tokens. What is the final count?",
    "Suppose the initial value is {a}; after an increment of {b}, what is the resulting value?",
    "Compute the new total if a collection of size {a} grows by {b}.",
]

SUB_TEMPLATES = [
    "{a} children are in a room and {b} leave. How many remain?",
    "A jar holds {a} marbles. If {b} marbles are taken out, how many are left?",
    "There are {a} pages in a notebook. After tearing out {b} pages, how many pages remain?",
]

OOD_SUB_TEMPLATES = [
    "Begin with quantity {a}. Decrease it by {b}. What remains?",
    "A system stores {a} items, then removes {b}. What is the updated count?",
]

CHAIN_TEMPLATES = [
    "Nina has {a} oranges, buys {b}, and then gets {c} more. How many oranges does she have?",
    "A score starts at {a}, goes up by {b}, and then rises by {c}. What is the final score?",
]

OOD_CHAIN_TEMPLATES = [
    "Take the value {a}, add {b}, then add {c}. What is the result?",
    "An inventory begins at {a}. It increases by {b} and later by {c}. Report the ending inventory.",
]

WRAPPERS = [
    "Solve the word problem carefully.\n{question}\nAnswer with a single integer.",
    "Read the problem and compute the result.\n{question}\nFinal answer only.",
]

OOD_WRAPPERS = [
    "You are checking arithmetic consistency.\n{question}\nRespond in the format: Answer: <integer>.",
    "Determine the result exactly.\n{question}\nReturn only the numeric result.",
]


@dataclass
class Example:
    split: str
    sample_id: str
    shift_type: str
    prompt: str
    answer: str
    metadata: dict[str, object]

    def to_json(self) -> str:
        return json.dumps(
            {
                "split": self.split,
                "sample_id": self.sample_id,
                "shift_type": self.shift_type,
                "prompt": self.prompt,
                "answer": self.answer,
                "metadata": self.metadata,
            },
            ensure_ascii=True,
        )


def wrap_question(question: str, wrappers: list[str], rng: random.Random) -> str:
    return rng.choice(wrappers).format(question=question)


def build_addition(split: str, idx: int, rng: random.Random, ood: bool) -> Example:
    a = rng.randint(2, 40 if not ood else 90)
    b = rng.randint(2, 20 if not ood else 45)
    template = rng.choice(OOD_TEMPLATES if ood else ID_TEMPLATES)
    wrappers = OOD_WRAPPERS if ood else WRAPPERS
    question = template.format(a=a, b=b)
    answer = a + b
    return Example(
        split=split,
        sample_id=f"{split}-add-{idx:05d}",
        shift_type="template_shift" if ood else "in_distribution",
        prompt=wrap_question(question, wrappers, rng),
        answer=str(answer),
        metadata={"op": "add", "a": a, "b": b, "template_ood": ood},
    )


def build_subtraction(split: str, idx: int, rng: random.Random, ood: bool) -> Example:
    a = rng.randint(10, 60 if not ood else 120)
    b = rng.randint(1, a - 1)
    template = rng.choice(OOD_SUB_TEMPLATES if ood else SUB_TEMPLATES)
    wrappers = OOD_WRAPPERS if ood else WRAPPERS
    question = template.format(a=a, b=b)
    answer = a - b
    return Example(
        split=split,
        sample_id=f"{split}-sub-{idx:05d}",
        shift_type="operator_shift" if ood else "in_distribution",
        prompt=wrap_question(question, wrappers, rng),
        answer=str(answer),
        metadata={"op": "sub", "a": a, "b": b, "template_ood": ood},
    )


def build_chain(split: str, idx: int, rng: random.Random, ood: bool) -> Example:
    a = rng.randint(2, 20 if not ood else 40)
    b = rng.randint(2, 10 if not ood else 20)
    c = rng.randint(2, 10 if not ood else 20)
    template = rng.choice(OOD_CHAIN_TEMPLATES if ood else CHAIN_TEMPLATES)
    wrappers = OOD_WRAPPERS if ood else WRAPPERS
    question = template.format(a=a, b=b, c=c)
    answer = a + b + c
    return Example(
        split=split,
        sample_id=f"{split}-chain-{idx:05d}",
        shift_type="composition_shift" if ood else "in_distribution",
        prompt=wrap_question(question, wrappers, rng),
        answer=str(answer),
        metadata={"op": "chain_add", "a": a, "b": b, "c": c, "template_ood": ood},
    )


def generate_split(split: str, size: int, rng: random.Random, ood: bool) -> list[Example]:
    return generate_split_unique(split, size, rng, ood=ood, blocked_prompts=set())


def generate_split_unique(
    split: str,
    size: int,
    rng: random.Random,
    *,
    ood: bool,
    blocked_prompts: set[str],
) -> list[Example]:
    builders = [build_addition, build_subtraction, build_chain]
    examples: list[Example] = []
    attempts = 0
    idx = 0
    local_prompts: set[str] = set()
    max_attempts = max(1000, size * 20)
    while len(examples) < size and attempts < max_attempts:
        builder = builders[idx % len(builders)]
        example = builder(split, idx, rng, ood)
        prompt = example.prompt.strip()
        attempts += 1
        idx += 1
        if prompt in blocked_prompts or prompt in local_prompts:
            continue
        local_prompts.add(prompt)
        examples.append(example)
    if len(examples) < size:
        raise RuntimeError(
            f"Could not generate enough unique prompts for split={split}. "
            f"Requested={size}, generated={len(examples)}."
        )
    rng.shuffle(examples)
    return examples


def write_jsonl(path: Path, examples: list[Example]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for example in examples:
            handle.write(example.to_json())
            handle.write("\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DATA_DIR / "arithshift")
    parser.add_argument("--train-size", type=int, default=2400)
    parser.add_argument("--val-size", type=int, default=300)
    parser.add_argument("--ood-size", type=int, default=600)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--allow-overlap", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    if args.allow_overlap:
        train = generate_split("train", args.train_size, rng, ood=False)
        val = generate_split("val", args.val_size, rng, ood=False)
        test_ood = generate_split("test_ood", args.ood_size, rng, ood=True)
    else:
        seen: set[str] = set()
        train = generate_split_unique("train", args.train_size, rng, ood=False, blocked_prompts=seen)
        seen.update(example.prompt.strip() for example in train)
        val = generate_split_unique("val", args.val_size, rng, ood=False, blocked_prompts=seen)
        seen.update(example.prompt.strip() for example in val)
        test_ood = generate_split_unique("test_ood", args.ood_size, rng, ood=True, blocked_prompts=seen)
    write_jsonl(args.output_dir / "train.jsonl", train)
    write_jsonl(args.output_dir / "val.jsonl", val)
    write_jsonl(args.output_dir / "test_ood.jsonl", test_ood)
    summary = {
        "train_size": len(train),
        "val_size": len(val),
        "ood_size": len(test_ood),
        "seed": args.seed,
        "path": str(args.output_dir.resolve()),
    }
    print(json.dumps(summary, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
