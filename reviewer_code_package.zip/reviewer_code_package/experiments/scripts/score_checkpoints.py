#!/usr/bin/env python3
"""Checkpoint scoring for SCOPE using perturbation stability and optional RRD."""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

from workspace_paths import INTERMEDIATE_RUNS_DIR
from typing import Any

import torch
import torch.nn.functional as F
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


def patch_peft_upcast_dtypes() -> None:
    try:
        from peft.tuners import tuners_utils
    except Exception:  # noqa: BLE001
        return
    upcast_dtypes = getattr(tuners_utils, "UPCAST_DTYPES", None)
    if upcast_dtypes is None:
        return
    filtered = tuple(name for name in upcast_dtypes if hasattr(torch, name))
    if filtered != upcast_dtypes:
        tuners_utils.UPCAST_DTYPES = filtered


patch_peft_upcast_dtypes()


def has_bitsandbytes() -> bool:
    try:
        import bitsandbytes  # noqa: F401
    except ImportError:
        return False
    return True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--checkpoint-dir", type=Path, required=True)
    parser.add_argument("--tokenizer-path", type=Path, default=None)
    parser.add_argument("--probe-file", type=Path, required=True)
    parser.add_argument("--output-file", type=Path, default=INTERMEDIATE_RUNS_DIR / "checkpoint_scores.json")
    parser.add_argument("--reference-checkpoint", type=Path, default=None)
    parser.add_argument("--max-samples", type=int, default=0)
    parser.add_argument("--enable-rrd", action="store_true")
    parser.add_argument("--seed-id", type=int, default=None)
    parser.add_argument("--allow-remote", action="store_true")
    return parser.parse_args()


def read_jsonl(path: Path, limit: int | None = None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for idx, line in enumerate(handle):
            if limit is not None and idx >= limit:
                break
            rows.append(json.loads(line))
    return rows


def list_checkpoints(path: Path) -> list[Path]:
    checkpoints = sorted(
        [p for p in path.iterdir() if p.is_dir() and p.name.startswith("checkpoint-")],
        key=lambda p: checkpoint_step(p.name),
    )
    if not checkpoints:
        checkpoints = [path]
    return checkpoints


def checkpoint_step(name: str) -> int:
    if name.startswith("checkpoint-"):
        try:
            return int(name.split("-", 1)[1])
        except ValueError:
            return 10**9
    return 10**9


def build_tokenizer(base_model: str, tokenizer_path: Path | None, local_files_only: bool) -> Any:
    candidates: list[str] = []
    if tokenizer_path is not None:
        candidates.append(str(tokenizer_path))
    candidates.append(base_model)
    last_error: Exception | None = None
    for candidate in candidates:
        try:
            tokenizer = AutoTokenizer.from_pretrained(
                candidate,
                use_fast=False,
                local_files_only=local_files_only,
            )
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            tokenizer.padding_side = "right"
            return tokenizer
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    if last_error is not None:
        raise last_error
    raise RuntimeError("Failed to build tokenizer.")


def build_base_model(base_model: str, local_files_only: bool) -> Any:
    use_4bit = torch.cuda.is_available() and has_bitsandbytes()
    quant_config = None
    if use_4bit:
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        )
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=quant_config,
        torch_dtype=torch.float16 if torch.cuda.is_available() and not use_4bit else (torch.bfloat16 if torch.cuda.is_available() else torch.float32),
        device_map="auto" if torch.cuda.is_available() else None,
        local_files_only=local_files_only,
    )
    model.eval()
    return model


def attach_adapter(base_model: Any, checkpoint_path: Path) -> Any:
    model = PeftModel.from_pretrained(base_model, checkpoint_path)
    model.eval()
    return model


def next_token_distribution(model: Any, tokenizer: Any, prompt: str) -> torch.Tensor:
    encoded = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=384).to(model.device)
    with torch.no_grad():
        outputs = model(**encoded)
        logits = outputs.logits[:, -1, :]
    return torch.softmax(logits.float(), dim=-1).squeeze(0).cpu()


def js_divergence(p: torch.Tensor, q: torch.Tensor) -> float:
    m = 0.5 * (p + q)
    p_term = F.kl_div(torch.log(p + 1e-8), m, reduction="sum")
    q_term = F.kl_div(torch.log(q + 1e-8), m, reduction="sum")
    return float(0.5 * (p_term + q_term))


def compute_ps(model: Any, tokenizer: Any, probe_rows: list[dict[str, Any]]) -> float:
    scores: list[float] = []
    for row in probe_rows:
        base_dist = next_token_distribution(model, tokenizer, row["base_prompt"])
        for rewrite in row["rewrites"]:
            rewrite_dist = next_token_distribution(model, tokenizer, rewrite["prompt"])
            scores.append(js_divergence(base_dist, rewrite_dist))
    if not scores:
        return math.nan
    return float(sum(scores) / len(scores))


def collect_hidden_matrix(model: Any, tokenizer: Any, probe_rows: list[dict[str, Any]]) -> torch.Tensor:
    vectors: list[torch.Tensor] = []
    for row in probe_rows:
        encoded = tokenizer(
            row["base_prompt"],
            return_tensors="pt",
            truncation=True,
            max_length=384,
        ).to(model.device)
        with torch.no_grad():
            outputs = model(**encoded, output_hidden_states=True)
            hidden = outputs.hidden_states[-1].squeeze(0).float().cpu()
        pooled = hidden.mean(dim=0)
        vectors.append(pooled)
    return torch.stack(vectors, dim=0)


def principal_angle_drift(reference: torch.Tensor, current: torch.Tensor, rank: int = 8) -> float:
    ref = reference - reference.mean(dim=0, keepdim=True)
    cur = current - current.mean(dim=0, keepdim=True)
    ref_q = torch.pca_lowrank(ref, q=min(rank, ref.shape[0] - 1, ref.shape[1]))[0]
    cur_q = torch.pca_lowrank(cur, q=min(rank, cur.shape[0] - 1, cur.shape[1]))[0]
    singular_values = torch.linalg.svdvals(ref_q.T @ cur_q)
    singular_values = torch.clamp(singular_values, -1.0, 1.0)
    angles = torch.arccos(singular_values)
    return float(angles.mean().item())


def zscore_map(metric_map: dict[str, float], reverse: bool = False) -> dict[str, float]:
    values = torch.tensor(list(metric_map.values()), dtype=torch.float32)
    mean = values.mean()
    std = values.std(unbiased=False)
    if std.item() == 0:
        normalized = {key: 0.0 for key in metric_map}
    else:
        normalized = {key: float((value - mean) / std) for key, value in metric_map.items()}
    if reverse:
        normalized = {key: -value for key, value in normalized.items()}
    return normalized


def peak_gpu_memory_gb() -> float:
    if not torch.cuda.is_available():
        return math.nan
    return float(torch.cuda.max_memory_allocated() / (1024**3))


def main() -> None:
    runtime_start = time.perf_counter()
    args = parse_args()
    probe_limit = None if args.max_samples <= 0 else args.max_samples
    probe_rows = read_jsonl(args.probe_file, limit=probe_limit)
    rewrites_per_probe = len(probe_rows[0].get("rewrites", [])) if probe_rows else 0
    local_files_only = not args.allow_remote
    tokenizer = build_tokenizer(args.base_model, args.tokenizer_path, local_files_only=local_files_only)
    checkpoints = list_checkpoints(args.checkpoint_dir)

    reference_path = args.reference_checkpoint or checkpoints[0]
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    reference_base = build_base_model(args.base_model, local_files_only=local_files_only)
    reference_model = attach_adapter(reference_base, reference_path)
    reference_hidden = None
    if args.enable_rrd:
        reference_hidden = collect_hidden_matrix(reference_model, tokenizer, probe_rows)
    del reference_model
    del reference_base
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    ps_scores: dict[str, float] = {}
    rrd_scores: dict[str, float] = {}
    runtime_by_checkpoint: dict[str, float] = {}
    peak_memory_by_checkpoint: dict[str, float] = {}

    for checkpoint in checkpoints:
        checkpoint_start = time.perf_counter()
        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
        base_model = build_base_model(args.base_model, local_files_only=local_files_only)
        model = attach_adapter(base_model, checkpoint)
        ps_scores[checkpoint.name] = compute_ps(model, tokenizer, probe_rows)
        if args.enable_rrd and reference_hidden is not None:
            current_hidden = collect_hidden_matrix(model, tokenizer, probe_rows)
            rrd_scores[checkpoint.name] = principal_angle_drift(reference_hidden, current_hidden)
        runtime_by_checkpoint[checkpoint.name] = time.perf_counter() - checkpoint_start
        peak_memory_by_checkpoint[checkpoint.name] = peak_gpu_memory_gb()
        del model
        del base_model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    ps_z = zscore_map(ps_scores, reverse=True)
    rrd_z = zscore_map(rrd_scores, reverse=True) if rrd_scores else {}
    results: list[dict[str, Any]] = []
    for checkpoint in checkpoints:
        name = checkpoint.name
        score = ps_z.get(name, 0.0) + rrd_z.get(name, 0.0)
        results.append(
            {
                "checkpoint": name,
                "path": str(checkpoint.resolve()),
                "ps": ps_scores.get(name),
                "rrd": rrd_scores.get(name),
                "scope_score": score,
                "runtime_seconds": runtime_by_checkpoint.get(name),
                "peak_gpu_memory_gb": peak_memory_by_checkpoint.get(name),
            }
        )
    results.sort(key=lambda row: row["scope_score"], reverse=True)
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    extra_forwards_per_checkpoint = len(probe_rows) * (1 + rewrites_per_probe + (1 if args.enable_rrd else 0))
    with args.output_file.open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "base_model": args.base_model,
                "checkpoint_dir": str(args.checkpoint_dir.resolve()),
                "reference_checkpoint": str(reference_path.resolve()),
                "probe_file": str(args.probe_file.resolve()),
                "enable_rrd": args.enable_rrd,
                "seed": args.seed_id,
                "probe_count": len(probe_rows),
                "rewrites_per_probe": rewrites_per_probe,
                "num_checkpoints": len(checkpoints),
                "runtime_seconds": time.perf_counter() - runtime_start,
                "peak_gpu_memory_gb": max(
                    [value for value in peak_memory_by_checkpoint.values() if not math.isnan(value)],
                    default=math.nan,
                ),
                "extra_forwards_per_checkpoint": extra_forwards_per_checkpoint,
                "extra_forwards_total": extra_forwards_per_checkpoint * len(checkpoints),
                "results": results,
            },
            handle,
            indent=2,
            ensure_ascii=True,
        )
    print(json.dumps({"ranked_checkpoints": results[:5], "output_file": str(args.output_file.resolve())}, indent=2))


if __name__ == "__main__":
    main()
