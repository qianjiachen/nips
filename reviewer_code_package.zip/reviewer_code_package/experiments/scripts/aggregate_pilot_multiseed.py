#!/usr/bin/env python3
"""Aggregate ArithShift pilot analyses across multiple seeds."""

from __future__ import annotations

import argparse
import json
import math
import re
from itertools import product
from pathlib import Path
from typing import Any


ORDER = ["last", "best_id", "best_scope", "best_ood"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-file", type=Path, required=True)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else math.nan


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def percentile(sorted_vals: list[float], q: float) -> float:
    if not sorted_vals:
        return math.nan
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    idx = (len(sorted_vals) - 1) * q
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return sorted_vals[lo]
    frac = idx - lo
    return sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac


def ci95(values: list[float]) -> tuple[float, float]:
    if not values:
        return (math.nan, math.nan)
    if len(values) == 1:
        return (values[0], values[0])
    sorted_vals = sorted(values)
    return (percentile(sorted_vals, 0.025), percentile(sorted_vals, 0.975))


def paired_signflip_pvalue(diffs: list[float]) -> float:
    usable = [x for x in diffs if not math.isnan(x)]
    n = len(usable)
    if n == 0:
        return math.nan
    observed = abs(mean(usable))
    total = 0
    extreme = 0
    for signs in product([-1.0, 1.0], repeat=n):
        perm_mean = abs(mean([d * s for d, s in zip(usable, signs)]))
        total += 1
        if perm_mean >= observed - 1e-12:
            extreme += 1
    return extreme / total


def infer_seed(payload: dict[str, Any], path: Path) -> int:
    if payload.get("seed") is not None:
        return int(payload["seed"])
    text = str(path)
    match = re.search(r"seed(\d+)", text)
    if match:
        return int(match.group(1))
    raise ValueError(f"Could not infer seed for {path}")


def pack_row(row: dict[str, Any] | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {
        "checkpoint": row.get("checkpoint"),
        "checkpoint_step": row.get("checkpoint_step"),
        "id_accuracy": row.get("id_accuracy"),
        "ood_accuracy": row.get("ood_accuracy"),
        "scope_score": row.get("scope_score"),
    }


def build_seed_rows(analysis_files: list[Path]) -> dict[int, dict[str, Any]]:
    seed_rows: dict[int, dict[str, Any]] = {}
    for path in analysis_files:
        payload = read_json(path)
        seed = infer_seed(payload, path)
        seed_rows[seed] = {
            "seed": seed,
            "best_ood": pack_row(payload.get("best_ood_checkpoint")),
            "best_id": pack_row(payload.get("best_id_checkpoint")),
            "best_scope": pack_row(payload.get("best_scope_checkpoint")),
            "last": pack_row(payload.get("last_checkpoint")),
            "non_monotonic_ood": bool(payload.get("non_monotonic_ood")),
        }
    return seed_rows


def build_selector_rows(seed_rows: dict[int, dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for selector in ORDER:
        id_vals: list[float] = []
        ood_vals: list[float] = []
        regret_vals: list[float] = []
        step_vals: list[float] = []
        examples: list[str] = []
        for seed in sorted(seed_rows):
            row = seed_rows[seed].get(selector)
            if row is None:
                continue
            if row.get("id_accuracy") is not None:
                id_vals.append(float(row["id_accuracy"]))
            if row.get("ood_accuracy") is not None:
                ood_val = float(row["ood_accuracy"])
                ood_vals.append(ood_val)
                oracle = seed_rows[seed].get("best_ood", {}).get("ood_accuracy")
                if oracle is not None:
                    regret_vals.append(float(oracle) - ood_val)
            if row.get("checkpoint_step") is not None:
                step_vals.append(float(row["checkpoint_step"]))
            if row.get("checkpoint") is not None:
                examples.append(str(row["checkpoint"]))
        id_ci_low, id_ci_high = ci95(id_vals)
        ood_ci_low, ood_ci_high = ci95(ood_vals)
        regret_ci_low, regret_ci_high = ci95(regret_vals)
        step_ci_low, step_ci_high = ci95(step_vals)
        out.append(
            {
                "selector": selector,
                "n_seeds": len(ood_vals),
                "id_accuracy_mean": mean(id_vals),
                "id_accuracy_std": std(id_vals),
                "id_accuracy_ci95_low": id_ci_low,
                "id_accuracy_ci95_high": id_ci_high,
                "ood_accuracy_mean": mean(ood_vals),
                "ood_accuracy_std": std(ood_vals),
                "ood_accuracy_ci95_low": ood_ci_low,
                "ood_accuracy_ci95_high": ood_ci_high,
                "ood_regret_mean": mean(regret_vals),
                "ood_regret_std": std(regret_vals),
                "ood_regret_ci95_low": regret_ci_low,
                "ood_regret_ci95_high": regret_ci_high,
                "checkpoint_step_mean": mean(step_vals),
                "checkpoint_step_std": std(step_vals),
                "checkpoint_step_ci95_low": step_ci_low,
                "checkpoint_step_ci95_high": step_ci_high,
                "example_checkpoints": examples,
            }
        )
    return out


def paired_stats(seed_rows: dict[int, dict[str, Any]], lhs: str, rhs: str) -> dict[str, Any]:
    diffs_ood: list[float] = []
    diffs_id: list[float] = []
    for seed in sorted(seed_rows):
        lrow = seed_rows[seed].get(lhs)
        rrow = seed_rows[seed].get(rhs)
        if lrow is None or rrow is None:
            continue
        if lrow.get("ood_accuracy") is not None and rrow.get("ood_accuracy") is not None:
            diffs_ood.append(float(lrow["ood_accuracy"]) - float(rrow["ood_accuracy"]))
        if lrow.get("id_accuracy") is not None and rrow.get("id_accuracy") is not None:
            diffs_id.append(float(lrow["id_accuracy"]) - float(rrow["id_accuracy"]))
    ood_ci_low, ood_ci_high = ci95(diffs_ood)
    id_ci_low, id_ci_high = ci95(diffs_id)
    return {
        "n_pairs": len(diffs_ood),
        "mean_diff_ood": mean(diffs_ood),
        "ci95_low_ood": ood_ci_low,
        "ci95_high_ood": ood_ci_high,
        "p_value_signflip_ood": paired_signflip_pvalue(diffs_ood),
        "mean_diff_id": mean(diffs_id),
        "ci95_low_id": id_ci_low,
        "ci95_high_id": id_ci_high,
    }


def aggregate(seed_rows: dict[int, dict[str, Any]]) -> dict[str, Any]:
    scope_matches = 0
    scope_earlier_than_last = 0
    for seed in sorted(seed_rows):
        best_scope = seed_rows[seed].get("best_scope")
        best_ood = seed_rows[seed].get("best_ood")
        last = seed_rows[seed].get("last")
        if best_scope is not None and best_ood is not None and best_scope.get("checkpoint") == best_ood.get("checkpoint"):
            scope_matches += 1
        if best_scope is not None and last is not None:
            scope_step = best_scope.get("checkpoint_step")
            last_step = last.get("checkpoint_step")
            if scope_step is not None and last_step is not None and float(scope_step) < float(last_step):
                scope_earlier_than_last += 1

    return {
        "num_seeds": len(seed_rows),
        "seeds": sorted(seed_rows),
        "non_monotonic_ood_seeds": sum(1 for row in seed_rows.values() if row.get("non_monotonic_ood")),
        "scope_matches_oracle_seeds": scope_matches,
        "scope_earlier_than_last_seeds": scope_earlier_than_last,
        "selectors": build_selector_rows(seed_rows),
        "paired_tests": {
            "scope_minus_last": paired_stats(seed_rows, "best_scope", "last"),
            "scope_minus_best_id": paired_stats(seed_rows, "best_scope", "best_id"),
        },
    }


def main() -> None:
    args = parse_args()
    seed_rows = build_seed_rows(args.analysis_files)
    summary = aggregate(seed_rows)
    args.output_file.parent.mkdir(parents=True, exist_ok=True)
    args.output_file.write_text(json.dumps(summary, ensure_ascii=True, indent=2), encoding="utf-8")
    print(json.dumps({"output_file": str(args.output_file.resolve())}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
