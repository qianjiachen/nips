#!/usr/bin/env python3
"""Sync the local SCOPE project to a fresh remote machine and bootstrap its Python environment."""

from __future__ import annotations

import argparse
import json
import os
import posixpath
import sys
import tarfile
import tempfile
from pathlib import Path

import paramiko


INCLUDE_PATHS = [
    "paper",
    "experiments",
    "docs",
    "WORKSPACE_MAP.md",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--username", required=True)
    parser.add_argument("--password", default=None)
    parser.add_argument("--password-env", default="REMOTE_SSH_PASSWORD")
    parser.add_argument("--remote-workdir", default="/root/project")
    parser.add_argument("--python-bin", default="/usr/bin/python3")
    parser.add_argument("--setup-env", action="store_true")
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--workdir", type=Path, default=Path("."))
    return parser.parse_args()


def resolve_password(args: argparse.Namespace) -> str:
    if args.password:
        return args.password
    value = os.environ.get(args.password_env)
    if value:
        return value
    raise ValueError(f"Missing SSH password. Pass --password or set {args.password_env}.")


def build_archive(repo_root: Path) -> Path:
    handle = tempfile.NamedTemporaryFile(prefix="nips_sync_", suffix=".tar.gz", delete=False)
    archive_path = Path(handle.name)
    handle.close()
    with tarfile.open(archive_path, "w:gz") as tar:
        for rel_path in INCLUDE_PATHS:
            src = repo_root / rel_path
            if not src.exists():
                continue
            tar.add(src, arcname=rel_path)
    return archive_path


def exec_remote(client: paramiko.SSHClient, command: str, timeout: int = 1800) -> tuple[int, str, str]:
    stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
    exit_code = stdout.channel.recv_exit_status()
    out = stdout.read().decode("utf-8", "ignore")
    err = stderr.read().decode("utf-8", "ignore")
    return exit_code, out, err


def main() -> None:
    args = parse_args()
    repo_root = args.workdir.resolve()
    archive_path = build_archive(repo_root)
    password = resolve_password(args)
    remote_archive = posixpath.join("/tmp", archive_path.name)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            args.host,
            port=args.port,
            username=args.username,
            password=password,
            timeout=20,
            banner_timeout=20,
            auth_timeout=20,
        )
        with client.open_sftp() as sftp:
            sftp.put(str(archive_path), remote_archive)

        setup_cmds = [
            f"mkdir -p {args.remote_workdir}",
            f"tar -xzf {remote_archive} -C {args.remote_workdir}",
            f"rm -f {remote_archive}",
            f"cd {args.remote_workdir}",
            "chmod +x experiments/*.sh || true",
            "chmod +x experiments/scripts/*.sh || true",
        ]
        if args.setup_env:
            setup_cmds.append(
                f"PYTHON_BIN={args.python_bin} ENV_DIR=.venv bash experiments/scripts/setup_python_env.sh"
            )
        if args.verify:
            setup_cmds.append(
                ". .venv/bin/activate && python - <<'PY'\n"
                "import json\n"
                "import torch\n"
                "print(json.dumps({\n"
                "  'torch_version': torch.__version__,\n"
                "  'cuda_available': bool(torch.cuda.is_available()),\n"
                "  'gpu_count': torch.cuda.device_count(),\n"
                "  'device_name': None if not torch.cuda.is_available() else torch.cuda.get_device_name(0),\n"
                "}, ensure_ascii=True))\n"
                "PY"
            )
        code, out, err = exec_remote(client, " && ".join(setup_cmds), timeout=7200)
        if code != 0:
            raise RuntimeError(f"Remote bootstrap failed.\nSTDOUT:\n{out}\nSTDERR:\n{err}")

        print(
            json.dumps(
                {
                    "remote_workdir": args.remote_workdir,
                    "archive": str(archive_path),
                    "stdout": out,
                    "stderr": err,
                },
                ensure_ascii=True,
                indent=2,
            )
        )
    finally:
        archive_path.unlink(missing_ok=True)
        client.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"error": str(exc)}, ensure_ascii=True, indent=2))
        raise
