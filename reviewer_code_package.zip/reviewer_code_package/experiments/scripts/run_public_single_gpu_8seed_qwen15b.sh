﻿#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
WORKDIR="${WORKDIR:-$ROOT_DIR}"
PYTHON_BIN="${PYTHON_BIN:-${WORKDIR}/.venv/bin/python}"

cd "${WORKDIR}"

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HUB_ENDPOINT="${HF_HUB_ENDPOINT:-https://hf-mirror.com}"
export HF_HUB_DISABLE_XET="${HF_HUB_DISABLE_XET:-1}"
export HF_HUB_DOWNLOAD_TIMEOUT="${HF_HUB_DOWNLOAD_TIMEOUT:-600}"
export HF_HUB_ETAG_TIMEOUT="${HF_HUB_ETAG_TIMEOUT:-60}"
unset HF_HUB_ENABLE_HF_TRANSFER
export HUGGINGFACE_HUB_CACHE="${HUGGINGFACE_HUB_CACHE:-${WORKDIR}/.cache/hf}"
mkdir -p "${HUGGINGFACE_HUB_CACHE}" outputs

SEEDS=(
  20260320
  20260321
  20260322
  20260323
  20260324
  20260325
  20260326
  20260327
)

"${PYTHON_BIN}" experiments/scripts/run_public_multiseed.py \
  --config experiments/configs/public_transfer_qwen25_15b.json \
  --seeds "${SEEDS[@]}" \
  --train-gpus 0 \
  --eval-gpu 0 \
  --desired-checkpoints 10 \
  --enable-rrd \
  --allow-remote \
  --run-diagnostics \
  --diagnostic-max-samples 256 \
  --reuse-existing-scores \
  --reuse-existing-diagnostics \
  --force

