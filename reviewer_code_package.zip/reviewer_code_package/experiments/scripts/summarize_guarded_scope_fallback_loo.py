#!/usr/bin/env python3
"""Summarize an exploratory guarded-SCOPE fallback with leave-one-seed-out guard selection."""

from __future__ import annotations

import argparse
import json
import math
from itertools import product
from pathlib import Path
from typing import Any


DEFAULT_AUX_FAMILY = [
    "top1_ratio_min",
    "entropy_min",
    "effective_rank_max",
]


AUX_LABELS = {
    "top1_ratio_min": "Min Top-1 Ratio",
    "entropy_min": "Min Entropy",
    "effective_rank_max": "Max EffRank",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selector-files", type=Path, nargs="+", required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-tex", type=Path, required=True)
    parser.add_argument("--aux-family", type=str, nargs="+", default=DEFAULT_AUX_FAMILY)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def mean(values: list[float]) -> float:
    if not values:
        return math.nan
    return sum(values) / len(values)


def std(values: list[float]) -> float:
    if len(values) <= 1:
        return math.nan
    mu = mean(values)
    return math.sqrt(sum((x - mu) ** 2 for x in values) / (len(values) - 1))


def paired_signflip_pvalue(diffs: list[float]) -> float:
    usable = [value for value in diffs if not math.isnan(value)]
    if not usable:
        return math.nan
    observed = abs(mean(usable))
    total = 0
    extreme = 0
    for signs in product([-1.0, 1.0], repeat=len(usable)):
        perm_mean = abs(mean([diff * sign for diff, sign in zip(usable, signs)]))
        total += 1
        if perm_mean >= observed - 1e-12:
            extreme += 1
    return extreme / total


def get_selector(payload: dict[str, Any], name: str) -> dict[str, Any]:
    for selector in payload.get("selectors", []):
        if selector.get("selector") == name:
            return selector
    raise KeyError(f"Missing selector {name}")


def aggregate_rows(rows: list[dict[str, Any]], oracle_rows: list[dict[str, Any]]) -> dict[str, Any]:
    regrets = [
        float(oracle["ood_accuracy"]) - float(row["ood_accuracy"])
        for row, oracle in zip(rows, oracle_rows)
    ]
    return {
        "n_seeds": len(rows),
        "id_accuracy_mean": mean([float(row["id_accuracy"]) for row in rows]),
        "id_accuracy_std": std([float(row["id_accuracy"]) for row in rows]),
        "ood_accuracy_mean": mean([float(row["ood_accuracy"]) for row in rows]),
        "ood_accuracy_std": std([float(row["ood_accuracy"]) for row in rows]),
        "ood_regret_mean": mean(regrets),
        "ood_regret_std": std(regrets),
        "checkpoints": [str(row["checkpoint"]) for row in rows],
    }


def guarded_pick(
    last_row: dict[str, Any],
    scope_row: dict[str, Any],
    aux_row: dict[str, Any],
) -> dict[str, Any]:
    return scope_row if aux_row["checkpoint"] != last_row["checkpoint"] else last_row


def aux_label(name: str) -> str:
    return AUX_LABELS.get(name, name)


def select_aux_for_holdout(
    payloads: list[dict[str, Any]],
    aux_family: list[str],
    holdout_index: int,
) -> tuple[str, dict[str, Any]]:
    candidate_scores: list[tuple[float, float, int, str]] = []
    for family_index, aux_name in enumerate(aux_family):
        ood_values: list[float] = []
        regrets: list[float] = []
        for index, payload in enumerate(payloads):
            if index == holdout_index:
                continue
            last_row = get_selector(payload, "last")
            scope_row = get_selector(payload, "best_scope")
            aux_row = get_selector(payload, aux_name)
            oracle_row = get_selector(payload, "best_ood_oracle")
            guarded_row = guarded_pick(last_row, scope_row, aux_row)
            ood_values.append(float(guarded_row["ood_accuracy"]))
            regrets.append(float(oracle_row["ood_accuracy"]) - float(guarded_row["ood_accuracy"]))
        candidate_scores.append((-mean(ood_values), mean(regrets), family_index, aux_name))
    candidate_scores.sort()
    best_aux = candidate_scores[0][3]
    return best_aux, {
        "training_mean_ood": -candidate_scores[0][0],
        "training_mean_regret": candidate_scores[0][1],
    }


def format_mean_std(mu: float, sigma: float) -> str:
    return f"{mu:.4f} $\\pm$ {sigma:.4f}"


def write_latex_table(path: Path, summary: dict[str, Any]) -> None:
    rows = summary["selectors"]
    chosen_counts = summary["aux_choice_counts"]
    chosen_text = ", ".join(
        f"\\texttt{{{aux_label(name)}}}: {count}/{summary['num_seeds']}"
        for name, count in chosen_counts.items()
    )
    lines: list[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(
        "\\caption{Exploratory guarded-SCOPE fallback with leave-one-seed-out "
        "auxiliary-guard selection on the final public-transfer benchmark (8 seeds). "
        "For each held-out seed, we choose the auxiliary selector from a predeclared unlabeled "
        "family \\{\\texttt{Min Top-1 Ratio}, \\texttt{Min Entropy}, \\texttt{Max EffRank}\\} "
        "using mean guarded-rule OOD on the other seven seeds, then evaluate on the hold-out. "
        f"Chosen guards across folds: {chosen_text}. This remains a selector-only diagnostic on the same benchmark family and does not solve regime detection.}}"
    )
    lines.append("\\label{tab:guarded-fallback}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Selector & ID Acc & OOD Acc & Regret to Oracle \\\\")
    lines.append("\\midrule")
    for key, label in [
        ("last", "Last"),
        ("best_scope", "SCOPE"),
        ("loo_aux_selector", "LOO aux selector"),
        ("loo_guarded_scope", "LOO-guarded SCOPE"),
        ("best_ood_oracle", "Oracle Best-OOD"),
    ]:
        row = rows[key]
        lines.append(
            f"{label} & "
            f"{format_mean_std(row['id_accuracy_mean'], row['id_accuracy_std'])} & "
            f"{format_mean_std(row['ood_accuracy_mean'], row['ood_accuracy_std'])} & "
            f"{row['ood_regret_mean']:.4f} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    payloads = [read_json(path) for path in args.selector_files]
    payloads.sort(key=lambda payload: int(payload.get("seed", 0)))

    rows_by_name: dict[str, list[dict[str, Any]]] = {
        "last": [],
        "best_scope": [],
        "loo_aux_selector": [],
        "best_ood_oracle": [],
        "loo_guarded_scope": [],
    }
    per_seed_choices: list[dict[str, Any]] = []
    aux_choice_counts: dict[str, int] = {}

    for holdout_index, payload in enumerate(payloads):
        selected_aux, selection_meta = select_aux_for_holdout(payloads, args.aux_family, holdout_index)
        aux_choice_counts[selected_aux] = aux_choice_counts.get(selected_aux, 0) + 1
        last_row = get_selector(payload, "last")
        scope_row = get_selector(payload, "best_scope")
        aux_row = get_selector(payload, selected_aux)
        oracle_row = get_selector(payload, "best_ood_oracle")
        guarded_row = guarded_pick(last_row, scope_row, aux_row)

        rows_by_name["last"].append(last_row)
        rows_by_name["best_scope"].append(scope_row)
        rows_by_name["loo_aux_selector"].append(aux_row)
        rows_by_name["best_ood_oracle"].append(oracle_row)
        rows_by_name["loo_guarded_scope"].append(guarded_row)
        per_seed_choices.append(
            {
                "seed": int(payload["seed"]),
                "selected_aux": selected_aux,
                "selected_aux_label": aux_label(selected_aux),
                "training_mean_ood": selection_meta["training_mean_ood"],
                "training_mean_regret": selection_meta["training_mean_regret"],
                "last_checkpoint": str(last_row["checkpoint"]),
                "scope_checkpoint": str(scope_row["checkpoint"]),
                "aux_checkpoint": str(aux_row["checkpoint"]),
                "guarded_checkpoint": str(guarded_row["checkpoint"]),
                "guarded_ood_accuracy": float(guarded_row["ood_accuracy"]),
            }
        )

    oracle_rows = rows_by_name["best_ood_oracle"]
    selectors_summary = {
        key: aggregate_rows(value, oracle_rows)
        for key, value in rows_by_name.items()
    }
    paired_tests = {
        "loo_guarded_minus_last": {
            "mean_diff_ood": mean([
                float(g["ood_accuracy"]) - float(l["ood_accuracy"])
                for g, l in zip(rows_by_name["loo_guarded_scope"], rows_by_name["last"])
            ]),
            "p_value_signflip": paired_signflip_pvalue([
                float(g["ood_accuracy"]) - float(l["ood_accuracy"])
                for g, l in zip(rows_by_name["loo_guarded_scope"], rows_by_name["last"])
            ]),
        },
        "loo_guarded_minus_scope": {
            "mean_diff_ood": mean([
                float(g["ood_accuracy"]) - float(s["ood_accuracy"])
                for g, s in zip(rows_by_name["loo_guarded_scope"], rows_by_name["best_scope"])
            ]),
            "p_value_signflip": paired_signflip_pvalue([
                float(g["ood_accuracy"]) - float(s["ood_accuracy"])
                for g, s in zip(rows_by_name["loo_guarded_scope"], rows_by_name["best_scope"])
            ]),
        },
        "loo_guarded_minus_aux": {
            "mean_diff_ood": mean([
                float(g["ood_accuracy"]) - float(a["ood_accuracy"])
                for g, a in zip(rows_by_name["loo_guarded_scope"], rows_by_name["loo_aux_selector"])
            ]),
            "p_value_signflip": paired_signflip_pvalue([
                float(g["ood_accuracy"]) - float(a["ood_accuracy"])
                for g, a in zip(rows_by_name["loo_guarded_scope"], rows_by_name["loo_aux_selector"])
            ]),
        },
    }

    output = {
        "num_seeds": len(payloads),
        "aux_family": args.aux_family,
        "aux_family_labels": {name: aux_label(name) for name in args.aux_family},
        "aux_choice_counts": aux_choice_counts,
        "per_seed_choices": per_seed_choices,
        "selectors": selectors_summary,
        "paired_tests": paired_tests,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(output, ensure_ascii=True, indent=2), encoding="utf-8")
    write_latex_table(args.output_tex, output)
    print(
        json.dumps(
            {
                "output_json": str(args.output_json.resolve()),
                "output_tex": str(args.output_tex.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
