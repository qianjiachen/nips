#!/usr/bin/env python3
"""Build paper-facing artifacts (tables/macros/figures) from experiment summaries."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

from workspace_paths import PAPER_RESULTS_DIR, PAPER_TABLES_DIR, SCRIPTS_DIR


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--multiseed-json", type=Path, required=True)
    parser.add_argument("--control-json", type=Path, default=None)
    parser.add_argument("--pilot-json", type=Path, default=None)
    parser.add_argument("--diagnostic-json", type=Path, default=None)
    parser.add_argument("--scope-cost-probe-file", type=Path, default=None)
    parser.add_argument("--scope-cost-analysis-files", type=Path, nargs="*", default=None)
    parser.add_argument("--scope-score-files", type=Path, nargs="*", default=None)
    parser.add_argument("--diagnostic-score-files", type=Path, nargs="*", default=None)
    parser.add_argument("--tex-file", type=Path, required=True)
    parser.add_argument("--trajectory-plot", type=Path, default=None)
    parser.add_argument("--workdir", type=Path, default=Path("."))
    return parser.parse_args()


def run_cmd(cmd: list[str], cwd: Path) -> None:
    subprocess.run(cmd, cwd=str(cwd), check=True)


def main() -> None:
    args = parse_args()
    cwd = args.workdir.resolve()
    tex_file = args.tex_file.resolve()
    selector_table_tex = PAPER_TABLES_DIR / "selector_table.tex"
    run_cmd(
        [
            sys.executable,
            str(SCRIPTS_DIR / "export_latex_tables.py"),
            "--multiseed-json",
            str(args.multiseed_json.resolve()),
            "--output-tex",
            str(selector_table_tex),
        ],
        cwd,
    )

    control_table_tex = None
    if args.control_json is not None and args.control_json.exists():
        control_table_tex = PAPER_TABLES_DIR / "control_selector_table.tex"
        run_cmd(
            [
                sys.executable,
                str(SCRIPTS_DIR / "export_latex_control_table.py"),
                "--control-json",
                str(args.control_json.resolve()),
                "--output-tex",
                str(control_table_tex),
            ],
            cwd,
        )

    pilot_table_tex = None
    if args.pilot_json is not None and args.pilot_json.exists():
        pilot_table_tex = PAPER_TABLES_DIR / "pilot_selector_table.tex"
        run_cmd(
            [
                sys.executable,
                str(SCRIPTS_DIR / "export_latex_pilot_table.py"),
                "--pilot-json",
                str(args.pilot_json.resolve()),
                "--output-tex",
                str(pilot_table_tex),
            ],
            cwd,
        )

    diagnostic_table_tex = None
    if args.diagnostic_json is not None and args.diagnostic_json.exists():
        diagnostic_table_tex = PAPER_TABLES_DIR / "diagnostic_selector_table.tex"
        run_cmd(
            [
                sys.executable,
                str(SCRIPTS_DIR / "export_latex_diagnostic_table.py"),
                "--diagnostic-json",
                str(args.diagnostic_json.resolve()),
                "--output-tex",
                str(diagnostic_table_tex),
            ],
            cwd,
        )

    scope_cost_table_tex = None
    if (
        args.scope_cost_probe_file is not None
        and args.scope_cost_probe_file.exists()
        and args.scope_cost_analysis_files
    ):
        scope_cost_table_tex = PAPER_TABLES_DIR / "scope_cost_table.tex"
        scope_cost_summary_json = PAPER_TABLES_DIR / "scope_cost_summary.json"
        cmd = [
            sys.executable,
            str(SCRIPTS_DIR / "summarize_scope_cost.py"),
            "--label",
            args.multiseed_json.resolve().parent.name,
            "--probe-file",
            str(args.scope_cost_probe_file.resolve()),
            "--output-json",
            str(scope_cost_summary_json),
            "--output-tex",
            str(scope_cost_table_tex),
            "--analysis-files",
        ]
        cmd.extend(str(path.resolve()) for path in args.scope_cost_analysis_files)
        if args.scope_score_files:
            cmd.append("--scope-score-files")
            cmd.extend(str(path.resolve()) for path in args.scope_score_files)
        if args.diagnostic_score_files:
            cmd.append("--diagnostic-files")
            cmd.extend(str(path.resolve()) for path in args.diagnostic_score_files)
        run_cmd(cmd, cwd)

    run_cmd(
        [
            sys.executable,
            str(SCRIPTS_DIR / "fill_tex_metrics.py"),
            "--multiseed-json",
            str(args.multiseed_json.resolve()),
            "--tex-file",
            str(tex_file),
        ],
        cwd,
    )

    copied_trajectory = None
    if args.trajectory_plot is not None and args.trajectory_plot.exists():
        copied_trajectory = PAPER_RESULTS_DIR / "trajectory_plot.png"
        copied_trajectory.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(args.trajectory_plot, copied_trajectory)

    print(
            json.dumps(
            {
                "selector_table_tex": str(selector_table_tex.resolve()),
                "control_table_tex": None if control_table_tex is None else str(control_table_tex.resolve()),
                "pilot_table_tex": None if pilot_table_tex is None else str(pilot_table_tex.resolve()),
                "diagnostic_table_tex": None if diagnostic_table_tex is None else str(diagnostic_table_tex.resolve()),
                "scope_cost_table_tex": None if scope_cost_table_tex is None else str(scope_cost_table_tex.resolve()),
                "tex_file": str(tex_file),
                "trajectory_plot": None if copied_trajectory is None else str(copied_trajectory.resolve()),
            },
            ensure_ascii=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
