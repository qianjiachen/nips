#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

CONFIG="$(ls "${ROOT_DIR}/experiments/configs/public_transfer_"*.json | head -n 1)"
python "${ROOT_DIR}/experiments/scripts/run_public_multiseed.py" \
  --config "${CONFIG}" \
  --seeds 20260320 20260321 20260322 \
  --train-gpus 0 1 2 \
  --eval-gpu 3 \
  --desired-checkpoints 10 \
  --enable-rrd
