# WSL Setup

## Why WSL2
For this project, `bitsandbytes`, quantized loading, and Hugging Face training are much more stable under `WSL2 + Ubuntu` than under native Windows Python.

## Recommended setup
```bash
bash experiments/setup_wsl.sh
```

## Quick checks
```bash
python -c "import torch; print(torch.cuda.is_available())"
python -c "import transformers, datasets, peft, bitsandbytes, matplotlib; print('ok')"
```

## First pilot sequence
```bash
bash experiments/run_pilot.sh
```

## Main public-transfer sequence
```bash
bash experiments/run_public_transfer.sh
```

## Decision gate
- If `eval_results.json` does not show non-monotonic OOD behavior, do not scale up yet.
- First harden the synthetic shift before moving to the public benchmark track.
