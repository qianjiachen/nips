# Multi-seed Layout

## Recommended directory pattern
For the main public-transfer runs, keep each seed in its own output directory:

```text
experiments/runs/intermediate/
  public_transfer_qwen25_15b_seed1/
    analysis/
      analysis.json
  public_transfer_qwen25_15b_seed2/
    analysis/
      analysis.json
  public_transfer_qwen25_15b_seed3/
    analysis/
      analysis.json
```

## Aggregation command
```bash
python experiments/scripts/aggregate_multiseed.py \
  --analysis-files \
    experiments/runs/intermediate/public_transfer_qwen25_15b_seed1/analysis/analysis.json \
    experiments/runs/intermediate/public_transfer_qwen25_15b_seed2/analysis/analysis.json \
    experiments/runs/intermediate/public_transfer_qwen25_15b_seed3/analysis/analysis.json \
  --output-dir experiments/runs/intermediate/public_transfer_qwen25_15b_multiseed \
  --tag public_transfer_qwen25_15b
```

## What it produces
- `multiseed_table.csv`
- `multiseed_summary.md`
- `multiseed_summary.json`

## How to read it
- `best_scope` is the deployable method result.
- `last` is the simplest practical baseline.
- `best_id` tests whether ordinary validation-based checkpoint selection is enough.
- `best_ood` is an oracle upper bound and should not be presented as a deployable method.
